from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
MODE=sys.argv[1]
EXPECTED=json.loads((ROOT/"expected-source.json").read_text())
COMPOSITION=json.loads((ROOT/"composition.json").read_text())
OUT=ROOT/"qa"/MODE
OUT.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_check():
 result={}
 for label in ("baseline","candidate"):
  r=ROOT/label
  checked=0
  for item in EXPECTED["leaves"]:
   p=r/item["path"];data=p.read_bytes()
   if label=="candidate" and item["path"]=="web/airspace/src/main.ts":
    assert hashlib.sha256(data).hexdigest()==COMPOSITION["candidate_sha256"]
   else:
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==item["sha"],(label,item["path"])
   assert bool(p.stat().st_mode&0o111)==(item["mode"]=="100755"),(label,item["path"],"mode")
   checked+=1
  result[label]={"upstream_files_verified":checked,"source_sha256":sha(r/"web/airspace/src/main.ts")}
 assert sha(ROOT/"candidate/tools/verify_airspace_reset.cjs")==COMPOSITION["browser_harness_sha256"]
 return result
before=source_check()
if MODE.endswith("-build"):
 label=MODE.removesuffix("-build")
 command=["/usr/bin/node",str(ROOT/"build.mjs"),label]
 cwd=ROOT
elif MODE=="candidate-tests":
 command=["/usr/bin/node",str(ROOT/"candidate/web/airspace/node_modules/vitest/vitest.mjs"),"run","--config",str(ROOT/"vitest.config.mjs"),"--configLoader","runner"]
 cwd=ROOT/"candidate/web/airspace"
elif MODE.endswith("-browser"):
 label=MODE.removesuffix("-browser")
 command=["/usr/bin/node",str(ROOT/"candidate/tools/verify_airspace_reset.cjs"),str(ROOT/(label+"-dist")),str(OUT/"browser"),str(ROOT/label/"web/airspace/src/main.ts"),"/snap/bin/chromium"]
 cwd=ROOT
else:raise ValueError(MODE)
env=dict(os.environ,TMPDIR=str(ROOT/"tmp"),NODE_PATH="/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules",PYTHONDONTWRITEBYTECODE="1")
start=time.monotonic()
request={"started_at":datetime.datetime.now(datetime.UTC).isoformat(),"command":command,"cwd":str(cwd),"before":before,
         "explicit_environment":{k:env[k] for k in ("TMPDIR","NODE_PATH","PYTHONDONTWRITEBYTECODE")},
         "available_bytes_before":os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize}
(OUT/"request.json").write_text(json.dumps(request,indent=2)+"\n")
print("Starting "+MODE,flush=True)
run=subprocess.run(command,cwd=cwd,env=env,text=True,capture_output=True,timeout=180)
(OUT/"run.log").write_text(run.stdout+run.stderr)
result=dict(request,exit_code=run.returncode,elapsed_seconds=time.monotonic()-start,
            after=source_check(),log_sha256=sha(OUT/"run.log"),
            available_bytes_after=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize)
if MODE.endswith("-browser"):
 receipt=json.loads((OUT/"browser/receipt.json").read_text())
 result["browser_result"]={k:receipt[k] for k in ("browser","passed","failed","errors","source_sha256","source_after_sha256")}
 result["checks"]={x["name"]:x["checks"] for x in receipt["cases"]}
 result["browser_receipt_sha256"]=sha(OUT/"browser/receipt.json")
(OUT/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k not in ("before","after","command","explicit_environment")},indent=2))
print((run.stdout+run.stderr)[-2800:])
assert result["before"]==result["after"]
if MODE=="baseline-browser":
 assert run.returncode==1 and receipt["passed"]==1 and receipt["failed"]==2 and receipt["errors"]==[]
 assert all(receipt["cases"][0]["checks"].values())
 for item in receipt["cases"][1:]:
  assert {key for key,value in item["checks"].items() if not value}=={"labels_reset","default_rate_restored","default_traffic_projection_restored"}
else:
 assert run.returncode==0
 if MODE=="candidate-browser":
  assert receipt["passed"]==3 and receipt["failed"]==0 and receipt["errors"]==[]
  assert all(all(x["checks"].values()) for x in receipt["cases"])
