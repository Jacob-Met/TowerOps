const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const child = require('node:child_process');
const ts = require('/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules/typescript');
const root = __dirname;
const oldRoot = '/home/jacob/hamon-universal-e3a41d2b3368-towerops-reset';
const baselinePath = path.join(root, 'baseline/web/airspace/src/main.ts');
const candidatePath = path.join(root, 'candidate/web/airspace/src/main.ts');
const authorPath = path.join(oldRoot, 'candidate/web/airspace/src/main.ts');
const originalPath = path.join(oldRoot, 'qa/baseline-main.ts');
const digest = x => crypto.createHash('sha256').update(x).digest('hex');
const assert = (x,m) => { if (!x) throw new Error(m); };
function locate(text) {
  const file = ts.createSourceFile('main.ts',text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  const fn = file.statements.find(s => ts.isFunctionDeclaration(s) && s.name?.text === 'resetWorld');
  assert(fn && fn.body, 'resetWorld must exist');
  return {start:fn.getStart(file),end:fn.end,text:text.slice(fn.getStart(file),fn.end),
          statements:fn.body.statements.map(s=>s.getText(file))};
}
const before = fs.readFileSync(baselinePath,'utf8');
assert(fs.readFileSync(candidatePath,'utf8')===before,'candidate must begin at exact current main');
const author = fs.readFileSync(authorPath,'utf8');
assert(digest(author)==='c9c07a4a1ce29e6a29e918ecbe26a75bd3816cc77741231a4167c99b408f43f5','author source pin');
const original = fs.readFileSync(originalPath,'utf8');
const b = locate(before), a = locate(author), o = locate(original);
assert(b.text===o.text,'current resetWorld differs from original; explicit reconciliation required');
const after = before.slice(0,b.start)+a.text+before.slice(b.end);
fs.writeFileSync(candidatePath,after);
const c = locate(after);
assert(c.text===a.text,'exact authored function');
assert(before.slice(0,b.start)===after.slice(0,c.start) && before.slice(b.end)===after.slice(c.end),'outside function changed');
let pos = 0;
const retained = [];
for (const s of b.statements) {
  const i = c.statements.indexOf(s,pos);
  if (i>=0) {retained.push(s);pos=i+1;}
}
assert(retained.length===16,'the independently reviewed 16 preserved statements must remain in order');
const deps = '/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules';
for (const label of ['baseline','candidate']) {
  const repo = path.join(root,label), link = path.join(repo,'web/airspace/node_modules');
  assert(!fs.existsSync(link),'do not replace existing dependency paths');
  fs.symlinkSync(deps,link,'dir');
  fs.appendFileSync(path.join(repo,'.git/info/exclude'),'\nweb/airspace/node_modules\n');
}
const harnessSource=path.join(oldRoot,'candidate/tools/verify_airspace_reset.cjs');
const harnessTarget=path.join(root,'candidate/tools/verify_airspace_reset.cjs');
assert(!fs.existsSync(harnessTarget),'do not replace a current-main tool');
const harness=fs.readFileSync(harnessSource);
assert(digest(harness)==='30d8abef87cc09615277b839dc4d6edcc7ae90d6443abdbe18a90f86294aa6d7','frozen browser harness pin');
fs.copyFileSync(harnessSource,harnessTarget);
const output={
  base_commit:'a704b2c9f957a5f65169fa7eeb5e98f34c5a9d2c',
  base_tree:'5451d7fe56438137d3e162ccfcaabc5e064ab236',
  baseline_sha256:digest(before),candidate_sha256:digest(after),author_sha256:digest(author),
  original_function_identical_on_current_main:true,
  exact_authored_reset_function:true,outside_reset_world_bytes_identical:true,
  preserved_statements:retained.length,baseline_statements:b.statements.length,candidate_statements:c.statements.length,
  browser_harness_sha256:digest(harness),
  excluded_owner_scope:'PR44 broader pauseTraffic helper and its eight call sites remain with estate-55e3e26c5905; only shared rate=1 behavior overlaps.',
};
fs.writeFileSync(path.join(root,'composition.json'),JSON.stringify(output,null,2)+'\n');
fs.writeFileSync(path.join(root,'runtime.diff'),child.execFileSync('git',['-C',path.join(root,'candidate'),'diff','--','web/airspace/src/main.ts']));
console.log(JSON.stringify(output,null,2));
