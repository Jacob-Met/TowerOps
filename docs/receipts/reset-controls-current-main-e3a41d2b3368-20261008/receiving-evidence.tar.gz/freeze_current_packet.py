from pathlib import Path
import base64,datetime,gzip,hashlib,io,json,re,subprocess,tarfile
ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/"candidate"
DEST=Path("docs/receipts/reset-controls-current-main-e3a41d2b3368-20261008")
PACKET=CANDIDATE/DEST
sha=lambda b:hashlib.sha256(b).hexdigest()
digest=lambda p:sha(p.read_bytes())
read=lambda p:json.loads(p.read_text())
composition=read(ROOT/"composition.json")
expected=read(ROOT/"expected-source.json")
phases={n:read(ROOT/"qa"/n/"result.json") for n in ("baseline-build","baseline-browser","candidate-build","candidate-tests","candidate-browser")}
assert all(x["before"]==x["after"] for x in phases.values())
assert all(phases[x]["exit_code"]==0 for x in ("baseline-build","candidate-build","candidate-tests","candidate-browser"))
original=read(ROOT/"qa/baseline-browser/browser/receipt.json")
fixed=read(ROOT/"qa/candidate-browser/browser/receipt.json")
assert (original["passed"],original["failed"],original["errors"])==(1,2,[])
assert (fixed["passed"],fixed["failed"],fixed["errors"])==(3,0,[])
assert sum(len(x["checks"]) for x in fixed["cases"])==19
assert all(all(x["checks"].values()) for x in fixed["cases"])
for label,browser_receipt in (("baseline",original),("candidate",fixed)):
 for item in browser_receipt["served_files"]:
  assert digest(ROOT/(label+"-dist")/item["path"])==item["sha256"],(label,item["path"])
test_log=re.sub(r"\x1b\[[0-9;]*m","",(ROOT/"qa/candidate-tests/run.log").read_text())
assert re.search(r"Tests\s+120 passed",test_log)
source=CANDIDATE/"web/airspace/src/main.ts"
assert digest(source)==composition["candidate_sha256"]
def git(*args):return subprocess.check_output(["git","-C",str(CANDIDATE),*args],text=True).strip()
assert git("rev-parse","HEAD")==expected["base_commit"]
assert git("diff","--name-only")=="web/airspace/src/main.ts"
assert subprocess.check_output(["git","-C",str(ROOT/"baseline"),"status","--porcelain"],text=True)==""
members={}
for n in ("expected-source.json","composition.json","owner-pr44-main.ts","runtime.diff","compose.cjs","build.mjs","vitest.config.mjs","run_qualification.py","freeze_current_packet.py"):
 members[n]=(ROOT/n).read_bytes()
for label in ("baseline","candidate"):
 members["source/"+label+"-main.ts"]=(ROOT/label/"web/airspace/src/main.ts").read_bytes()
 for p in sorted((ROOT/(label+"-dist")).rglob("*")):
  if p.is_file() and (p.name=="index.html" or p.relative_to(ROOT/(label+"-dist")).parts[0]=="assets"):
   members["served/"+label+"/"+p.relative_to(ROOT/(label+"-dist")).as_posix()]=p.read_bytes()
for p in sorted((ROOT/"qa").rglob("*")):
 if p.is_file():members["qa/"+p.relative_to(ROOT/"qa").as_posix()]=p.read_bytes()
deps=Path("/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules")
versions={n:read(deps/n/"package.json")["version"] for n in ("typescript","vite","vitest","pyodide")}
versions["playwright"]=read(Path("/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules/playwright/package.json"))["version"]
members["dependency-versions.json"]=(json.dumps(versions,indent=2)+"\n").encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode="wb",filename="",mtime=0,compresslevel=9) as compressed:
 with tarfile.open(fileobj=compressed,mode="w",format=tarfile.PAX_FORMAT) as archive:
  for path,data in sorted(members.items()):
   entry=tarfile.TarInfo(path);entry.size=len(data);entry.mode=0o644;entry.uid=entry.gid=entry.mtime=0;entry.uname=entry.gname=""
   archive.addfile(entry,io.BytesIO(data))
archive_bytes=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive_bytes),mode="r:gz") as archive:
 restored={x.name:archive.extractfile(x).read() for x in archive.getmembers() if x.isfile()}
assert restored==members
PACKET.mkdir(parents=True,exist_ok=False)
(PACKET/"README.md").write_bytes((ROOT/"README.packet.md").read_bytes())
(PACKET/"receiving-evidence.tar.gz").write_bytes(archive_bytes)
manifest={"base_commit":expected["base_commit"],"base_tree":expected["base_tree"],
 "archive":{"path":"receiving-evidence.tar.gz","sha256":sha(archive_bytes),"bytes":len(archive_bytes),"members":len(members)},
 "member_index":[{"path":p,"sha256":sha(b),"bytes":len(b)} for p,b in sorted(members.items())],
 "archive_readback_every_member_exact":True,"dependency_versions":versions,
 "source_sha256":composition["candidate_sha256"],"browser_harness_sha256":composition["browser_harness_sha256"]}
(PACKET/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
source_bytes=source.read_bytes()
receipt={"status":"PASS_CURRENT_MAIN_RESET_RECEIVING","captured_at":datetime.datetime.now(datetime.UTC).isoformat(),
 "base_commit":expected["base_commit"],"base_tree":expected["base_tree"],
 "candidate_source":{"path":"web/airspace/src/main.ts","sha256":sha(source_bytes),
 "git_blob":hashlib.sha1(b"blob "+str(len(source_bytes)).encode()+b"\0"+source_bytes).hexdigest()},
 "composition":composition,"all_164_inherited_files_and_modes_verified_each_phase":True,
 "source_unchanged_during_receiving":True,"served_builds_unchanged_against_both_browser_manifests":True,
 "builds":{"baseline":"passed TypeScript and Vite","candidate":"passed TypeScript and Vite","transformed_modules":19},
 "native_tests":{"test_files":9,"passed":120,"failed":0},
 "browser":{"version":fixed["browser"],"baseline_groups":{"passed":1,"failed":2,"expected_assertion_failures":6},
 "candidate_groups":{"passed":3,"failed":0,"assertions_passed":19},"page_or_http_errors":0,
 "baseline_receipt_sha256":digest(ROOT/"qa/baseline-browser/browser/receipt.json"),
 "candidate_receipt_sha256":digest(ROOT/"qa/candidate-browser/browser/receipt.json")},
 "current_policy_screenshots_visually_checked":True,
 "owner_pr44":{"head":expected["owner"]["head"],"main_sha256":expected["owner"]["expected_main_sha256"],
 "shared_seam":"rate=1 on Reset","broader_pause_handling_untouched":True},
 "prior_independent_receiving":{"root_commit":"486a2b6f532162a6ea1b67818df53755d7bd953a",
 "root_acceptance_sha256":"ef0b127745fd9d69a1ff3c9b36dd9366960ddc7a4219ae7cc44b673dd67ad5b1",
 "external_proof_commit":"a704b2c9f957a5f65169fa7eeb5e98f34c5a9d2c","external_coordination_comment":6059713022,
 "source_scope":"Original exact Reset function on 09b96e31d2867af5b7a9738406d0431cf1010090; earlier independent executions are not claimed on the new main closure."},
 "archive_sha256":sha(archive_bytes),"archive_manifest_sha256":digest(PACKET/"manifest.json"),
 "runtime_scope":"resetWorld only; existing current-main statements outside the function unchanged",
 "publication_state":"native candidate checkpoint only",
 "packet_only_enospc_preserved":True}
(PACKET/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
subprocess.run(["git","-C",str(CANDIDATE),"add","web/airspace/src/main.ts","tools/verify_airspace_reset.cjs",str(DEST)],check=True)
subprocess.run(["git","-C",str(CANDIDATE),"-c","user.name=HAMON local_recovery",
 "-c","user.email=hamon-local-recovery@users.noreply.github.com","commit","-q","-m","Synchronize Reset controls on current Airspace main"],check=True)
commit=git("rev-parse","HEAD")
assert git("rev-parse","HEAD^")==expected["base_commit"]
assert git("status","--porcelain")==""
files=[]
for rel in ["web/airspace/src/main.ts","tools/verify_airspace_reset.cjs",*[p.relative_to(CANDIDATE).as_posix() for p in sorted(PACKET.iterdir())]]:
 data=(CANDIDATE/rel).read_bytes()
 item={"path":rel,"sha256":sha(data),"bytes":len(data),"content_base64":base64.b64encode(data).decode()}
 if rel.endswith(".tar.gz"):item.update(encoding="base64",content_type="application/gzip")
 files.append(item)
payload={"repository":"Jacob-Met/TowerOps","upstream_parent":expected["base_commit"],"native_candidate_commit":commit,
 "native_candidate_path":str(CANDIDATE),"runtime_scope":"resetWorld only","files":files,"contains_binary":True,
 "binary_paths":[str(DEST/"receiving-evidence.tar.gz")],
 "publication_boundary":"Check current base and PR44 coordination; retain broader pause handling with its owner."}
payload_path=ROOT/"current-main-publication-payload.json"
payload_path.write_text(json.dumps(payload,indent=2)+"\n")
result={"candidate_commit":commit,"candidate_parent":expected["base_commit"],"candidate_path":str(CANDIDATE),
 "source_sha256":sha(source_bytes),"source_git_blob":receipt["candidate_source"]["git_blob"],
 "receipt_sha256":digest(PACKET/"receipt.json"),"evidence_path":str(PACKET),
 "archive_sha256":sha(archive_bytes),"archive_bytes":len(archive_bytes),"archive_members":len(members),
 "payload":{"path":str(payload_path),"sha256":digest(payload_path),"bytes":payload_path.stat().st_size,"files":len(files)},
 "result":"120 native tests and all 19 browser assertions pass; strict current-main baseline negative control retained"}
(ROOT/"publication-manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
