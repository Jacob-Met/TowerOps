(function(){let e=null;async function t(t){return e||=(async()=>{let{loadPyodide:e}=await import(
/* @vite-ignore */
t+`python/pyodide.mjs`),n=await e({indexURL:t+`python/`}),r=await fetch(t+`python/towerops.py`);if(!r.ok)throw Error(`TowerOps Python source could not load`);return n.FS.writeFile(`towerops.py`,await r.text()),await n.runPythonAsync(`
import json
from dataclasses import asdict
from towerops import Aircraft, WorldState, SafetyPolicy, AdvisoryPlanner, Advisory, Approval, Ack, ControlRoom, GateRejected, canonical_bytes

def browser_audit(room):
    return {
        'events': room.audit.events,
        'audit_canonical': [canonical_bytes({k: v for k, v in event.items() if k != 'event_hash'}).decode('utf-8') for event in room.audit.events],
        'audit_json': json.dumps(room.audit.events),
    }

def browser_request(raw):
    q = json.loads(raw)
    if q.get('op') == 'review_trace':
        from decision_trace import review_trace
        try:
            return json.dumps(review_trace(q.get('trace_json')), allow_nan=False)
        except (TypeError, ValueError) as error:
            return json.dumps({'error': str(error)})
    s = q['state']
    state = WorldState(s['version'], float(s['observed_at']), tuple(Aircraft(**{k: (v if k == 'aircraft_id' else float(v)) for k,v in a.items()}) for a in s['aircraft']))
    policy = SafetyPolicy(**{k: float(v) for k,v in q['policy'].items()})
    if q['op'] == 'plan':
        plans = AdvisoryPlanner(policy).plan(state, float(q['now']))
        a = plans[0] if plans else None
        return json.dumps({'advisory': dict(asdict(a), advisory_hash=a.advisory_hash) if a else None})
    body = dict(q['advisory'])
    body.pop('advisory_hash', None)
    a = Advisory(**{k: (v if k in ('aircraft_id', 'world_hash', 'rationale') else float(v)) for k,v in body.items()})
    room = ControlRoom(policy)
    room.audit.events = json.loads(q.get('audit_json', '[]'))
    # JSON.stringify drops .0 from whole-number timestamps. Preserve the
    # declared float fields before Python hashes the approval/readback event,
    # just as the state and advisory fields above already do. Otherwise a
    # valid chain can hash 1 here and 1.0 in the browser's canonical verifier.
    # Only restore JSON integer numbers; booleans/strings/null retain their
    # original types so the native gate can reject invalid timestamps.
    approval = Approval(**{k: (float(v) if k == 'approved_at' and type(v) is int else v) for k,v in q['approval'].items()}) if q.get('approval') else None
    ack = Ack(**{k: (float(v) if k == 'acknowledged_at' and type(v) is int else v) for k,v in q['ack'].items()}) if q.get('ack') else None
    try:
        after = room.apply(state, a, approval, ack, float(q['now']))
        return json.dumps({'state': after.to_dict(), 'valid': room.audit.verify(room.audit.events), **browser_audit(room)})
    except GateRejected as e:
        return json.dumps({'error': e.reason, **browser_audit(room)})
`),n})().catch(t=>{throw e=null,t}),e}let n=null;async function r(e,t){return n||=(async()=>{for(let n of[`audit_replay.py`,`decision_trace.py`]){let r=await fetch(t+`python/`+n);if(!r.ok)throw Error(`Decision replay Python source could not load`);e.FS.writeFile(n,await r.text())}})().catch(e=>{throw n=null,e}),n}self.onmessage=async e=>{let{id:n,base:i,request:a}=e.data;try{let e=await t(i);a?.op===`review_trace`&&await r(e,i),e.globals.set(`browser_payload`,JSON.stringify(a));let o=JSON.parse(await e.runPythonAsync(`browser_request(browser_payload)`));self.postMessage({id:n,result:o})}catch(e){self.postMessage({id:n,error:String(e)})}}})();