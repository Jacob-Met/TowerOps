from pathlib import Path
import ast,base64,datetime,hashlib,io,json,os,subprocess,tarfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT/"candidate"
PRIOR=Path("/home/jacob/hamon-universal-e3a41d2b3368-towerops-reset-current-main")
PREFIX="docs/receipts/reset-controls-main-8d4933-e3a41d2b3368-20261008"
OUT=REPO/PREFIX
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return Path(p).read_bytes()
def pin(p):
    b=read(p);return {"bytes":len(b),"sha256":sha(b)}
def blob(data):return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def writejson(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
expected=json.loads((ROOT/"expected-source.json").read_text())
composition=json.loads((ROOT/"composition.json").read_text())
require(expected["base_commit"]=="8d4933f33a0f5e0673fa9d00002e8b29302a1c53" and len(expected["leaves"])==185,"wrong upstream")
for item in expected["leaves"]:
    p=REPO/item["path"];want=composition["candidate_git_blob"] if item["path"]=="web/airspace/src/main.ts" else item["sha"]
    require(blob(read(p))==want,"upstream mismatch "+item["path"])
    require(bool(p.stat().st_mode&0o111)==(item["mode"]=="100755"),"mode mismatch "+item["path"])
results={mode:json.loads((ROOT/"qa"/mode/"result.json").read_text()) for mode in ("candidate-build","candidate-reset-browser","candidate-draft-browser")}
require(all(r["exit_code"]==0 and r["before"]==r["after"] and r["after"]["upstream_files_verified"]==185 for r in results.values()),"qualification did not pass")
reset=results["candidate-reset-browser"];draft=results["candidate-draft-browser"]
checks=[v for values in reset["checks"].values() for v in values.values()]
require(len(checks)==19 and all(checks),"Reset controls failed")
require(len(draft["browser_result"]["checks"])==9 and all(x["status"]=="passed" for x in draft["browser_result"]["checks"]),"draft controls failed")
require(not reset["browser_result"]["errors"] and not draft["browser_result"]["pageErrors"],"browser errors")
require(draft["browser_result"]["cleanup"]["status"]=="passed","draft cleanup failed")
dist={str(p.relative_to(ROOT/"candidate-dist")):sha(read(p)) for p in sorted((ROOT/"candidate-dist").rglob("*")) if p.is_file()}
require(all(r["dist_after"]==dist for r in results.values()),"served build changed")
require(pin(PRIOR/"current-main-publication-payload.json")["sha256"]=="ba32826af43f6bd108497e82a8ceec6ce9a72e8cd7e9b51990ec99aab0d4a4a4","historical payload changed")
prior_payload=json.loads((PRIOR/"current-main-publication-payload.json").read_text())
historical=[]
for entry in prior_payload["files"]:
    if entry["path"] in ("web/airspace/src/main.ts","tools/verify_airspace_reset.cjs"):continue
    data=read(PRIOR/"candidate"/entry["path"])
    require(sha(data)==entry["sha256"] and len(data)==entry["bytes"],"historical receipt changed")
    target=REPO/entry["path"]
    require(not target.exists(),"historical target already exists")
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
    historical.append({"path":entry["path"],**pin(target)})
require(len(historical)==4,"historical receipt count")
OUT.mkdir(parents=True,exist_ok=False)
readme=read(ROOT/"README.packet.md")
require(len(readme)>3500 and b"19 existing Reset assertions" in readme,"truncated README")
(OUT/"README.md").write_bytes(readme)
members={}
for name in ("baseline-main.ts","composition.json","compose.cjs","build.mjs","run_qualification.py","expected-source.json","runtime.diff","clone.log","finalize_packet.py"):
    members["preparation/"+name]=read(ROOT/name)
members["source/main.ts"]=read(REPO/"web/airspace/src/main.ts")
members["source/verify_airspace_reset.cjs"]=read(REPO/"tools/verify_airspace_reset.cjs")
members["source/world-json-draft.browser.mjs"]=read(REPO/"web/airspace/tests/world-json-draft.browser.mjs")
for p in sorted((ROOT/"qa").rglob("*")):
    if not p.is_file() or "work" in p.relative_to(ROOT/"qa").parts:continue
    require(p.suffix in (".json",".log",".png"),"unexpected evidence file "+str(p))
    members[str(p.relative_to(ROOT))]=read(p)
for p in sorted((ROOT/"candidate-dist").rglob("*")):
    if p.is_file() and (p.name=="index.html" or p.parent.name=="assets"):
        members["served-build/"+str(p.relative_to(ROOT/"candidate-dist"))]=read(p)
member_index=[{"path":name,"bytes":len(data),"sha256":sha(data)} for name,data in sorted(members.items())]
archive=OUT/"receiving-evidence.tar.gz"
with archive.open("wb") as raw:
    import gzip
    with gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode="w",fileobj=zipped) as tar:
            for name,data in sorted(members.items()):
                item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive,"r:gz") as tar:
    require(tar.getnames()==sorted(members),"archive members changed")
    for name,data in members.items():require(tar.extractfile(name).read()==data,"archive readback mismatch "+name)
receipt={
 "schema":"towerops.reset-controls.current-main-receiving.v2",
 "created_at":datetime.datetime.now(datetime.UTC).isoformat(),
 "status":"qualified isolated current-main candidate; not published or deployed",
 "source":composition,
 "qualified_commands":{mode:{"command":r["command"],"exit_code":r["exit_code"],"elapsed_seconds":r["elapsed_seconds"],"result":pin(ROOT/"qa"/mode/"result.json")} for mode,r in results.items()},
 "reset":{"groups_passed":3,"assertions_passed":19,"errors":0,"browser":reset["browser_result"]["browser"],"receipt":pin(ROOT/"qa/candidate-reset-browser/browser/receipt.json")},
 "worldstate_draft":{"checks_passed":9,"errors":0,"cleanup":"passed","receiver_sha256":composition["draft_browser_sha256"],"receipt":pin(ROOT/"qa/candidate-draft-browser/browser/browser-report.json")},
 "preservation":{"upstream_files_and_modes":185,"other_source_bytes_unchanged":True,"outside_reset_world_bytes_identical":True,"retained_statements":16,"draft_edits_preserved":True,"served_build_unchanged":True,"historical_receipts":historical},
 "served_build_sha256":dist,"archive":pin(archive),"archive_members":len(member_index),
 "visual_inspection":"Fast-wide-policy screenshot reviewed; default 5.0 NM, 1,000 FT, and 5.0 MIN agree with controls.",
 "limits":["No new 8d4933 baseline execution; earlier a704 negative controls remain historical.","120 unchanged unit tests were not repeated.","Draft owner receiver uses exact source through pinned Vite; Reset receiver uses the new production bundle.","No GitHub or live hosting/deployment action."]}
writejson(OUT/"receipt.json",receipt)
manifest={"schema":"towerops.receiving.member-manifest.v1","source":composition,"files":{"README.md":pin(OUT/"README.md"),"receipt.json":pin(OUT/"receipt.json"),"receiving-evidence.tar.gz":pin(archive)},"archive_members":member_index}
writejson(OUT/"manifest.json",manifest)
paths=["web/airspace/src/main.ts","tools/verify_airspace_reset.cjs"]+[x["path"] for x in historical]+[PREFIX+"/"+n for n in ("README.md","manifest.json","receipt.json","receiving-evidence.tar.gz")]
require(len(paths)==10,"publication file count")
subprocess.run(["git","-C",str(REPO),"checkout","-b","fix/reset-controls-draft-composition-e3a41d2b3368"],check=True,capture_output=True,text=True)
subprocess.run(["git","-C",str(REPO),"add","--",*paths],check=True,capture_output=True,text=True)
subprocess.run(["git","-C",str(REPO),"-c","user.name=HAMON local_recovery","-c","user.email=hamon-local-recovery@users.noreply.github.com","commit","-m","Fix Reset control synchronization and receive WorldState draft composition"],check=True,capture_output=True,text=True)
commit=subprocess.check_output(["git","-C",str(REPO),"rev-parse","HEAD"],text=True).strip()
parent=subprocess.check_output(["git","-C",str(REPO),"rev-parse","HEAD^"],text=True).strip()
require(parent==expected["base_commit"],"wrong candidate parent")
raw_tree=subprocess.check_output(["git","-C",str(REPO),"ls-tree","-r","-z","HEAD"])
tree={}
for raw in raw_tree.split(b"\0"):
    if not raw:continue
    info,name=raw.split(b"\t");mode,typ,ident=info.decode().split()
    tree[name.decode()]={"mode":mode,"type":typ,"sha":ident}
for item in expected["leaves"]:
    want=dict(mode=item["mode"],type=item["type"],sha=composition["candidate_git_blob"] if item["path"]=="web/airspace/src/main.ts" else item["sha"])
    require(tree.get(item["path"])==want,"committed upstream preservation failed "+item["path"])
require(len(tree)==194,"unexpected publication additions")
require(not subprocess.check_output(["git","-C",str(REPO),"status","--porcelain"],text=True),"candidate not clean")
payload={"repository":"Jacob-Met/TowerOps","upstream_parent":parent,"native_candidate_commit":commit,"native_candidate_path":str(REPO),"runtime_scope":"resetWorld only; all 185 upstream leaves/modes preserved including WorldState draft PR46","files":[],"contains_binary":True,"binary_paths":[p for p in paths if p.endswith(".tar.gz")],"publication_boundary":"Unpublished isolated candidate; current head must still pass receiving tree gate."}
for path in paths:
    data=read(REPO/path);item={"path":path,"sha256":sha(data),"bytes":len(data)}
    if path.endswith(".tar.gz"):item.update(content_base64=base64.b64encode(data).decode(),encoding="base64",content_type="application/gzip")
    else:item["content"]=data.decode()
    payload["files"].append(item)
writejson(ROOT/"current-main-publication-payload.json",payload)
publication={"repository":payload["repository"],"upstream_parent":parent,"native_candidate_commit":commit,"candidate_tree":subprocess.check_output(["git","-C",str(REPO),"rev-parse","HEAD^{tree}"],text=True).strip(),"upstream_leaves_preserved":185,"unowned_leaves_byte_mode_identical":184,"added_files":9,"publication_files":10,"runtime":pin(REPO/"web/airspace/src/main.ts"),"receipt":pin(OUT/"receipt.json"),"archive":pin(archive),"archive_members":len(member_index),"historical_files_byte_identical":4,"payload":pin(ROOT/"current-main-publication-payload.json")}
writejson(ROOT/"publication-manifest.json",publication)
require(pin(PRIOR/"current-main-publication-payload.json")["sha256"]=="ba32826af43f6bd108497e82a8ceec6ce9a72e8cd7e9b51990ec99aab0d4a4a4","historical payload mutated")
print(json.dumps(publication,indent=2))
