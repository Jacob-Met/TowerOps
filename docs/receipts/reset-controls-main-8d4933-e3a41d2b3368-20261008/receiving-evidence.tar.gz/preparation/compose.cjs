const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const child = require('node:child_process');
const deps = '/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules';
const ts = require(path.join(deps,'typescript'));
const root=__dirname, repo=path.join(root,'candidate');
const prior='/home/jacob/hamon-universal-e3a41d2b3368-towerops-reset-current-main';
const originalRoot='/home/jacob/hamon-universal-e3a41d2b3368-towerops-reset';
const sha = x=>crypto.createHash('sha256').update(x).digest('hex');
const blob = x=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+x.length+'\0'),x])).digest('hex');
const req=(x,m)=>{if(!x)throw Error(m)};
const expected=JSON.parse(fs.readFileSync(path.join(root,'expected-source.json'),'utf8'));
req(expected.leaves.length===185 && expected.truncated===false,'complete upstream inventory');
req(child.execFileSync('git',['-C',repo,'rev-parse','HEAD'],{encoding:'utf8'}).trim()===expected.base_commit,'base commit changed');
for(const item of expected.leaves) {
 const p=path.join(repo,item.path),s=fs.lstatSync(p),data=fs.readFileSync(p);
 req(s.isFile() && blob(data)===item.sha,'upstream source mismatch '+item.path);
 req(Boolean(s.mode&0o111)===(item.mode==='100755'),'upstream mode mismatch '+item.path);
}
function locate(text) {
 const file=ts.createSourceFile('main.ts',text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 const fn=file.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='resetWorld');
 req(fn?.body,'missing resetWorld');
 return {start:fn.getStart(file),end:fn.end,text:text.slice(fn.getStart(file),fn.end),statements:fn.body.statements.map(s=>s.getText(file))};
}
const source=path.join(repo,'web/airspace/src/main.ts');
const before=fs.readFileSync(source,'utf8');
req(blob(Buffer.from(before))==='d975ab8c55c01b0f6177ad736ed0c6b1fa821599','new upstream main blob');
const author=fs.readFileSync(path.join(originalRoot,'candidate/web/airspace/src/main.ts'),'utf8');
req(sha(author)==='c9c07a4a1ce29e6a29e918ecbe26a75bd3816cc77741231a4167c99b408f43f5','frozen author source');
const original=fs.readFileSync(path.join(originalRoot,'qa/baseline-main.ts'),'utf8');
const b=locate(before),a=locate(author),o=locate(original);
req(b.text===o.text,'current resetWorld changed');
const after=before.slice(0,b.start)+a.text+before.slice(b.end),c=locate(after);
req(c.text===a.text,'authored function mismatch');
req(before.slice(0,b.start)===after.slice(0,c.start)&&before.slice(b.end)===after.slice(c.end),'outside function mismatch');
let pos=0,retained=[];
for(const s of b.statements){const i=c.statements.indexOf(s,pos);if(i>=0){retained.push(s);pos=i+1;}}
req(retained.length===16,'preserved statement count');
fs.writeFileSync(path.join(root,'baseline-main.ts'),before);
fs.writeFileSync(source,after);
const harnessSource=path.join(prior,'candidate/tools/verify_airspace_reset.cjs'),harness=fs.readFileSync(harnessSource);
req(sha(harness)==='30d8abef87cc09615277b839dc4d6edcc7ae90d6443abdbe18a90f86294aa6d7','reset receiver changed');
const harnessTarget=path.join(repo,'tools/verify_airspace_reset.cjs');
req(!fs.existsSync(harnessTarget),'upstream receiver collision');
fs.writeFileSync(harnessTarget,harness);
const draftPath=path.join(repo,'web/airspace/tests/world-json-draft.browser.mjs'),draft=fs.readFileSync(draftPath);
req(blob(draft)==='aa01b6711f7aeb7358cc4bba21477d840f449d45','draft receiver changed');
const link=path.join(repo,'web/airspace/node_modules');
req(!fs.existsSync(link),'pre-existing dependency link');
fs.symlinkSync(deps,link,'dir');
fs.appendFileSync(path.join(repo,'.git/info/exclude'),'\nweb/airspace/node_modules\n');
const build=fs.readFileSync(path.join(prior,'build.mjs'),'utf8').replace(prior,root);
req(build!==fs.readFileSync(path.join(prior,'build.mjs'),'utf8'),'build root replacement');
fs.writeFileSync(path.join(root,'build.mjs'),build);
const output={base_commit:expected.base_commit,base_tree:expected.tree,upstream_leaves:185,
 baseline_sha256:sha(before),baseline_git_blob:blob(Buffer.from(before)),candidate_sha256:sha(after),candidate_git_blob:blob(Buffer.from(after)),
 author_sha256:sha(author),exact_authored_reset_function:true,original_function_identical_on_current_main:true,
 outside_reset_world_bytes_identical:true,preserved_statements:retained.length,baseline_statements:b.statements.length,candidate_statements:c.statements.length,
 browser_harness_sha256:sha(harness),draft_browser_git_blob:blob(draft),draft_browser_sha256:sha(draft),
 receiving_delta:'WorldState JSON draft PR46; every byte outside resetWorld preserved, including all five draft changes',
 scope:'Only the accepted resetWorld rate and policy-control synchronization; PR44 broad pause handling remains with owner'};
fs.writeFileSync(path.join(root,'composition.json'),JSON.stringify(output,null,2)+'\n');
fs.writeFileSync(path.join(root,'runtime.diff'),child.execFileSync('git',['-C',repo,'diff','--','web/airspace/src/main.ts']));
console.log(JSON.stringify(output,null,2));
