from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
MODE=sys.argv[1]
EXPECTED=json.loads((ROOT/"expected-source.json").read_text())
COMPOSITION=json.loads((ROOT/"composition.json").read_text())
OUT=ROOT/"qa"/MODE
OUT.mkdir(parents=True,exist_ok=False)
REPO=ROOT/"candidate"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(data):return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
def source_check():
    checked=0
    for item in EXPECTED["leaves"]:
        p=REPO/item["path"];data=p.read_bytes()
        expected=COMPOSITION["candidate_git_blob"] if item["path"]=="web/airspace/src/main.ts" else item["sha"]
        if blob(data)!=expected:raise RuntimeError("Source mismatch "+item["path"])
        if bool(p.stat().st_mode&0o111)!=(item["mode"]=="100755"):raise RuntimeError("Mode mismatch "+item["path"])
        checked+=1
    if sha(REPO/"tools/verify_airspace_reset.cjs")!=COMPOSITION["browser_harness_sha256"]:raise RuntimeError("Reset receiver changed")
    if sha(REPO/"web/airspace/tests/world-json-draft.browser.mjs")!=COMPOSITION["draft_browser_sha256"]:raise RuntimeError("Draft receiver changed")
    return {"upstream_files_verified":checked,"runtime_sha256":sha(REPO/"web/airspace/src/main.ts"),
            "reset_receiver_sha256":COMPOSITION["browser_harness_sha256"],"draft_receiver_sha256":COMPOSITION["draft_browser_sha256"]}
def dist_check():
    root=ROOT/"candidate-dist"
    return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob("*")) if p.is_file()} if root.exists() else None
before=source_check()
dist_before=dist_check()
if MODE=="candidate-build":
    command=["/usr/bin/node",str(ROOT/"build.mjs"),"candidate"]
elif MODE=="candidate-reset-browser":
    command=["/usr/bin/node",str(REPO/"tools/verify_airspace_reset.cjs"),str(ROOT/"candidate-dist"),str(OUT/"browser"),str(REPO/"web/airspace/src/main.ts"),"/snap/bin/chromium"]
elif MODE=="candidate-draft-browser":
    command=["/usr/bin/node",str(REPO/"web/airspace/tests/world-json-draft.browser.mjs"),"--root",str(REPO),"--qa",str(OUT/"work"),"--output",str(OUT/"browser"),"--toolchain","/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules","--browser","/snap/bin/chromium"]
else:raise ValueError(MODE)
env=dict(os.environ,TMPDIR=str(ROOT/"tmp"),NODE_PATH="/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules",PYTHONDONTWRITEBYTECODE="1")
start=time.monotonic()
request={"started_at":datetime.datetime.now(datetime.UTC).isoformat(),"command":command,"cwd":str(ROOT),"before":before,
         "explicit_environment":{k:env[k] for k in ("TMPDIR","NODE_PATH","PYTHONDONTWRITEBYTECODE")},
         "available_bytes_before":os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize}
(OUT/"request.json").write_text(json.dumps(request,indent=2)+"\n")
print("Starting "+MODE,flush=True)
run=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=180)
(OUT/"run.log").write_text(run.stdout+run.stderr)
dist_after=dist_check()
result=dict(request,exit_code=run.returncode,elapsed_seconds=time.monotonic()-start,
            after=source_check(),log_sha256=sha(OUT/"run.log"),dist_after=dist_after,
            available_bytes_after=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize)
if MODE=="candidate-reset-browser":
    receipt=json.loads((OUT/"browser/receipt.json").read_text())
    result["browser_result"]={k:receipt[k] for k in ("browser","passed","failed","errors","source_sha256","source_after_sha256")}
    result["checks"]={x["name"]:x["checks"] for x in receipt["cases"]}
    result["browser_receipt_sha256"]=sha(OUT/"browser/receipt.json")
elif MODE=="candidate-draft-browser":
    receipt=json.loads((OUT/"browser/browser-report.json").read_text())
    result["browser_result"]={k:receipt[k] for k in ("status","checks","pageErrors","sourceChanged","cleanup","browser")}
    result["browser_receipt_sha256"]=sha(OUT/"browser/browser-report.json")
if MODE!="candidate-build":
    result["served_build_unchanged"]=dist_before==dist_after
(OUT/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k not in ("before","after","command","explicit_environment","dist_after")},indent=2))
print((run.stdout+run.stderr)[-3000:])
if before!=result["after"]:raise RuntimeError("Source changed during qualification")
if run.returncode:raise RuntimeError(f"{MODE} failed with exit {run.returncode}")
if MODE=="candidate-reset-browser":
    if receipt["passed"]!=3 or receipt["failed"]!=0 or receipt["errors"]:raise RuntimeError("Reset groups failed")
    checks=[v for case in receipt["cases"] for v in case["checks"].values()]
    if len(checks)!=19 or not all(checks):raise RuntimeError("Reset assertions failed")
elif MODE=="candidate-draft-browser":
    if receipt["status"]!="passed" or len(receipt["checks"])!=9 or not all(x["status"]=="passed" for x in receipt["checks"]):raise RuntimeError("Draft assertions failed")
    if receipt["sourceChanged"] or receipt["pageErrors"] or receipt["cleanup"]["status"]!="passed":raise RuntimeError("Draft cleanup/source failed")
if MODE!="candidate-build" and not result["served_build_unchanged"]:raise RuntimeError("Served build changed")
