from pathlib import Path
import json,hashlib,subprocess,os,sys,datetime
r=Path('/tmp/towerops-plan-html-066deeadcc8b')
p=json.loads((r/'evidence/canonical-web-supplement.json').read_text())
for row in p['files']:
 raw=row['content'].encode();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['sha']
 for name in ['baseline','candidate']:
  dest=r/name/row['path'];dest.parent.mkdir(exist_ok=True)
  assert not dest.exists();dest.write_bytes(raw)
out=r/'evidence/author-native-v2';out.mkdir()
files=lambda:{str(p.relative_to(r/'candidate')):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((r/'candidate').rglob('*')) if p.is_file() and not any(x in p.parts for x in ['__pycache__','.pytest_cache'])}
before=files()
argv=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider']
result=subprocess.run(argv,cwd=r/'candidate',capture_output=True,check=False,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(r/'evidence/author-native-v1/tmp')},timeout=120)
(out/'stdout.txt').write_bytes(result.stdout);(out/'stderr.txt').write_bytes(result.stderr)
after=files();assert before==after
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(r/'candidate'),'returncode':result.returncode,'source_before':before,'source_after':after,'source_unchanged':before==after,'prior_failure':'Original capsule omitted3canonical web static files used by inherited HTTP test; those exact parent files are now added without product changes. Original failed run preserved in author-native-v1.','reused_cli_cases':'Six exact source-stable CLI triples remain in author-native-v1; no new producer/renderer byte changed.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exit':result.returncode,'files':len(before),'source_unchanged':before==after}));print(result.stdout.decode());print(result.stderr.decode())
