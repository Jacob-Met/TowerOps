import fs from 'node:fs';import path from 'node:path';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);const {chromium}=require('/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright');
const root='/tmp/towerops-plan-html-066deeadcc8b/evidence';const out=path.join(root,'keyboard-diagnostic-v1');fs.mkdirSync(out);
const context=await chromium.launchPersistentContext(path.join(out,'profile'),{executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',headless:true,javaScriptEnabled:false,acceptDownloads:true,viewport:{width:1280,height:900},args:['--no-sandbox'],env:{...process.env,TMPDIR:'/tmp/tph-066deeadcc8b'}});
const observations=[];let error;
try{
 await context.setOffline(true);
 for(const label of ['crossing','policy-clock']){
  const page=await context.newPage();await page.goto(pathToFileURL(path.join(root,'author-browser-v3/detached',label+'.html')).href);
  await page.locator('.alternative > summary').last().click();
  const download=page.waitForEvent('download');await page.locator('#download-json').click();await(await download).saveAs(path.join(out,label+'.json'));
  await page.setViewportSize({width:375,height:900});await page.locator('#top').scrollIntoViewIfNeeded();
  const region=page.locator('#world .table-scroll');
  const states=[];
  async function record(phase){states.push(await region.evaluate((el,phase)=>({phase,left:el.scrollLeft,width:el.clientWidth,total:el.scrollWidth,active:document.activeElement===el,hasFocus:document.hasFocus(),visibility:document.visibilityState,rect:{y:el.getBoundingClientRect().y,height:el.getBoundingClientRect().height},windowY:scrollY}),phase));}
  await region.focus();await record('before-key');await page.keyboard.press('ArrowRight');
  for(let i=0;i<5;i++){await new Promise(r=>setTimeout(r,100));await record('after-key-'+i);}
  await page.bringToFront();await region.scrollIntoViewIfNeeded();await region.click({position:{x:20,y:20}});await region.focus();await record('before-explicit-focus-key');await page.keyboard.press('ArrowRight');
  for(let i=0;i<5;i++){await new Promise(r=>setTimeout(r,100));await record('after-explicit-focus-key-'+i);}
  await page.screenshot({path:path.join(out,label+'.png')});
  observations.push({label,states});await page.close();
 }
}catch(e){error=String(e);throw e;}finally{fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({observations,error},null,2)+'\n');await context.close();console.log(JSON.stringify({observations,error}));}
