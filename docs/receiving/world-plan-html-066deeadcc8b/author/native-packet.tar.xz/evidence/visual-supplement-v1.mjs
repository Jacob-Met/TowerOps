import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);const {chromium}=require('/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright');
const root='/tmp/towerops-plan-html-066deeadcc8b/evidence';const out=path.join(root,'visual-supplement-v1');fs.mkdirSync(out);
const file=path.join(root,'author-browser-v3/detached/crossing.html');const input=fs.readFileSync(file);
const ctx=await chromium.launchPersistentContext(path.join(out,'profile'),{executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',headless:true,javaScriptEnabled:false,viewport:{width:1280,height:900},args:['--no-sandbox'],env:{...process.env,TMPDIR:'/tmp/tph-066deeadcc8b'}});
const records=[];try{
 await ctx.setOffline(true);const page=await ctx.newPage();await page.goto(pathToFileURL(file).href);
 for(const width of [1280,375]){await page.setViewportSize({width,height:900});await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:path.join(out,'intro-'+width+'.png')});records.push({capture:'intro-'+width+'.png',geometry:await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollY}))});}
 await page.locator('.alternative>summary').first().click();const region=page.locator('.alternative .table-scroll').first();await page.bringToFront();await region.scrollIntoViewIfNeeded();await region.focus();
 for(let i=0;i<8;i++){await page.keyboard.press('ArrowRight');await new Promise(resolve=>setTimeout(resolve,60));}
 await page.screenshot({path:path.join(out,'alternative-proposed-375.png')});records.push({capture:'alternative-proposed-375.png',geometry:await region.evaluate(el=>({left:el.scrollLeft,width:el.clientWidth,total:el.scrollWidth,active:document.activeElement===el}))});
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify({input_file:file,input_sha256:crypto.createHash('sha256').update(input).digest('hex'),purpose:'Additional visual captures only; exact previously qualified document, no product rerun.',records},null,2)+'\n');console.log(JSON.stringify(records));
}finally{await ctx.close();}
