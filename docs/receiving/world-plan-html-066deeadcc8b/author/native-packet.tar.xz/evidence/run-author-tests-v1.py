import pathlib,subprocess,sys,hashlib,json,datetime,os
r=pathlib.Path('/home/jacob/towerops-plan-html-066deeadcc8b')
d=r/'evidence/author-tests-v1';d.mkdir(exist_ok=False)
source=r/'candidate'
manifest=lambda:{str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
before=manifest();(d/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
argv=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_world_plan_html.py','-v']
result=subprocess.run(argv,cwd=source,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=120,check=False)
(d/'stdout.txt').write_bytes(result.stdout);(d/'stderr.txt').write_bytes(result.stderr)
after=manifest();(d/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'argv':argv,'cwd':str(source),'returncode':result.returncode,'source_unchanged':before==after,'python':sys.version,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(result.stderr.decode())
