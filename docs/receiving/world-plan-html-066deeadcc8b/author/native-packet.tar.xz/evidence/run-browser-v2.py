from pathlib import Path
import subprocess,os,json,datetime,hashlib,shutil
r=Path('/tmp/towerops-plan-html-066deeadcc8b')
e=r/'evidence';assert shutil.disk_usage(r).free>536870912
argv=['/usr/bin/node',str(e/'author-browser-v2.mjs')]
result=subprocess.run(argv,cwd=r,capture_output=True,check=False,timeout=180,env={**os.environ,'TMPDIR':'/tmp/tph-066deeadcc8b'})
(e/'browser-command-v2.stdout').write_bytes(result.stdout);(e/'browser-command-v2.stderr').write_bytes(result.stderr)
row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(r),'returncode':result.returncode,'driver_sha256':hashlib.sha256((e/'author-browser-v2.mjs').read_bytes()).hexdigest(),'chrome':'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome','playwright':'/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright','free_bytes_after':shutil.disk_usage(r).free}
(e/'browser-command-v2.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));print(result.stdout.decode());print(result.stderr.decode())
