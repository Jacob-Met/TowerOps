import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);
const {chromium}=require('/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright');
const root='/tmp/towerops-plan-html-066deeadcc8b';
const evidence=path.join(root,'evidence');
const input=path.join(evidence,'author-native-v1');
const out=path.join(evidence,'author-browser-v3');
fs.mkdirSync(out);
fs.mkdirSync(path.join(out,'downloads'));
fs.mkdirSync(path.join(out,'detached'));
const native=JSON.parse(fs.readFileSync(path.join(input,'receipt.json'),'utf8'));
const fullGate=JSON.parse(fs.readFileSync(path.join(evidence,'author-native-v2/receipt.json'),'utf8'));
assert.equal(fullGate.returncode,0);
for(const file of ['plan_world.py','world_plan_html.py','tests/test_world_plan_html.py']){
 const previous=JSON.parse(fs.readFileSync(path.join(input,'source-before.json'),'utf8')).candidate[file];
 assert.equal(previous.sha256,fullGate.source_before[file].sha256);
}
const checks=[],requests=[],errors=[],downloads=[];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function check(name,condition,detail){checks.push({name,passed:!!condition,detail}); if(!condition)throw Error(name);}
let context;
try{
 context=await chromium.launchPersistentContext(path.join(out,'profile'),{
  executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',
  headless:true,javaScriptEnabled:false,acceptDownloads:true,
  viewport:{width:1280,height:900},deviceScaleFactor:1,
  args:['--no-sandbox','--no-first-run','--disable-dev-shm-usage'],
  env:{...process.env,TMPDIR:'/tmp/tph-066deeadcc8b'}
 });
 await context.setOffline(true);
 context.on('request',request=>requests.push(request.url()));
 await context.route('**/*',async route=>{
  const url=route.request().url();
  if(url.startsWith('file:')||url.startsWith('data:')) await route.continue();
  else {errors.push('unexpected network '+url);await route.abort();}
 });
 for(const row of native.cases){
  const original=fs.readFileSync(path.join(input,row.case+'-baseline.stdout'));
  const report=JSON.parse(original);
  const html=fs.readFileSync(path.join(input,row.case+'-html.stdout'));
  const file=path.join(out,'detached',row.case+'.html');fs.writeFileSync(file,html);
  const page=await context.newPage();
  page.on('pageerror',error=>errors.push(String(error)));
  await page.goto(pathToFileURL(file).href,{waitUntil:'load'});
  const source=await page.content();
  check(row.case+' no executable document resources',!(await page.locator('script,iframe,img,link,form').count()),null);
  const nodes=await page.locator('#alternatives .alternative').evaluateAll(elements=>elements.map(el=>({
   rank:el.getAttribute('data-rank'),id:el.getAttribute('data-aircraft-id'),
   body:el.querySelector('[data-field="advisory_json"]').textContent,
   rows:[...el.querySelectorAll('[data-component]')].map(tr=>({
    field:tr.getAttribute('data-component'),
    current:tr.querySelector('[data-value="current"] code').textContent,
    proposed:tr.querySelector('[data-value="proposed"] code').textContent
   }))
  })));
  check(row.case+' complete alternative order and bodies',
   JSON.stringify(nodes.map(n=>JSON.parse(n.body)))===JSON.stringify(report.advisories),nodes.length);
  const world=new Map(report.world.aircraft.map(a=>[a.aircraft_id,a]));
  nodes.forEach((node,index)=>{
   assert.equal(node.rank,String(index+1));assert.equal(node.id,report.advisories[index].aircraft_id);
   for(const cell of node.rows){
    assert.equal(Number(cell.current),world.get(node.id)[cell.field]);
    assert.equal(Number(cell.proposed),report.advisories[index]['set_'+cell.field]);
   }
  });
  check(row.case+' current/proposed component binding',true,nodes.length*3);
  for(const [key,value] of Object.entries(report.policy)){
   assert.equal(Number(await page.locator('[data-policy-field="'+key+'"]').textContent()),value);
  }
  check(row.case+' seven policy fields',true,Object.keys(report.policy).length);
  for(const key of ['world_hash','input_sha256','status','candidate_count','reviewed_at']){
   const expectedDisplay=typeof report[key]==='number' ? original.toString('utf8').match(new RegExp('^  "'+key+'": ([^,\\n]+)','m'))[1] : String(report[key]);
   assert.equal(await page.locator('#summary [data-field="'+key+'"] code').textContent(),expectedDisplay);
  }
  check(row.case+' identity and clocks',true,null);
  if(nodes.length){
   const first=page.locator('.alternative > summary').first();
   await first.focus();await page.keyboard.press('Enter');
   check(row.case+' keyboard opens native disclosure',await page.locator('.alternative').first().getAttribute('open')!==null,null);
   await page.keyboard.press('Space');
   check(row.case+' keyboard closes native disclosure',await page.locator('.alternative').first().getAttribute('open')===null,null);
   await page.locator('.alternative > summary').last().click();
   check(row.case+' last alternative inspectable',await page.locator('.alternative').last().getAttribute('open')!==null,nodes.length);
  } else {
   check(row.case+' explicit empty alternatives',await page.locator('#empty-alternatives').count()===1,report.status);
  }
  const downloadPromise=page.waitForEvent('download');
  await page.locator('#download-json').click();
  const download=await downloadPromise;const dest=path.join(out,'downloads',row.case+'.json');
  await download.saveAs(dest);const got=fs.readFileSync(dest);
  check(row.case+' exact actual download',got.equals(original),{bytes:got.length,sha256:sha(got)});
  downloads.push({case:row.case,filename:download.suggestedFilename(),bytes:got.length,sha256:sha(got)});
  await page.setViewportSize({width:375,height:900});
  await page.locator('#top').scrollIntoViewIfNeeded();
  const geometry=await page.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
  check(row.case+' narrow document fits',geometry.document<=375&&geometry.body<=375,geometry);
  const region=page.locator('#world .table-scroll');
  await region.focus();await page.keyboard.press('ArrowRight');
  await page.waitForFunction(()=>document.querySelector('#world .table-scroll').scrollLeft>0);
  check(row.case+' narrow table keyboard scroll',await region.evaluate(el=>el.scrollLeft>0),null);
  if(row.case==='crossing'||row.case==='sixty-flight'){
   await page.locator('#top').scrollIntoViewIfNeeded();
   await page.screenshot({path:path.join(out,row.case+'-375.png')});
   if(nodes.length){
    await page.locator('.alternative > summary').first().click();
    await page.locator('.alternative').first().scrollIntoViewIfNeeded();
    await page.screenshot({path:path.join(out,row.case+'-alternative-375.png')});
   }
  }
  check(row.case+' original HTML remains exact',fs.readFileSync(file).equals(html),sha(html));
  await page.close();
 }
 check('all documents offline and error-free',errors.length===0,errors);
 const metadata={node:process.version,playwright:require('/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright/package.json').version,browser:context.browser()?.version()??'persistent',javaScriptEnabled:false};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({passed:true,checks,downloads,requests,errors,metadata},null,2)+'\n');
 console.log(JSON.stringify({passed:true,checks:checks.length,downloads:downloads.length,errors}));
}catch(error){
 fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({passed:false,error:String(error),stack:error.stack,checks,downloads,requests,errors},null,2)+'\n');
 throw error;
}finally{if(context)await context.close();}
