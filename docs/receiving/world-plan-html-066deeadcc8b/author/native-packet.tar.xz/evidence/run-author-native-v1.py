from pathlib import Path
import ast,base64,datetime,hashlib,importlib.metadata,json,os,shutil,subprocess,sys
r=Path('/tmp/towerops-plan-html-066deeadcc8b')
out=r/'evidence/author-native-v1';out.mkdir()
tmp=out/'tmp';tmp.mkdir()
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(tmp)}
def manifest(root):
 return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and not any(x in p.parts for x in ['__pycache__','.pytest_cache'])}
before={name:manifest(r/name) for name in ['baseline','candidate']}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[]
def run(label,argv,cwd,input=None):
 result=subprocess.run(argv,cwd=cwd,input=input,capture_output=True,check=False,env=env,timeout=180)
 (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
 row={'label':label,'argv':list(map(str,argv)),'cwd':str(cwd),'returncode':result.returncode,'stdout_bytes':len(result.stdout),'stderr_bytes':len(result.stderr)}
 commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return result
assert shutil.disk_usage(r).free>536870912
suite=run('pytest',[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider'],r/'candidate')
print('FULL_SUITE',suite.returncode,flush=True)
base=json.loads((r/'evidence/original-world.json').read_text())
cases=[]
cases.append(('crossing',base,[]))
cases.append(('policy-clock',base,['--now','125','--horizontal-nm','3','--vertical-ft','800','--horizon-min','4']))
cases.append(('empty',{'version':0,'observed_at':0,'aircraft':[]},[]))
overlap=json.loads(json.dumps(base))
for f in overlap['aircraft']:
 f.update(x_nm=0,y_nm=0,vx_nm_min=0,vy_nm_min=0,climb_ft_min=0)
cases.append(('no-option',overlap,[]))
signed=json.loads(json.dumps(base));signed['aircraft'][0]['aircraft_id']='a';signed['aircraft'][1]['aircraft_id']='A';signed['aircraft'][0]['vy_nm_min']=-0.0
cases.append(('case-signed-zero',signed,[]))
rows=[]
for i in range(60):
 rows.append({'aircraft_id':f'F{i:02d}','x_nm':i*1000,'y_nm':i*2000,'altitude_ft':12000,'vx_nm_min':0,'vy_nm_min':0,'climb_ft_min':0})
cases.append(('sixty-flight',{'version':2,'observed_at':120,'aircraft':rows},[]))
checks=[]
for label,world,flags in cases:
 raw=(json.dumps(world,ensure_ascii=False,indent=2)+'\n').encode()
 source=out/(label+'.world.json');source.write_bytes(raw)
 old=run(label+'-baseline',[sys.executable,'-B','plan_world.py',str(source),*flags],r/'baseline')
 new=run(label+'-candidate',[sys.executable,'-B','plan_world.py',str(source),*flags],r/'candidate')
 html=run(label+'-html',[sys.executable,'-B','plan_world.py',str(source),'--html',*flags],r/'candidate')
 assert (old.returncode,new.returncode,html.returncode)==(0,0,0),label
 assert old.stdout==new.stdout,label
 text=html.stdout.decode();mark='href="data:application/json;charset=utf-8;base64,';start=text.index(mark)+len(mark);end=text.index('"',start)
 embedded=base64.b64decode(text[start:end],validate=True);assert embedded==old.stdout,label
 assert source.read_bytes()==raw,label
 data=json.loads(old.stdout);checks.append({'case':label,'status':data['status'],'admitted':len(data['advisories']),'candidates':data['candidate_count'],'json_sha256':hashlib.sha256(old.stdout).hexdigest(),'html_sha256':hashlib.sha256(html.stdout).hexdigest(),'exact_baseline_json':True,'exact_download':True})
 print('CASE',label,'PASSED',flush=True)
functions={}
for name in ['baseline','candidate']:
 text=(r/name/'plan_world.py').read_text();tree=ast.parse(text)
 functions[name]={n.name:ast.get_source_segment(text,n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='main'}
assert functions['baseline']==functions['candidate']
after={name:manifest(r/name) for name in ['baseline','candidate']}
assert before==after
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'pytest':importlib.metadata.version('pytest'),'full_suite_exit':suite.returncode,'all_non_main_producer_definitions_exact':list(functions['baseline']),'cases':checks,'source_unchanged':before==after,'commands':commands}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(suite.returncode)
