import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const [inputPath,outputPath]=process.argv.slice(2);
if(!inputPath||!outputPath)throw Error('Usage: receive_browser.mjs browser-input.json NEW_OUTPUT');
if(fs.existsSync(outputPath))throw Error('Fresh output required');
fs.mkdirSync(outputPath,{recursive:true});
const input=JSON.parse(fs.readFileSync(inputPath,'utf8'));
if(!input.cases.length||input.cases.some(x=>!x.html))throw Error('Actual generated HTML required');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const pin=b=>({bytes:b.length,sha256:hash(b)});
const write=(name,x)=>fs.writeFileSync(path.join(outputPath,name),JSON.stringify(x,null,2)+'\n');
const originals={};
for(const c of input.cases)for(const p of [c.html,c.json,c.expected])originals[p]=pin(fs.readFileSync(p));
fs.mkdirSync('/tmp/tpr-066deeadcc8b',{recursive:true});
process.env.TMPDIR='/tmp/tpr-066deeadcc8b';
const playwrightPath='/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright/index.mjs';
const executablePath='/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome';
const {chromium}=await import(pathToFileURL(playwrightPath).href);
const report={started_at:new Date().toISOString(),node:process.version,playwrightPath,executablePath,inputPath,source_files:originals,positive:[],negative:[],application_errors:[],network_attempts:[]};
let browser;
const failed=x=>x.checks.filter(y=>!y.pass);
async function receive(c,width,mutation=null){
 const name=c.name+'-'+width+(mutation?'-'+mutation:'');
 const folder=path.join(outputPath,name);fs.mkdirSync(folder);
 const expected=JSON.parse(fs.readFileSync(c.expected,'utf8')),raw=fs.readFileSync(c.json);
 const result={name,width,mutation,source_html:c.html,source_json:c.json,attribution:c.attribution||'Actual CLI output',checks:[],requests:[],errors:[]};
 const check=(label,ok,detail)=>result.checks.push({label,pass:!!ok,...(detail===undefined?{}:{detail})});
 const context=await browser.newContext({viewport:{width,height:960},javaScriptEnabled:false,acceptDownloads:true});
 await context.route(/^https?:\/\//,async route=>{result.requests.push({blocked:true,url:route.request().url()});await route.abort();});
 const page=await context.newPage();
 page.on('pageerror',e=>result.errors.push(String(e)));
 page.on('request',r=>{if(/^https?:/.test(r.url()))result.requests.push({event:true,url:r.url()});});
 try{
  await page.goto(pathToFileURL(c.html).href,{waitUntil:'load',timeout:15000});
  await page.bringToFront();
  if(mutation==='drop-last-alternative')await page.locator('#alternatives .alternative').last().evaluate(n=>n.remove());
  if(mutation==='wrong-json-download')await page.locator('#download-json').evaluate((n,href)=>n.setAttribute('href',href),'data:application/json;base64,'+Buffer.concat([raw,Buffer.from(' ')]).toString('base64'));
  const observed=await page.evaluate(()=>{
   const scalar=n=>n.querySelector('code')?.textContent??n.textContent;
   const values=(root,selector,key)=>Object.fromEntries([...root.querySelectorAll(selector)].map(n=>[n.getAttribute(key),scalar(n)]));
   return {
    title:document.title,lang:document.documentElement.lang,
    summary:values(document.querySelector('#summary'),'dd[data-field]','data-field'),
    policy:values(document.querySelector('#policy'),'dd[data-policy-field]','data-policy-field'),
    world:[...document.querySelectorAll('#world tbody tr[data-aircraft-id]')].map(n=>({aircraft_id:n.getAttribute('data-aircraft-id'),fields:values(n,'td[data-field]','data-field')})),
    options:[...document.querySelectorAll('#alternatives .alternative')].map(n=>({
     rank:Number(n.getAttribute('data-rank')),id:n.id,aircraft_id:n.getAttribute('data-aircraft-id'),tag:n.tagName,
     metadata:values(n,'dl dd[data-field]','data-field'),
     components:Object.fromEntries([...n.querySelectorAll('tr[data-component]')].map(tr=>[tr.getAttribute('data-component'),values(tr,'td[data-value]','data-value')])),
     advisory_json:n.querySelector('pre[data-field="advisory_json"]')?.textContent,
     summary:n.querySelector('summary')?.textContent
    })),
    report_json:document.querySelector('#report-json pre')?.textContent,
    download_href:document.querySelector('#download-json')?.getAttribute('href'),
    download_name:document.querySelector('#download-json')?.getAttribute('download'),
    body_text:document.body.textContent,
    empty_message:document.querySelector('#alternatives')?.textContent,
    scripts:document.scripts.length,interpreted_markers:document.querySelectorAll('#tower-receiver-markup,#tower-receiver-script').length,
    document_width:document.documentElement.scrollWidth,viewport_width:innerWidth
   };
  });
  fs.writeFileSync(path.join(folder,'observed.json'),JSON.stringify(observed,null,2)+'\n');
  check('meaningful document title',!!observed.title&&observed.title.length>8,observed.title);
  check('language declared',observed.lang==='en',observed.lang);
  for(const [k,v]of Object.entries(expected.summary))check('summary '+k,observed.summary[k]===v,{expected:v,actual:observed.summary[k]});
  for(const[k,v]of Object.entries(expected.world_metadata))check('world metadata '+k,observed.summary[k]===v,{expected:v,actual:observed.summary[k]});
  check('conflicting identity list',observed.summary.conflicting_aircraft===expected.conflicting_aircraft,{expected:expected.conflicting_aircraft,actual:observed.summary.conflicting_aircraft});
  check('admitted count',observed.summary.admitted_count===expected.admitted_count);
  check('world row count',observed.world.length===expected.world.length);
  for(let i=0;i<observed.world.length;i++){
   const a=observed.world[i],e=expected.world[i];if(!e){check('unexpected world row',false,a);continue;}
   check('world '+i+' identity/order',a.aircraft_id===e.aircraft_id);
   check('world '+i+' seven fields',Object.keys(a.fields).length===7);
   for(const[k,v]of Object.entries(e.fields))check('world '+i+' '+k,a.fields[k]===v,{expected:v,actual:a.fields[k]});
  }
  check('complete policy fields',Object.keys(observed.policy).length===7);
  for(const[k,v]of Object.entries(expected.policy))check('policy '+k,observed.policy[k]===v,{expected:v,actual:observed.policy[k]});
  check('ordered alternative count',observed.options.length===expected.options.length,{expected:expected.options.length,actual:observed.options.length});
  for(let i=0;i<observed.options.length;i++){
   const a=observed.options[i],e=expected.options[i];if(!e){check('unexpected alternative',false,a);continue;}
   check('alternative '+i+' rank and native disclosure',a.rank===e.rank&&a.id==='alternative-'+e.rank&&a.tag==='DETAILS');
   check('alternative '+i+' exact target',a.aircraft_id===e.aircraft_id);
   for(const k of ['advisory_hash','world_hash','issued_at','expires_at','rationale'])check('alternative '+i+' '+k,a.metadata[k]===e.fields[k],{expected:e.fields[k],actual:a.metadata[k]});
   for(const[k,values]of Object.entries(e.components))for(const key of ['current','proposed'])check('alternative '+i+' '+k+' '+key,a.components[k]?.[key]===values[key],{expected:values[key],actual:a.components[k]?.[key]});
   check('alternative '+i+' complete logical body',a.advisory_json===e.returned_body);
  }
  check('complete original source text',observed.report_json===expected.report_text);
  check('no application scripts',observed.scripts===0);
  check('supplied markup remains literal',observed.interpreted_markers===0);
  check('no horizontal document overflow',observed.document_width<=observed.viewport_width+1,{width:observed.document_width,viewport:observed.viewport_width});
  const text=observed.body_text.replace(/\s+/g,' ');
  for(const [label,pattern]of [
   ['simulation disclosure',/simulat/i],['individual screening disclosure',/individual.{0,35}screen|screen.{0,35}individual/i],
   ['mutually exclusive alternatives disclosure',/mutually exclusive|not.{0,35}(simultaneous|batch)/i],
   ['no approval or actuation disclosure',/(not|no).{0,80}(approval|actuat|readback)/i],
   ['not complete-world resolution disclosure',/(not|does not).{0,120}(resolv|every.{0,30}conflict|all.{0,30}conflict)/i]
  ])check(label,pattern.test(text));
  if(expected.options.length){
   check('horizontal rate unit visible',text.includes('nm/min'));
   check('vertical rate unit visible',text.includes('ft/min'));
  }else{
   const wording=(observed.empty_message||'').replace(/\s+/g,' ');
   check('meaningful distinct empty outcome',expected.status==='no_conflict'?/no.{0,35}conflict|no.{0,35}candidate/i.test(wording):/no.{0,35}(admitt|option|alternative)|none.{0,35}(pass|screen)/i.test(wording),wording);
   result.empty_message=wording;
  }
  const url=observed.download_href||'';
  const match=/^data:application\/json(?:;charset=[^;,]+)?;base64,([\s\S]+)$/.exec(url);
  check('native JSON download link',!!match&&!!observed.download_name&&observed.download_name.endsWith('.json'));
  check('embedded download bytes',!!match&&Buffer.from(match[1],'base64').equals(raw));
  const [download]=await Promise.all([page.waitForEvent('download',{timeout:15000}),page.locator('#download-json').click()]);
  await download.saveAs(path.join(folder,'download.json'));
  const downloaded=fs.readFileSync(path.join(folder,'download.json'));
  result.download={suggested_filename:download.suggestedFilename(),...pin(downloaded)};
  check('actual download bytes',downloaded.equals(raw),{expected:pin(raw),actual:pin(downloaded)});
  if(!mutation){
   if(expected.options.length){
    const last='#alternative-'+expected.options.length;
    await page.locator(last+' > summary').focus();
    await page.keyboard.press('Enter');
    check('native keyboard disclosure opens',await page.locator(last).evaluate(n=>n.open));
    check('opened full body visible',await page.locator(last+' pre[data-field="advisory_json"]').isVisible());
    await page.goto(pathToFileURL(c.html).href+'#alternative-'+expected.options.length,{waitUntil:'load'});
    check('native deep anchor retained',new URL(page.url()).hash==='#alternative-'+expected.options.length);
   }
   if(width===375&&expected.world.length){
    const state=await page.evaluate(()=>{
     let n=document.querySelector('#world table')||document.querySelector('#world');
     while(n){
      if(n.scrollWidth>n.clientWidth+1&&/auto|scroll/.test(getComputedStyle(n).overflowX)){
       n.dataset.receiverScroller='world';n.scrollLeft=0;n.focus();
       return {found:true,tabindex:n.tabIndex,active:document.activeElement===n,scroll:n.scrollLeft,range:n.scrollWidth-n.clientWidth};
      }
      n=n.parentElement;
     }
     return {found:false};
    });
    check('wide world table has keyboard scroll container',state.found&&state.tabindex>=0&&state.active,state);
    if(state.found){
     await page.bringToFront();await page.keyboard.press('ArrowRight');
     let scroll=0;
     for(let i=0;i<25;i++){scroll=await page.locator('[data-receiver-scroller="world"]').evaluate(n=>n.scrollLeft);if(scroll>0)break;await new Promise(resolve=>setTimeout(resolve,80));}
     check('actual keyboard scroll advances',scroll>0,{before:0,after:scroll});
    }
   }
   if(['crossing','typed-policy','empty-world','renderer-literals'].includes(c.name)){
    await page.evaluate(()=>{document.documentElement.style.scrollBehavior='auto';window.scrollTo(0,0);});
    await page.screenshot({path:path.join(folder,'viewport.png'),fullPage:false});
   }
   if(c.name==='crossing'&&width===1280){
    await page.emulateMedia({media:'print'});
    check('print summary remains visible',await page.locator('#summary').isVisible());
    await page.screenshot({path:path.join(folder,'print-viewport.png'),fullPage:false});
   }
  }else{
   fs.writeFileSync(path.join(folder,'mutated-document.html'),await page.content());
  }
  check('no page exceptions',result.errors.length===0,result.errors);
  check('no network attempts',result.requests.length===0,result.requests);
 }catch(error){result.fatal=String(error);check('browser receiving completes',false,String(error));}
 finally{
  await context.close();
  result.totals={passed:result.checks.filter(x=>x.pass).length,failed:failed(result).length};
  fs.writeFileSync(path.join(folder,'report.json'),JSON.stringify(result,null,2)+'\n');
 }
 return result;
}
try{
 browser=await chromium.launch({executablePath,headless:true,args:['--disable-dev-shm-usage']});
 report.browser_version=browser.version();
 for(const c of input.cases)report.positive.push(await receive(c,375));
 report.positive.push(await receive(input.cases.find(x=>x.name==='crossing'),1280));
 for(const mutation of ['drop-last-alternative','wrong-json-download']){
  const result=await receive(input.cases.find(x=>x.name==='crossing'),375,mutation);
  const failures=failed(result);
  const allowed=mutation==='drop-last-alternative'?['ordered alternative count']:['embedded download bytes','actual download bytes'];
  result.negative_control_rejected=failures.length>0&&!result.fatal&&failures.every(x=>allowed.includes(x.label))&&allowed.every(x=>failures.some(f=>f.label===x));
  report.negative.push(result);
 }
 const empty=report.positive.filter(x=>x.empty_message);
 report.empty_outcomes_distinct=new Set(empty.map(x=>x.empty_message)).size>=2;
}catch(error){report.fatal=String(error);}
finally{
 if(browser)await browser.close();
 report.source_after=Object.fromEntries(Object.keys(originals).map(p=>[p,pin(fs.readFileSync(p))]));
 report.source_unchanged=JSON.stringify(report.source_after)===JSON.stringify(originals);
 report.ended_at=new Date().toISOString();
 report.totals={views:report.positive.length,checks:report.positive.reduce((n,x)=>n+x.checks.length,0),failed:report.positive.reduce((n,x)=>n+failed(x).length,0),actual_downloads:[...report.positive,...report.negative].filter(x=>x.download).length,negative_controls:report.negative.length,negative_controls_rejected:report.negative.filter(x=>x.negative_control_rejected).length};
 report.accepted=!report.fatal&&report.source_unchanged&&report.empty_outcomes_distinct&&report.totals.failed===0&&report.totals.negative_controls_rejected===2;
 write('report.json',report);
 console.log(JSON.stringify({accepted:report.accepted,...report.totals}));
}
process.exitCode=report.accepted?0:1;
