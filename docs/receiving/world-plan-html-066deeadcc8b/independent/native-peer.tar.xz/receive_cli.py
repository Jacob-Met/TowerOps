#!/usr/bin/env python3
"""Independently authored pre-inspection CLI receiving for TowerOps HTML."""
from pathlib import Path
import argparse,copy,hashlib,json,os,subprocess,sys,time

def pin(data):
 return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
def snapshot(root):
 return {p.relative_to(root).as_posix():pin(p.read_bytes()) for p in sorted(root.rglob("*")) if p.is_file()}
def aircraft(identity,x,y=0,altitude=12000,vx=0,vy=0,climb=0):
 return {"aircraft_id":identity,"x_nm":x,"y_nm":y,"altitude_ft":altitude,"vx_nm_min":vx,"vy_nm_min":vy,"climb_ft_min":climb}
def world(rows,version=7,observed=120.0):return {"version":version,"observed_at":observed,"aircraft":rows}
def fixture_cases():
 crossing=world([aircraft("EAST",-8.0,1.0,12000.0,2.0,0.0,0.0),aircraft("WEST",8.0,1.0,12000.0,-2.0,0.0,0.0)])
 typed=world([aircraft("a",-8.0,-0.0,12000,2,-0.0,-0.0),aircraft("A",8.0,0,12000.0,-2.0,0,0)],9007199254740991,100.0)
 four=world([aircraft("PAIR_A",-8,0,12000,2),aircraft("PAIR_B",8,0,12000,-2),aircraft("PAIR_C",-8,100,12000,2),aircraft("PAIR_D",8,100,12000,-2)])
 return [
  {"name":"crossing","world":crossing,"flags":[],"status":"options_available"},
  {"name":"stdin-crossing","world":crossing,"flags":[],"status":"options_available","stdin":True},
  {"name":"typed-policy","world":typed,"flags":["--now","105.0","--horizontal-nm","3.5","--vertical-ft","800","--horizon-min","4.0"],"status":"options_available"},
  {"name":"two-independent-conflicts","world":four,"flags":[],"status":"options_available"},
  {"name":"single-literal-numbers","world":world([aircraft("ONLY",1000000000000,1e-9,9000.0,-0.0,0,0)]),"flags":[],"status":"no_conflict"},
  {"name":"empty-world","world":world([]),"flags":[],"status":"no_conflict"},
  {"name":"no-admitted-option","world":world([aircraft("ONE",0,0,12000,0),aircraft("TWO",0,0,12000,0)]),"flags":[],"status":"no_admitted_option"},
 ]
def scalar(value):
 return value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(",",":"))
def expected_view(report,raw):
 rows=report["world"]["aircraft"]; by_id={a["aircraft_id"]:a for a in rows}
 options=[]
 for rank,item in enumerate(report["advisories"],1):
  current=by_id[item["aircraft_id"]]
  options.append({"rank":rank,"aircraft_id":item["aircraft_id"],"fields":{k:scalar(v) for k,v in item.items()},"logical_body":json.dumps({k:v for k,v in item.items() if k!="advisory_hash"},ensure_ascii=False,indent=2),"returned_body":json.dumps(item,ensure_ascii=False,indent=2),"components":{k:{"current":scalar(current[k]),"proposed":scalar(item["set_"+k])} for k in ("vx_nm_min","vy_nm_min","climb_ft_min")}})
 return {"json_sha256":hashlib.sha256(raw).hexdigest(),"json_bytes":len(raw),"report_text":raw.decode(),"status":report["status"],"world":[{"aircraft_id":a["aircraft_id"],"fields":{k:scalar(v) for k,v in a.items()}} for a in rows],"policy":{k:scalar(v) for k,v in report["policy"].items()},"summary":{k:scalar(report[k]) for k in ("status","input_sha256","world_hash","reviewed_at","candidate_count")},"world_metadata":{k:scalar(report["world"][k]) for k in ("version","observed_at")},"conflicting_aircraft":json.dumps(report["conflicting_aircraft"],ensure_ascii=False),"admitted_count":str(len(options)),"options":options}
def main():
 parser=argparse.ArgumentParser();parser.add_argument("mode",choices=["baseline","candidate"]);parser.add_argument("source",type=Path);parser.add_argument("output",type=Path);parser.add_argument("--reference",type=Path)
 args=parser.parse_args();source=args.source.resolve();out=args.output.resolve()
 if out.exists():raise ValueError("Fresh output directory required")
 out.mkdir(parents=True)
 report={"mode":args.mode,"source":str(source),"python":sys.version,"started_at":time.time(),"checks":[],"processes":[],"source_before":snapshot(source),"candidate_inspection":"Driver criteria authored before candidate source inspection; candidate may already exist."}
 def check(label,ok,detail=None):
  report["checks"].append({"label":label,"pass":bool(ok),"detail":detail})
 def run(label,argv,input_bytes=None,closed_output=False):
  folder=out/label;folder.mkdir(parents=True)
  start=time.time();env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1"
  if closed_output:
   rd,wr=os.pipe();os.close(rd)
   try:p=subprocess.run(argv,input=input_bytes,stdout=wr,stderr=subprocess.PIPE,cwd=source,env=env,timeout=30)
   finally:os.close(wr)
   stdout=b""
  else:
   p=subprocess.run(argv,input=input_bytes,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=source,env=env,timeout=30);stdout=p.stdout
  (folder/"stdout").write_bytes(stdout);(folder/"stderr").write_bytes(p.stderr)
  meta={"label":label,"argv":argv,"stdin":pin(input_bytes) if input_bytes is not None else None,"returncode":p.returncode,"started_at":start,"ended_at":time.time(),"closed_output":closed_output,"stdout":pin(stdout),"stderr":pin(p.stderr)}
  dump(folder/"process.json",meta);report["processes"].append(meta)
  return p.returncode,stdout,p.stderr,folder
 try:
  fixtures=out/"inputs";fixtures.mkdir()
  successful=[]
  for case in fixture_cases():
   raw=(json.dumps(case["world"],ensure_ascii=False,indent=2,allow_nan=False)+"\n").encode()
   path=fixtures/(case["name"]+".json");path.write_bytes(raw)
   arg="-" if case.get("stdin") else str(path)
   cmd=[sys.executable,"-B",str(source/"plan_world.py"),arg,*case["flags"]]
   rc,stdout,stderr,folder=run(case["name"]+"-json",cmd,raw if case.get("stdin") else None)
   check(case["name"]+" native JSON succeeds",rc==0 and not stderr,{"rc":rc,"stderr":stderr.decode(errors="replace")})
   data=json.loads(stdout);check(case["name"]+" status",data["status"]==case["status"],data["status"])
   check(case["name"]+" exact input identity",data["input_sha256"]==hashlib.sha256(raw).hexdigest())
   check(case["name"]+" source world identity",data["world"]["version"]==case["world"]["version"] and data["world"]["observed_at"]==case["world"]["observed_at"] and {a["aircraft_id"]:a for a in data["world"]["aircraft"]}=={a["aircraft_id"]:a for a in case["world"]["aircraft"]})
   check(case["name"]+" complete seven-value policy",len(data["policy"])==7)
   check(case["name"]+" original serialized bytes",stdout==(json.dumps(data,ensure_ascii=False,allow_nan=False,indent=2)+"\n").encode())
   check(case["name"]+" input untouched",path.read_bytes()==raw)
   expectation=expected_view(data,stdout);dump(folder/"expected-view.json",expectation)
   successful.append({"name":case["name"],"json":str(folder/"stdout"),"expected":str(folder/"expected-view.json")})
   if args.mode=="candidate":
    prior=(args.reference/(case["name"]+"-json")/"stdout").read_bytes()
    check(case["name"]+" baseline JSON remains byte exact",stdout==prior)
    hrc,html,hstderr,hfolder=run(case["name"]+"-html",cmd+["--html"],raw if case.get("stdin") else None)
    check(case["name"]+" HTML succeeds",hrc==0 and not hstderr,{"rc":hrc,"stderr":hstderr.decode(errors="replace")})
    check(case["name"]+" standalone HTML",html.lstrip().lower().startswith(b"<!doctype html"))
    (hfolder/"report.html").write_bytes(html)
    successful[-1]["html"]=str(hfolder/"report.html")
   elif case["name"] in ("crossing","empty-world","no-admitted-option"):
    arc,absent,err,afolder=run(case["name"]+"-absent-html",cmd+["--html"],raw if case.get("stdin") else None)
    check(case["name"]+" baseline capability absent",arc==2 and absent==b"" and b"--html" in err)
  if args.mode=="candidate":
   original=json.loads((out/"crossing-json"/"stdout").read_bytes())
   original["advisories"]=copy.deepcopy(original["advisories"][:2])
   hostile='  Receiver <img id="tower-receiver-markup" src="https://invalid.invalid/no-request"> & </pre><script id="tower-receiver-script">globalThis.bad=1</script> Ω ☃\nline 2  '
   original["advisories"][0]["rationale"]=hostile
   raw=(json.dumps(original,ensure_ascii=False,indent=2,allow_nan=False)+"\n").encode()
   path=fixtures/"renderer-literals-report.json";path.write_bytes(raw)
   call="from pathlib import Path;import sys;from world_plan_html import render_plan_html;sys.stdout.write(render_plan_html(Path(sys.argv[1]).read_text()))"
   rc,html,stderr,folder=run("renderer-literals",[sys.executable,"-B","-c",call,str(path)])
   check("controlled literal renderer API succeeds",rc==0 and not stderr,{"rc":rc,"stderr":stderr.decode(errors="replace")})
   check("controlled renderer input retained",path.read_bytes()==raw)
   (folder/"report.html").write_bytes(html);(folder/"report.json").write_bytes(raw)
   dump(folder/"expected-view.json",expected_view(original,raw))
   successful.append({"name":"renderer-literals","json":str(folder/"report.json"),"expected":str(folder/"expected-view.json"),"html":str(folder/"report.html"),"attribution":"Controlled renderer-only string variant, not an admitted native world or a valid advisory hash."})
  refusals=[
   ("malformed",b"{",[],2),
   ("late-invalid",json.dumps(world([aircraft("GOOD",0),{**aircraft("LATE",8),"unsupported":True}])).encode(),[],2),
   ("stale-empty",json.dumps(world([],observed=100)).encode(),["--now","111"],1),
   ("oversize",b" "*262145,[],2),
   ("zero-policy",json.dumps(world([])).encode(),["--horizontal-nm","0"],2),
  ]
  for name,raw,flags,wanted in refusals:
   path=fixtures/(name+".json");path.write_bytes(raw)
   cmd=[sys.executable,"-B",str(source/"plan_world.py"),str(path),*flags]+(["--html"] if args.mode=="candidate" else [])
   rc,stdout,stderr,folder=run("refusal-"+name,cmd)
   check(name+" refuses without stdout",rc==wanted and not stdout and bool(stderr),{"rc":rc,"stderr":stderr.decode(errors="replace")})
   check(name+" source bytes retained",path.read_bytes()==raw)
  pipe_case=fixtures/"crossing.json"
  rc,stdout,stderr,folder=run("closed-output",[sys.executable,"-B",str(source/"plan_world.py"),str(pipe_case)]+(["--html"] if args.mode=="candidate" else []),closed_output=True)
  check("closed output fails instead of success",rc==2 and b"cannot write report" in stderr,{"rc":rc,"stderr":stderr.decode(errors="replace")})
  report["successful_cases"]=successful
  dump(out/"browser-input.json",{"cases":successful,"mode":args.mode})
 except BaseException as error:
  report["fatal"]=repr(error);check("receiver completes",False,repr(error))
 finally:
  report["source_after"]=snapshot(source);check("all source bytes unchanged",report["source_before"]==report["source_after"])
  report["ended_at"]=time.time();report["totals"]={"passed":sum(x["pass"] for x in report["checks"]),"failed":sum(not x["pass"] for x in report["checks"]),"processes":len(report["processes"])}
  dump(out/"report.json",report)
 print(json.dumps(report["totals"]),flush=True)
 return int(report["totals"]["failed"]>0)
if __name__=="__main__":raise SystemExit(main())
