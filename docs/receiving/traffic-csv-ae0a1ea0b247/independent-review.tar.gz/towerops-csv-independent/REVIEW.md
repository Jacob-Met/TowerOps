# Independent TowerOps CSV receiving — ACCEPT

Baseline: `53aa5048b6585aa08592d5513cfcf555a8bba018`.
Accepted converter: `c20ad8c93ac06f882bc6630f755559499fdf3f7d`.
Accepted guide: `1b385503aa027e396ea815fad98235b63fdb89f2`.
Source scope: [TowerOps issue 52](https://github.com/Jacob-Met/TowerOps/issues/52).

This reviewer authored the receiving fixture and driver, not the converter. The expectations and complete driver were frozen after reading the current native source and before candidate disclosure. A separate actual baseline planner invocation validated the independently constructed expected world before the converter arrived.

## Source disposition

The new module parses bounded UTF-8 CSV with exact headers and explicit native numeric fields, then calls the unchanged `plan_world.parse_world` on the complete world. It never normalizes IDs or replaces world admission. It emits `WorldState.to_dict()` after all rows and metadata have been admitted; failures return before that write. Its handling of an output failure is distinct from the all-input-before-output admission boundary.

The native dependencies are exact baseline bytes:

- `plan_world.py`: `8e826a10cc2f9425de26727dce07851497174bba`.
- `towerops.py`: `3f541e5f0f3a05dac9d12c96e75d3d69ef3377d1`.
- `advisory_options.py`: `2cb3bb564559fb2fa2b20d9a215b4cb99badecbd`.

The README has one additive seven-line section pointing to the new guide. The guide correctly distinguishes raw world data, the native planner's later policy review and complete saved-scenario state. No new planner, policy, model, dependency, approval or UI behavior was introduced in the reviewed source.

## Actual independent receiving

Four groups passed in one run, using seven actual Python child processes:

1. An all-quoted, CRLF, BOM-prefixed spreadsheet with reordered headers preserves independently specified values, case-sensitive ID ordering, integer-versus-float types, signed zero, a tiny finite exponent, the numeric bound and the maximum native version.
2. The same authored rows and columns in a different order, received on stdin, produce byte-identical JSON.
3. The unchanged native planner receives those actual output bytes and returns the exact independently expected world and hash, preserved observation metadata, `no_conflict`, zero candidate advisories and the existing proposal-only flags.
4. Valid-prefix sheets with a late duplicate exact ID, boolean numeric cell, nonfinite exponent or invalid UTF-8 each return exit 2, empty stdout and a controlled diagnostic. Every input file and reviewed source byte remains unchanged.

Expected native world hash:
`fddfc5a2429219fbfec71a7804874b13677615aea5fc42068854b140fe5c0a20`.

The receiving receipt is `results/independent-receipt.json`; original sheets, exact CLI stdout/stderr, the expected world and native planner output are retained beside it. Source pins, pre-candidate expectations, driver, baseline-control output and setup-retention failure are also retained. The first attempted shared expectation write hit ENOSPC before tests; the private-scope source and results were subsequently written and read back into the allocated archive. No failed behavior test or implementation correction occurred in this independent review.

## Scope of acceptance

This is source/native consumer acceptance for the exact listed blobs. Existing broader model and admission qualifications are reused; this reviewer did not duplicate the author's broad suite or run a browser. All traffic is an authored local fixture. No external service, actual aircraft, live control state or operational assurance is involved. Publication and current-parent preservation remain separate native integration steps.
