from pathlib import Path
import ast,hashlib,json,subprocess,sys
root=Path(sys.argv[1])
tree=ast.parse((root/"independent_review.py").read_text())
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="expected" for t in n.targets))
expected=ast.literal_eval(node.value)
raw=json.dumps(expected,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
result=subprocess.run([sys.executable,"-B",str(root/"baseline/plan_world.py"),"-"],input=raw,capture_output=True,check=False,timeout=10)
(root/"baseline-expected-world.json").write_bytes(raw)
(root/"baseline-native.stdout").write_bytes(result.stdout)
(root/"baseline-native.stderr").write_bytes(result.stderr)
report=json.loads(result.stdout)
assert result.returncode==0 and not result.stderr
assert report["world"]==expected and report["world_hash"]==hashlib.sha256(raw).hexdigest()
assert report["status"]=="no_conflict" and report["candidate_count"]==0
receipt={"status":"PASS","scope":"Pre-candidate expectation control through unchanged native planner","base":"53aa5048b6585aa08592d5513cfcf555a8bba018","returncode":result.returncode,"expectedWorldSha256":hashlib.sha256(raw).hexdigest(),"stdoutSha256":hashlib.sha256(result.stdout).hexdigest(),"sourceReviewExpectationOnly":True}
(root/"baseline-control.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
