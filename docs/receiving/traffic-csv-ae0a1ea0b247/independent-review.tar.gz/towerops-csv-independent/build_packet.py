from pathlib import Path
import hashlib,io,json,os,sys,tarfile
root=Path(sys.argv[1]); reserve=Path(sys.argv[2])
def ident(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()}
files=[p for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.name!="MANIFEST.json"]
manifest={str(p.relative_to(root)):ident(p.read_bytes()) for p in sorted(files)}
(root/"MANIFEST.json").write_text(json.dumps({"files":manifest},indent=2)+"\n")
files.append(root/"MANIFEST.json")
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode="w:gz",compresslevel=9) as archive:
 for p in sorted(files):
  archive.add(p,arcname="towerops-csv-independent/"+str(p.relative_to(root)),recursive=False)
raw=buf.getvalue()
assert reserve.exists() and reserve.stat().st_size>=len(raw),(len(raw),str(reserve))
assert not any(reserve.read_bytes()),"Retained evidence must not be overwritten"
with reserve.open("r+b") as out:
 out.write(raw);out.flush();os.fsync(out.fileno());out.seek(0);assert out.read(len(raw))==raw
 out.truncate(len(raw));out.flush();os.fsync(out.fileno());out.seek(0);assert out.read()==raw
with tarfile.open(fileobj=io.BytesIO(reserve.read_bytes()),mode="r:gz") as archive:
 for name,pin in manifest.items():
  assert ident(archive.extractfile("towerops-csv-independent/"+name).read())==pin,name
print(json.dumps({"packet":{"path":str(reserve),"format":"tar.gz","files":len(files),**ident(raw)},"manifest":ident((root/"MANIFEST.json").read_bytes()),"receipt":ident((root/"results/independent-receipt.json").read_bytes())},indent=2))
