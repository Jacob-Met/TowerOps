"""Independent actual CSV-to-WorldState consumer receiving; synthetic inputs only."""
from __future__ import annotations
import csv, hashlib, io, json, math, os, pathlib, subprocess, sys, traceback

ROOT = pathlib.Path(sys.argv[1]).resolve()
SOURCE = pathlib.Path(sys.argv[2]).resolve()
EXPECTED_CONVERTER = sys.argv[3]
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

def ident(raw):
    return {"bytes":len(raw), "sha256":hashlib.sha256(raw).hexdigest(),
            "gitBlob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()}

def save(name, raw):
    p=OUT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(raw)
    assert p.read_bytes()==raw
    return ident(raw)

def canon(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")

expectation=json.loads((ROOT/"EXPECTATIONS.json").read_text())
pins=expectation["nativePins"] | {"world_from_csv.py":EXPECTED_CONVERTER}
source_before={}
for path,pin in pins.items():
    data=(SOURCE/path).read_bytes()
    assert ident(data)["gitBlob"]==pin,(path,ident(data))
    source_before[path]=ident(data)
expected={
  "version":9007199254740991,"observed_at":-0.0,
  "aircraft":[
    {"aircraft_id":"9","x_nm":-20.125,"y_nm":-0.0,"altitude_ft":7000.0,"vx_nm_min":0.0,"vy_nm_min":1.25,"climb_ft_min":0},
    {"aircraft_id":"A-1","x_nm":1000000000000,"y_nm":-1000000000000.0,"altitude_ft":3000,"vx_nm_min":1.0,"vy_nm_min":0,"climb_ft_min":-0.0},
    {"aircraft_id":"a_1","x_nm":-0.0,"y_nm":1e-300,"altitude_ft":11000,"vx_nm_min":0,"vy_nm_min":-0.0,"climb_ft_min":0.0}
  ]
}
expected_raw=canon(expected)
save("expected-world.json",expected_raw+b"\n")

def sheet(header,rows,bom=True):
    out=io.StringIO(newline="")
    writer=csv.writer(out,quoting=csv.QUOTE_ALL,lineterminator="\r\n")
    writer.writerow(header)
    writer.writerows([[row[field] for field in header] for row in rows])
    return ("\ufeff" if bom else "").encode("utf-8")+out.getvalue().encode("utf-8")

def invoke(label,script,args,raw=None):
    env=os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"]="1"
    command=[sys.executable,"-B",str(SOURCE/script),*args]
    result=subprocess.run(command,input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          env=env,cwd=SOURCE,timeout=12,check=False)
    entry={"argv":command,"returncode":result.returncode,
           "stdout":save(label+".stdout",result.stdout),"stderr":save(label+".stderr",result.stderr)}
    if raw is not None:
        entry["stdin"]=save(label+".stdin",raw)
    runs[label]=entry
    return result

def compare(actual):
    assert type(actual) is dict
    assert canon(actual)==expected_raw,(actual,expected)
    for got,want in zip(actual["aircraft"],expected["aircraft"],strict=True):
        for field,number in want.items():
            if field=="aircraft_id": continue
            assert type(got[field]) is type(number),(field,type(got[field]),type(number))
            if isinstance(number,float) and number==0:
                assert math.copysign(1,got[field])==math.copysign(1,number),field
    assert type(actual["version"]) is int
    assert type(actual["observed_at"]) is float
    assert math.copysign(1,actual["observed_at"])==-1

runs={}; groups=[]; failures=[]
args=["--observed-at=-0.0","--version=9007199254740991"]
try:
    original=sheet(expectation["header"],expectation["tokens"])
    input_path=OUT/"authored-traffic.csv"
    input_path.write_bytes(original)
    before=ident(input_path.read_bytes())
    file_result=invoke("file", "world_from_csv.py",[str(input_path),*args])
    assert file_result.returncode==0 and file_result.stderr==b"",file_result.stderr
    compare(json.loads(file_result.stdout))
    assert ident(input_path.read_bytes())==before
    groups.append("Actual file intake preserves quoted/reordered/BOM/CRLF data, exact JSON numeric types, signed zeros and source bytes.")
    reversed_sheet=sheet(list(reversed(expectation["header"])),list(reversed(expectation["tokens"])),bom=False)
    stdin_result=invoke("stdin-reordered","world_from_csv.py",["-",*args],reversed_sheet)
    assert stdin_result.returncode==0 and stdin_result.stderr==b"",stdin_result.stderr
    compare(json.loads(stdin_result.stdout))
    assert stdin_result.stdout==file_result.stdout
    groups.append("Equivalent reordered stdin produces exact same canonical native world bytes.")
    native=invoke("native-planner","plan_world.py",["-"],file_result.stdout)
    assert native.returncode==0 and native.stderr==b"",native.stderr
    report=json.loads(native.stdout)
    compare(report["world"])
    assert report["world_hash"]==hashlib.sha256(expected_raw).hexdigest()
    assert report["input_sha256"]==hashlib.sha256(file_result.stdout).hexdigest()
    assert report["reviewed_at"]==0 and math.copysign(1,report["reviewed_at"])==-1
    assert report["status"]=="no_conflict" and report["advisories"]==[] and report["candidate_count"]==0
    assert report["simulation_only"] is True and report["proposal_only"] is True
    groups.append("Actual unchanged native planner receives exact converted bytes/world/hash/metadata and returns the expected no-conflict proposal result.")
    late=dict(expectation["tokens"][0])
    mutations={
      "late-exact-duplicate":original+sheet(expectation["header"],[late],bom=False).split(b"\r\n",1)[1],
      "late-boolean":sheet(expectation["header"],expectation["tokens"]+[dict(late,aircraft_id="late",x_nm="true")]),
      "late-nonfinite":sheet(expectation["header"],expectation["tokens"]+[dict(late,aircraft_id="late",x_nm="1e309")]),
      "late-invalid-utf8":original+b"\xff"
    }
    for name,raw in mutations.items():
        invalid=OUT/(name+".csv")
        invalid.write_bytes(raw)
        original_hash=ident(raw)
        result=invoke(name,"world_from_csv.py",[str(invalid),*args])
        assert result.returncode==2 and result.stdout==b"" and result.stderr,(name,result)
        assert b"Traceback" not in result.stderr,(name,result.stderr)
        assert ident(invalid.read_bytes())==original_hash
    groups.append("Four valid-prefix/late-error sheets refuse atomically with no JSON prefix and no source mutation.")
except Exception as exc:
    failures.append({"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()})
for path,old in source_before.items():
    assert ident((SOURCE/path).read_bytes())==old,path
receipt={
 "status":"ACCEPT" if not failures else "BLOCKED",
 "role":"Independent source/native consumer receiving; no converter implementation authored by this reviewer",
 "baseline":expectation["base"],"source":source_before,
 "expectation":ident((ROOT/"EXPECTATIONS.json").read_bytes()),
 "expectedWorld":ident(expected_raw),
 "groups":groups,"failures":failures,"runs":runs,
 "nativeSourcesUnchanged":True,
 "limits":["Synthetic local fixtures only; no actual aircraft or service.","No duplicate broad planner/admission suite or browser run.","Native model/policy behavior reused unchanged; no operational safety claim."]
}
save("independent-receipt.json",(json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps({"status":receipt["status"],"groups":groups,"failures":failures,"receipt":ident((OUT/"independent-receipt.json").read_bytes())},indent=2))
raise SystemExit(bool(failures))
