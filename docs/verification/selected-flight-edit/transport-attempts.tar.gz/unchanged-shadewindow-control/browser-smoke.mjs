// Optional real-browser qualification. Node 22+ and an installed Chromium are
// required; the product and its ordinary Node tests remain dependency-free.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';

const sourceRoot = path.resolve(process.argv[2] ?? fileURLToPath(new URL('../../', import.meta.url)));
const browserPath = process.env.SHADEWINDOW_CHROMIUM ?? 'chromium';
const evidenceDir = process.env.SHADEWINDOW_EVIDENCE_DIR ?? await fs.mkdtemp(path.join(os.tmpdir(), 'shadewindow-evidence-'));
await fs.mkdir(evidenceDir, { recursive: true });
const profileRoot = process.env.SHADEWINDOW_PROFILE_ROOT ?? os.tmpdir();
const profile = await fs.mkdtemp(path.join(profileRoot, 'hamon-shadewindow-e652aa-'));
const sourceFiles = ['index.html', 'style.css', 'src/app.mjs', 'src/model.mjs', 'src/planner.mjs',
  'data/la-2025-08-01_to_2025-09-30.json', 'EVALUATION.md'];
const hashSources = async () => Object.fromEntries(await Promise.all(sourceFiles.map(async name => [
  name, crypto.createHash('sha256').update(await fs.readFile(path.join(sourceRoot, name))).digest('hex'),
])));
const before = await hashSources();
const checks = [], exceptions = [], requests = [];
let browser, socket, receipt, failData = false;
const types = { '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const server = http.createServer(async (request, response) => {
  try {
    let pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    if (pathname === '/') pathname = '/index.html';
    if (failData && pathname.startsWith('/data/')) throw new Error('Intentional unavailable-data control');
    const file = path.resolve(sourceRoot, '.' + pathname);
    if (!file.startsWith(sourceRoot + path.sep)) throw new Error('Outside test source');
    const bytes = await fs.readFile(file);
    response.writeHead(200, { 'content-type': types[path.extname(file)] ?? 'application/octet-stream', 'cache-control': 'no-store' });
    response.end(bytes);
  } catch {
    response.writeHead(404);
    response.end('Unavailable in isolated test');
  }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const url = `http://127.0.0.1:${server.address().port}/`;
const browserVersion = execFileSync(browserPath, ['--version'], { encoding: 'utf8', timeout: 15000 }).trim();
let nextId = 0;
const pending = new Map();
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function send(method, params = {}, sessionId) {
  const id = ++nextId;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }, 15000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(sessionId, expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sessionId);
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function waitFor(sessionId, expression) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if (await evaluate(sessionId, expression)) return;
    await delay(80);
  }
  throw new Error(`Page did not reach expected state: ${expression}`);
}
async function openPage() {
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  await send('Runtime.enable', {}, sessionId);
  await send('Page.enable', {}, sessionId);
  await send('Network.enable', {}, sessionId);
  await send('Page.navigate', { url }, sessionId);
  return { targetId, sessionId };
}
async function setControls(sessionId, values) {
  await evaluate(sessionId, `(() => {
    const values = ${JSON.stringify(values)};
    for (const [selector, value] of Object.entries(values)) document.querySelector(selector).value = String(value);
    const last = Object.keys(values).at(-1);
    document.querySelector(last).dispatchEvent(new Event(last === '#threshold' ? 'input' : 'change', {bubbles: true}));
  })()`);
}
async function click(sessionId, selector) {
  const point = await evaluate(sessionId, `(() => {
    const element = document.querySelector(${JSON.stringify(selector)});
    element.scrollIntoView({block: 'center'});
    const r = element.getBoundingClientRect();
    return {x: r.x + r.width / 2, y: r.y + r.height / 2};
  })()`);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...point }, sessionId);
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...point }, sessionId);
}
async function readState(sessionId) {
  return evaluate(sessionId, `(() => ({
    date: document.querySelector('#day-select').value,
    starts: [...document.querySelectorAll('[data-slot-start]')].map(button => Number(button.dataset.slotStart)),
    selected: document.querySelector('[data-slot-start][aria-pressed="true"]')?.dataset.slotStart ?? null,
    highlight: document.querySelector('#selected-window') ? {...document.querySelector('#selected-window').dataset} : null,
    hours: [...document.querySelectorAll('#hourly-rows tr th')].map(cell => cell.textContent),
    prior: document.querySelector('#source-day').textContent,
    status: document.querySelector('#slot-status').textContent,
    window: document.querySelector('#window-result').textContent,
    error: document.querySelector('#planner-error').hidden ? null : document.querySelector('#planner-error').textContent,
    evidenceHidden: document.querySelector('#hourly-evidence').hidden,
    bodyOverflow: document.documentElement.scrollWidth > window.innerWidth + 1,
    active: document.activeElement.id,
  }))()`);
}
async function screenshot(sessionId, name) {
  await evaluate(sessionId, 'window.scrollTo(0, 0)');
  const { cssContentSize } = await send('Page.getLayoutMetrics', {}, sessionId);
  const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true,
    clip: { x: 0, y: 0, width: cssContentSize.width, height: cssContentSize.height, scale: 1 } }, sessionId);
  await fs.writeFile(path.join(evidenceDir, name), Buffer.from(shot.data, 'base64'));
}

try {
  browser = spawn(browserPath, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-extensions',
    '--password-store=basic', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    `--user-data-dir=${profile}`, 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] });
  const endpoint = await new Promise((resolve, reject) => {
    let errors = '';
    const timer = setTimeout(() => reject(new Error(`Chromium did not start: ${errors.slice(-2000)}`)), 15000);
    browser.on('error', error => { clearTimeout(timer); reject(error); });
    browser.on('exit', code => { clearTimeout(timer); reject(new Error(`Chromium exited: ${code} ${errors.slice(-2000)}`)); });
    browser.stderr.on('data', bytes => {
      errors += bytes.toString();
      const found = errors.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);
      if (found) { clearTimeout(timer); resolve(found[1]); }
    });
  });
  socket = new WebSocket(endpoint);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const task = pending.get(message.id);
      pending.delete(message.id);
      clearTimeout(task.timer);
      if (message.error) task.reject(new Error(JSON.stringify(message.error))); else task.resolve(message.result);
    }
    if (message.method === 'Runtime.exceptionThrown') exceptions.push(message.params.exceptionDetails.text);
    if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  const { sessionId } = await openPage();
  await send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 1000, deviceScaleFactor: 1, mobile: false }, sessionId);
  await waitFor(sessionId, 'document.querySelectorAll("[data-slot-start]").length > 0');
  let state = await readState(sessionId);
  assert.equal(state.date, '2025-09-21');
  assert.equal(state.prior, 'Prior observation: Sep 20');
  assert.equal(state.hours.length, 2);
  assert.equal(state.error, null);
  assert.equal(state.bodyOverflow, false);
  checks.push('Initial historical replay renders and labels the actual preceding source day');

  await setControls(sessionId, { '#available-start': 10, '#available-end': 16, '#duration': 2, '#threshold': 85 });
  state = await readState(sessionId);
  assert.equal(state.starts.length, 5);
  assert.deepEqual([...state.starts].sort((a, b) => a - b), [10, 11, 12, 13, 14]);
  assert.equal(state.hours.length, 2);
  assert.equal(Number(state.highlight.end) - Number(state.highlight.start), 2);
  checks.push('Changing availability/duration/threshold yields five complete requested slots');

  await click(sessionId, '#more-slots-label');
  const alternate = state.starts.at(-1);
  await click(sessionId, `[data-slot-start="${alternate}"]`);
  state = await readState(sessionId);
  assert.equal(Number(state.selected), alternate);
  assert.equal(Number(state.highlight.start), alternate);
  assert.equal(state.hours[0], `${String(alternate).padStart(2, '0')}:00`);
  checks.push('A real pointer click on an additional ranked slot updates selected state, chart and hourly table');

  await setControls(sessionId, { '#comparison-basis': 'upper-bound' });
  state = await readState(sessionId);
  assert.equal(state.starts.length, 1);
  assert.match(state.status, /interval upper bound/);
  await setControls(sessionId, { '#day-select': '2025-09-24' });
  state = await readState(sessionId);
  assert.equal(state.starts.length, 0);
  assert.match(state.status, /interval upper bound/);
  assert.equal(state.highlight, null);
  assert.equal(state.evidenceHidden, true);
  await setControls(sessionId, { '#comparison-basis': 'estimate' });
  assert.equal((await readState(sessionId)).starts.length, 1);
  checks.push('Point and upper-bound modes diverge visibly; no-fit clears the old selection and evidence');

  await setControls(sessionId, { '#available-end': 12, '#duration': 3 });
  state = await readState(sessionId);
  assert.match(state.status, /does not fit inside 10:00–12:00/);
  assert.equal(state.highlight, null);
  await setControls(sessionId, { '#available-end': 9 });
  state = await readState(sessionId);
  assert.match(state.error, /end time later/);
  assert.equal(state.starts.length, 0);
  checks.push('Too-short and reversed availability produce distinct understandable states without stale slots');

  await setControls(sessionId, { '#available-start': 22, '#available-end': 24, '#duration': 2, '#threshold': 105 });
  state = await readState(sessionId);
  assert.equal(state.error, null);
  assert.deepEqual(state.hours, ['22:00', '23:00']);
  assert.equal(state.highlight.end, '24');
  await evaluate(sessionId, 'document.querySelector("#compare").focus()');
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, text: '\r' }, sessionId);
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 }, sessionId);
  assert.equal((await readState(sessionId)).active, 'slot-heading');
  checks.push('Same-day midnight end works and native keyboard submission moves focus to results');

  await setControls(sessionId, { '#day-select': '2025-09-21', '#available-start': 10, '#available-end': 16, '#duration': 2, '#threshold': 85 });
  await click(sessionId, '#hourly-evidence > summary');
  await screenshot(sessionId, 'desktop.png');
  await send('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: false }, sessionId);
  assert.equal((await readState(sessionId)).bodyOverflow, false);
  await screenshot(sessionId, 'mobile.png');
  checks.push('Desktop and 390px layouts fit their viewport; hourly table scroll stays inside its container');

  failData = true;
  const failed = await openPage();
  await waitFor(failed.sessionId, 'document.querySelector("#planner-error") && !document.querySelector("#planner-error").hidden');
  const failedState = await readState(failed.sessionId);
  assert.match(failedState.error, /Could not load bundled weather data/);
  assert.equal(failedState.starts.length, 0);
  assert.equal(await evaluate(failed.sessionId, 'document.querySelector("#compare").disabled'), true);
  checks.push('Unavailable bundled data produces an explicit error and leaves comparison disabled');
  failData = false;

  assert.deepEqual(exceptions, []);
  assert.ok(requests.every(request => new URL(request).origin === new URL(url).origin));
  assert.deepEqual(await hashSources(), before);
  checks.push('No uncaught page exceptions, external page requests or changes to source/model/data/evaluation');
  receipt = { status: 'pass', node: process.version, browser: browserVersion, checks, sourceSha256: before,
    viewports: [[1280, 1000], [390, 844]], actualBrowser: true, serving: 'isolated loopback test server',
    modelOrDatasetModified: false, liveWeatherOrProductionBenefitClaimed: false };
} finally {
  // Let Chromium shut down its renderer/profile writers before removing this
  // run's profile. Killing only a package wrapper can race a final disk write.
  if (socket?.readyState === WebSocket.OPEN) {
    await Promise.race([send('Browser.close').catch(() => {}), delay(3000)]);
  }
  socket?.close();
  if (browser && browser.exitCode === null) {
    browser.kill('SIGTERM');
    await Promise.race([new Promise(resolve => browser.once('exit', resolve)), delay(4000)]);
    if (browser.exitCode === null) browser.kill('SIGKILL');
  }
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  await fs.rm(profile, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
  for (const task of pending.values()) clearTimeout(task.timer);
}
// A passing receipt is published only after this run's process/profile cleanup
// has completed as well as its assertions.
await fs.writeFile(path.join(evidenceDir, 'browser-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
