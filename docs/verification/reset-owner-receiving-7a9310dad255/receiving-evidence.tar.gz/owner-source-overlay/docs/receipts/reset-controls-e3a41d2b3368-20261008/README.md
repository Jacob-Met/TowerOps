# Reset controls and simulation state together

On TowerOps main `09b96e31d2867af5b7a9738406d0431cf1010090`, choosing a nondefault time scale and then pressing **Reset** returns the slider to 1 while retaining the old simulation rate. The speed label and subsequent traffic movement still use that old rate. Reset also restores the three policy sliders and live policy but leaves their adjacent labels at the previous values. These are ordinary keyboard/control interactions, not malformed inputs.

The [ownership comment](https://github.com/Jacob-Met/TowerOps/issues/37#issuecomment-6058749962) reserves only this reset synchronization seam. Encounter exploration and WorldState JSON draft work remain with their existing contributors.

## Change

Only `web/airspace/src/main.ts::resetWorld` changes. It resets `rate`, sets the slider values from the restored policy/rate, and refreshes the three policy labels using the existing formatting. The regular renderer refreshes the speed label. All source text before and after that function is byte-identical to the parent; no planner, audit, track-edit, import or draft behavior is changed.

The optional [browser receiver](../../../tools/verify_airspace_reset.cjs) is new. It serves an actual production build on loopback, starts a separate installed Chromium, changes sliders with native Home/End keys, presses the real Reset/Run/Export controls, reads the displayed controls and exported world, and closes its own browser/server. It does not access a user's existing browser session.

## Actual browser evidence

The same frozen receiver ran against original and corrected production builds in Chromium 153.0.8010.47 with Playwright 1.62.1 and Node 22.22.1.

| Scenario | Original after Reset | Corrected after Reset |
| --- | --- | --- |
| Fresh default control | Correct labels and 3 simulated seconds | Same correct result |
| Previously selected 3× and wide policy | Sliders reset, old labels remain; 9 simulated seconds | Labels reset; 3 simulated seconds |
| Previously selected 0.5× and narrow policy | Sliders reset, old labels remain; 1.5 simulated seconds | Labels reset; 3 simulated seconds |

The elapsed values above use identical application animation callbacks at 1000 and 1050 milliseconds. Only callback scheduling is controlled; the actual application handler, model, state update and rendering execute unchanged. Elapsed simulated time is measured from the first zero-elapsed frame, because the fixture's observation timestamp legitimately predates its live simulation clock. These values are not a wall-clock timing measurement.

- [Original receiver](baseline-browser-calibrated/receipt.json): one passing fresh-page control and two failing reset scenarios. Ordinary selected-rate behavior, slider restoration, policy restoration, pause behavior and world reset all remain passing controls.
- [Corrected receiver](candidate-browser/receipt.json): all three scenarios and all 19 checks pass. Both reset scenarios produce exactly the same projected world as the fresh default control.
- Both runs report no page errors or failed HTTP responses. Source hashes before and after each run match. Each receipt binds the served build files and the unchanged receiving harness.
- Speed and policy captures from both builds were visually inspected. They show the stale labels beside reset slider positions in the original, and matching labels/positions in the candidate.

The initial harness attempt assumed the fixture observation time equaled the live clock. Its normal control correctly exposed that bad assumption. The original attempt, source and result remain under `initial-harness-attempt/`; the elapsed-time origin was corrected and the baseline replayed before any runtime source edit. It is not reported as a product failure.

## Existing project gates and source pins

The native TypeScript check and production build pass. All **70 existing Vitest tests** pass, including the integrated numeric-admission, selected-track, Python audit interoperability and float-parity controls ([test log](candidate-tests.log)). No dependency was installed. Existing native packages were reused through a read-only target; Vite/Vitest used caches and build outputs in the exclusive author directory. The exact native build/config wrappers are preserved here.

The parent is the actual upstream Git commit, with tree `4d22827647c0b2e37d11921aa5273f7a358bcdde`. The candidate retains that ancestry.

| Artifact | SHA-256 |
| --- | --- |
| Original `main.ts` | `e712557df83d2159d8c496393e982de28dc7258be1beeefb7d3d4da0664b8d9f` |
| Corrected `main.ts` | `c9c07a4a1ce29e6a29e918ecbe26a75bd3816cc77741231a4167c99b408f43f5` |
| Frozen browser receiver | `30d8abef87cc09615277b839dc4d6edcc7ae90d6443abdbe18a90f86294aa6d7` |

The original and corrected main Git blobs are `2aabfdba1292f6db0890b2fb0b9bc8cf9e027636` and `b23dbd6580d9f5499b8381664dd42425eca61ab4`. See `source-pins.json` and `receipt.json` for exact custody and payload hashes.

For a normal independent replay, build the checked-out app with its installed dependencies, then run:

```sh
node tools/verify_airspace_reset.cjs web/airspace/dist /tmp/towerops-reset-receiving web/airspace/src/main.ts /path/to/chromium
```

The receiver requires an already installed Playwright package (use `NODE_PATH` if it is provided by an isolated shared tool environment) and a new output directory. The app's runtime dependencies and normal test command remain unchanged.

## Receiving state

This packet establishes author qualification of a source candidate. Root coordinates independent receiving, the current upstream head and composition with other owners, and any publication. No merge, installed-service change or deployment is claimed here. A later receiving head must retain additions made by the JSON draft and encounter contributors, including any separate reset statements.
