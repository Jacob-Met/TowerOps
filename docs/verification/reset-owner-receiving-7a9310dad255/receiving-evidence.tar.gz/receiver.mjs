// Native CDP transport adapted from 7a9310dad255/runtime's existing Commons receiver.
// This receiver uses a new browser profile and reads the supplied build/source only.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const [sourceArg, manifestArg, outArg] = process.argv.slice(2);
if (!sourceArg || !manifestArg || !outArg) throw Error('source, source manifest, and exclusive output directory required');
const source=path.resolve(sourceArg), dist=path.join(source,'web/airspace/dist'), out=path.resolve(outArg);
await fs.mkdir(out,{recursive:false});
const profile=path.join(out,'profile');
await fs.mkdir(profile);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const manifestBytes=await fs.readFile(manifestArg), manifest=JSON.parse(manifestBytes);
const checks=[], exceptions=[], served=[], external=[], proxyBlocks=[], serverEvents=[], networkEvents=[], debugEvents=[];
let selfCheck, chromeStderr='', navigationFailureState;
let browser, socket, session, serial=0, fatal, baseline, browserVersion;
const pending=new Map();
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const driverHash=sha(await fs.readFile(fileURLToPath(import.meta.url)));
async function sourceUnchanged(){
 for(const f of manifest.files){
  const b=await fs.readFile(path.join(source,f.path));
  assert.equal(sha(b),f.sha256,'Source changed: '+f.path);
  assert.equal(git(b),f.git_blob,'Git identity changed: '+f.path);
 }
}
function send(method,params={},sessionId=session){
 const id=++serial;
 return new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},15000);
  pending.set(id,{resolve,reject,timer});
  socket.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));
 });
}
async function evaluate(expression){
 const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
 if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
 return r.result.value;
}
async function until(expression){
 const end=Date.now()+12000;
 while(Date.now()<end){if(await evaluate(expression))return;await delay(60);}
 throw Error('Browser state not reached: '+expression);
}
async function settle(){
 await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');
 await delay(100);
}
async function click(selector){
 const point=await evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');if(!e)throw Error("Missing control");e.scrollIntoView({block:"center",behavior:"instant"});const r=e.getBoundingClientRect();if(!e.checkVisibility()||r.width<=0||r.height<=0)throw Error("Control is not visible");if(e.disabled)throw Error("Control is disabled");return{x:r.x+r.width/2,y:r.y+r.height/2};})()');
 await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...point});
 await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...point});
 await settle();
}
async function value(){return evaluate('document.querySelector("#world-json").value');}
async function typeDraft(text){
 await click('#world-json');
 await evaluate('document.querySelector("#world-json").select()');
 await send('Input.insertText',{text});
 assert.equal(await value(),text,'Native input did not produce the authored draft');
}
async function resize(width){
 await send('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:false});
 await settle();
}
async function reset(){
 await click('#reset-world');
 await click('#export-world');
 baseline=JSON.parse(await value());
}
async function record(name,fn){
 let detail, failure=null;
 try{detail=await fn();}catch(e){failure=e.stack||String(e);}
 checks.push({name,passed:!failure,detail,failure});
 await fs.writeFile(path.join(out,'observations.json'),JSON.stringify(checks,null,2)+'\n');
 console.log(JSON.stringify(checks.at(-1)));
}
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.wasm':'application/wasm'};
const server=http.createServer(async(req,res)=>{
 serverEvents.push({kind:'request',url:req.url,method:req.method});
 try{
  let requested=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
  if(requested==='/'||requested==='/index.html')requested='/index.html';
  const file=path.resolve(dist,'.'+requested);
  if(!file.startsWith(dist+path.sep))throw Error('Outside build');
  const b=await fs.readFile(file);
  served.push({path:requested,bytes:b.length,sha256:sha(b)});
  res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});
  res.end(b);
 }catch(e){serverEvents.push({kind:'error',url:req.url,error:String(e)});res.writeHead(404);res.end('Not found');}
});
const proxy=http.createServer((req,res)=>{proxyBlocks.push(req.url);res.writeHead(502);res.end();});
proxy.on('connect',(req,s)=>{s.on('error',e=>proxyBlocks.push({socket_error:e.code}));proxyBlocks.push(req.url);s.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');});
try{
 await sourceUnchanged();
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 await new Promise(r=>proxy.listen(0,'127.0.0.1',r));
 const ownURL='http://127.0.0.1:'+server.address().port+'/';
 const probe=await fetch(ownURL,{signal:AbortSignal.timeout(5000)});
 const probeBody=Buffer.from(await probe.arrayBuffer());
 selfCheck={url:ownURL,status:probe.status,bytes:probeBody.length,sha256:sha(probeBody)};
 assert.equal(probe.status,200,'Own HTTP server self-check failed');
 browser=spawn('/snap/bin/chromium',[
  '--headless=new','--no-first-run','--no-default-browser-check','--disable-background-networking',
  '--disable-component-update','--disable-sync','--disable-extensions','--disable-quic',
  '--password-store=basic','--use-mock-keychain',
  '--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--log-net-log='+path.join(out,'chrome-netlog.json'),
  '--proxy-server=http://127.0.0.1:'+proxy.address().port,'--user-data-dir='+profile,'about:blank'
 ],{stdio:['ignore','ignore','pipe']});
 const endpoint=await new Promise((resolve,reject)=>{
  let stderr='';const t=setTimeout(()=>reject(Error('Chrome startup timeout: '+stderr.slice(-1000))),15000);
  browser.on('error',e=>{clearTimeout(t);reject(e);});
  browser.on('exit',code=>{clearTimeout(t);reject(Error('Chrome exited '+code));});
  browser.stderr.on('data',b=>{stderr+=b;chromeStderr+=b;const m=stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(t);resolve(m[1]);}});
 });
 socket=new WebSocket(endpoint);
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 socket.addEventListener('message',event=>{
  const m=JSON.parse(event.data);
  if(debugEvents.length<100)debugEvents.push({id:m.id,method:m.method,sessionId:m.sessionId,hasResult:!!m.result,error:m.error});
  if(m.method==='Network.requestWillBeSent')networkEvents.push({kind:'request',url:m.params.request.url,requestId:m.params.requestId});
  if(m.method==='Network.loadingFailed')networkEvents.push({kind:'failed',requestId:m.params.requestId,error:m.params.errorText,blockedReason:m.params.blockedReason});
  if(m.id&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);
  if(m.method==='Network.requestWillBeSent'&&!m.params.request.url.startsWith('http://127.0.0.1:'))external.push(m.params.request.url);
 });
 browserVersion=await send('Browser.getVersion',{},null);
 const target=await send('Target.createTarget',{url:'about:blank'},null);
 session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true},null)).sessionId;
 await send('Runtime.enable');await send('Page.enable');await send('Network.enable');
 await resize(1280);
 try{await send('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/'});}catch(e){
 navigationFailureState={state:await evaluate('({url:location.href,ready:document.readyState,title:document.title,body:document.body?.innerText.slice(0,500)})'),history:await send('Page.getNavigationHistory')};
 throw e;
 }
 await until('document.querySelector("#world-json")?.value.length>0');
 await click('details.control-card>summary');
 await click('details.state-workbench>summary');

 await click('details.policy-editor>summary');
 const trials=[{"id":"fast-and-mixed-policy","width":1280,"rate":2.5,"horizontal":7.5,"vertical":1800,"horizon":8},{"id":"slow-and-low-policy","width":1280,"rate":0.5,"horizontal":3.5,"vertical":600,"horizon":2.5},{"id":"maximum-controls-on-phone","width":390,"rate":3,"horizontal":10,"vertical":2500,"horizon":10}];
 async function controls(){
  return evaluate('(()=>{const ids=["speed-range","policy-horizontal","policy-vertical","policy-horizon"];const outputs=["speed-value","horizontal-value","vertical-value","horizon-value"];return {values:Object.fromEntries(ids.map(id=>[id,document.getElementById(id).value])),readouts:Object.fromEntries(outputs.map(id=>[id,document.getElementById(id).innerText.trim()])),world:JSON.parse(document.getElementById("world-json").value),run:document.getElementById("toggle-run").innerText.trim(),clock:document.getElementById("sim-clock").innerText.trim()};})()');
 }
 async function key(key,code,number){
  await send('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:number,nativeVirtualKeyCode:number});
  await send('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:number,nativeVirtualKeyCode:number});
 }
 async function range(selector,target,min,step){
  await click(selector);await key('Home','Home',36);
  for(let i=0;i<Math.round((target-min)/step);i++)await key('ArrowRight','ArrowRight',39);
  await settle();assert.equal(await evaluate('Number(document.querySelector('+JSON.stringify(selector)+').value)'),target);
 }
 const fresh=await controls(), comparisons=[];
 await fs.writeFile(path.join(out,'fresh-page.json'),JSON.stringify(fresh,null,2)+'\n');
 await record('untouched-fresh-page-control',async()=>{
  assert.deepEqual(fresh.values,{'speed-range':'1','policy-horizontal':'5','policy-vertical':'1000','policy-horizon':'5'});
  const numeric=t=>Number.parseFloat(t.replaceAll(',',''));
  assert.equal(numeric(fresh.readouts['speed-value']),1);
  assert.equal(numeric(fresh.readouts['horizontal-value']),5);
  assert.equal(numeric(fresh.readouts['vertical-value']),1000);
  assert.equal(numeric(fresh.readouts['horizon-value']),5);
  assert.equal(fresh.world.version,1);assert.equal(fresh.world.aircraft.length,2);
  assert.equal(fresh.run,'Run traffic');assert.equal(fresh.clock,'T+0 SEC');
  return fresh;
 });
 for(const trial of trials)await record(trial.id,async()=>{
  await resize(trial.width);
  await range('#speed-range',trial.rate,0.5,0.5);
  await range('#policy-horizontal',trial.horizontal,3,0.5);
  await range('#policy-vertical',trial.vertical,500,100);
  await range('#policy-horizon',trial.horizon,2,0.5);
  await click('#add-traffic');
  const before=await controls();assert.equal(before.world.aircraft.length,3);
  await click('#reset-world');const after=await controls();
  comparisons.push({input:trial,before,after,expected:fresh});
  await fs.writeFile(path.join(out,'control-comparisons.json'),JSON.stringify(comparisons,null,2)+'\n');
  if(trial.width===390){
   await click('details.policy-editor>summary');await click('details.policy-editor>summary');
   const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
   await fs.writeFile(path.join(out,'phone-reset-controls.png'),Buffer.from(shot.data,'base64'));
  }
  assert.deepEqual(after,fresh,'Reset must restore fresh range values, readouts, world and paused clock together');
  return {input:trial,before,after};
 });
 await sourceUnchanged();
}catch(e){fatal=e.stack||String(e);console.error(fatal);}
finally{
 if(socket){try{await send('Browser.close',{},null);}catch{}try{socket.close();}catch{}}
 if(browser&&!browser.killed)browser.kill('SIGTERM');
 for(const p of pending.values())clearTimeout(p.timer);
 server.closeAllConnections();proxy.closeAllConnections();
 await Promise.all([new Promise(r=>server.close(r)),new Promise(r=>proxy.close(r))]);
 const receipt={version:1,source,source_parent:manifest.parent,source_tree:manifest.source_tree,
  source_manifest_sha256:sha(manifestBytes),source_files:manifest.files.length,driver_sha256:driverHash,
  node:process.version,browser:browserVersion,checks,passed:checks.filter(x=>x.passed).length,total:checks.length,
  exceptions,external_requests:external,proxy_blocks:proxyBlocks,served,fatal,selfCheck,serverEvents,networkEvents,debugEvents,navigationFailureState,
  boundary:'Actual retained native product build, isolated browser/profile and loopback reads. No owner source or installed service mutation.'};
 await fs.writeFile(path.join(out,'chrome.stderr.log'),chromeStderr);
 await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({passed:receipt.passed,total:receipt.total,exceptions:exceptions.length,external_requests:external.length,fatal,receipt:path.join(out,'receipt.json')}));
 process.exitCode=fatal||checks.some(x=>!x.passed)||exceptions.length||external.length?1:0;
}
