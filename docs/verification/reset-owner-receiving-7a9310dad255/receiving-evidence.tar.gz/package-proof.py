import os,io,json,hashlib,tarfile,gzip,pathlib,shutil
root=pathlib.Path('/tmp/hamon-7a9310dad255-tower-reset-owner-root')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
bm=json.loads((root/'baseline-source-manifest.json').read_text());cm=json.loads((root/'candidate-source-manifest.json').read_text())
old={e['path']:e for e in bm['files']}
for e in cm['files']:
    if e['path'] not in old or (e['git_blob'],e['mode'])!=(old[e['path']]['git_blob'],old[e['path']]['mode']):
        source=root/'candidate-source'/e['path'];target=root/'owner-source-overlay'/e['path']
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        assert sha(target.read_bytes())==e['sha256']
for label in ['baseline','candidate']:
    receipt=json.loads((root/(label+'-browser-v1')/'receipt.json').read_text())
    for entry in {e['path']:e for e in receipt['served']}.values():
        rel='index.html' if entry['path']=='/' else entry['path'].lstrip('/')
        source=root/(label+'-source')/'web/airspace/dist'/rel;target=root/'served-build'/label/rel
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        assert sha(target.read_bytes())==entry['sha256']
def included(path):
    rel=path.relative_to(root)
    return path.is_file() and not path.is_symlink() and not any(p in ['baseline-source','candidate-source','profile','vite-cache-baseline','vite-cache-candidate'] for p in rel.parts) and path.name not in ['receiving-evidence.tar.gz','export-manifest.json','archive-receipt.json']
files=sorted([p for p in root.rglob('*') if included(p)],key=lambda p:p.relative_to(root).as_posix())
entries=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'git_blob':blob(p.read_bytes())} for p in files]
manifest={'schema':'towerops.existing-reset-owner-proof.v1','root':str(root),'owner_source_commit':cm['commit'],'owner_source_tree':cm['source_tree'],'public_baseline':bm['commit'],'files':entries,'boundary':'Existing-owner exact-source receiving only. No competing production patch or current-main acceptance.'}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();(root/'export-manifest.json').write_bytes(manifest_bytes)
payload=[('export-manifest.json',manifest_bytes)]+[(e['path'],(root/e['path']).read_bytes()) for e in entries]
tar=io.BytesIO()
with tarfile.open(fileobj=tar,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for name,data in payload:
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644;archive.addfile(info,io.BytesIO(data))
output=gzip.compress(tar.getvalue(),mtime=0);dest=root/'receiving-evidence.tar.gz';dest.write_bytes(output)
with tarfile.open(fileobj=io.BytesIO(dest.read_bytes()),mode='r:gz') as archive:
    assert len(archive.getmembers())==len(payload)
    for name,data in payload:assert archive.extractfile(name).read()==data
receipt={'archive':str(dest),'bytes':len(output),'sha256':sha(output),'git_blob':blob(output),'members':len(payload),'uncompressed_payload_bytes':sum(len(data) for _,data in payload),'manifest_sha256':sha(manifest_bytes),'all_members_exact_after_readback':True,'source_overlay_files':len([e for e in entries if e['path'].startswith('owner-source-overlay/')]),'served_build_files':len([e for e in entries if e['path'].startswith('served-build/')])}
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
