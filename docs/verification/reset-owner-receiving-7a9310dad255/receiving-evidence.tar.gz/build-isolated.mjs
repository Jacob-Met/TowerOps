import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const root='/tmp/hamon-7a9310dad255-tower-reset-owner-root';
const [mode,labelArg]=process.argv.slice(2);const label=mode==='vite'?labelArg:mode;
assert.ok(['baseline','candidate'].includes(label));const source=path.join(root,label+'-source'),web=path.join(source,'web/airspace'),dist=path.join(web,'dist');
const dependency='/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(mode==='vite'){
 const expected="import { defineConfig } from 'vitest/config';\nexport default defineConfig({base:'./',build:{outDir:'dist',emptyOutDir:true},test:{environment:'node'}});\n";
 assert.equal(fs.readFileSync(path.join(web,'vite.config.ts'),'utf8'),expected,'Explicit equivalent config must match the pinned source');
 const {build}=await import(path.join(dependency,'vite/dist/node/index.js'));
 await build({root:web,configFile:false,base:'./',cacheDir:path.join(root,'vite-cache-'+label),build:{outDir:dist,emptyOutDir:true}});
}else{
 const sourceManifestBytes=fs.readFileSync(path.join(root,label+'-source-manifest.json')),manifest=JSON.parse(sourceManifestBytes);
 const dep=JSON.parse(fs.readFileSync(path.join(root,'source-capture-receipt.json'))).dependencyPins;
 function pins(){for(const f of manifest.files)assert.equal(sha(fs.readFileSync(path.join(source,f.path))),f.sha256,'Source changed '+f.path);for(const f of dep)assert.equal(sha(fs.readFileSync(f.path)),f.sha256,'Dependency metadata changed '+f.name);}
 const steps=[];const start=new Date().toISOString();let failure;
 try{pins();for(const [name,args]of [['prepare-python',['prepare-python.mjs']],['typecheck',[path.join(dependency,'typescript/bin/tsc'),'--noEmit']],['vite',[path.join(root,'build-isolated.mjs'),'vite',label]]]){
 const result=spawnSync(process.execPath,args,{cwd:web,encoding:'utf8',maxBuffer:8*1024*1024});
 fs.writeFileSync(path.join(root,label+'-'+name+'.stdout.log'),result.stdout||'',{flag:'wx'});fs.writeFileSync(path.join(root,label+'-'+name+'.stderr.log'),result.stderr||'',{flag:'wx'});
 steps.push({name,command:[process.execPath,...args],cwd:web,status:result.status,signal:result.signal,error:result.error?.message});if(result.status!==0)throw Error(name+' failed: '+result.stderr);
 }pins();}catch(e){failure=e.stack||String(e);}
 const files=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else{const b=fs.readFileSync(p);files.push({path:path.relative(dist,p),bytes:b.length,sha256:sha(b)});}}}if(fs.existsSync(dist))walk(dist);
 const receipt={start,finish:new Date().toISOString(),node:process.version,label,source,source_commit:manifest.commit,source_tree:manifest.source_tree,source_manifest_sha256:sha(sourceManifestBytes),source_files:manifest.files.length,dependency_pins:dep,build_driver_sha256:sha(fs.readFileSync(path.join(root,'build-isolated.mjs'))),configuration:'Pinned source two-line config asserted unchanged; Node22-compatible explicit equivalent build settings, isolated output/cache. Existing dependencies reused read-only.',steps,files,failure};
 fs.writeFileSync(path.join(root,label+'-build-receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({label,steps,assets:files.length,asset_bytes:files.reduce((n,f)=>n+f.bytes,0),failure,receipt_sha256:sha(fs.readFileSync(path.join(root,label+'-build-receipt.json')))}));if(failure)process.exitCode=1;
}