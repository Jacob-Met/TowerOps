import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='/home/jacob/hamon-7a9310dad255-tower-reset-owner-root';
const owner='/home/jacob/hamon-universal-e3a41d2b3368-towerops-reset/candidate';
const dependency='/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules';
const git=(...args)=>execFileSync('git',['--no-optional-locks','-C',owner,...args],{maxBuffer:32*1024*1024});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const blob=b=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const observedBefore={head:git('rev-parse','HEAD').toString().trim(),status:git('status','--porcelain=v1').toString()};
const cases=[{label:'baseline',commit:'09b96e31d2867af5b7a9738406d0431cf1010090',tree:'4d22827647c0b2e37d11921aa5273f7a358bcdde',main:'e712557df83d2159d8c496393e982de28dc7258be1beeefb7d3d4da0664b8d9f'},{label:'candidate',commit:'0f6e453cee36bbfcece6c0c80e90a38bc39cd0bd',tree:'a07a0d044cd38073e6dec49d745244e3461732aa',main:'c9c07a4a1ce29e6a29e918ecbe26a75bd3816cc77741231a4167c99b408f43f5'}];
const receipts=[];
for(const c of cases){
 assert.equal(git('rev-parse',c.commit+'^{tree}').toString().trim(),c.tree);
 const dest=path.join(root,c.label+'-source');fs.mkdirSync(dest);
 const entries=git('ls-tree','-rz',c.commit).toString().split('\0').filter(Boolean).map(l=>{const tab=l.indexOf('\t');const [mode,type,id]=l.slice(0,tab).split(' ');return{path:l.slice(tab+1),mode,type,id};});
 const files=[];
 for(const f of entries){
  assert.equal(f.type,'blob');assert.ok(['100644','100755'].includes(f.mode));assert.ok(!f.path.split('/').includes('..'));
  const bytes=git('cat-file','blob',f.id);assert.equal(blob(bytes),f.id);
  const target=path.join(dest,f.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx',mode:f.mode==='100755'?0o755:0o644});
  files.push({path:f.path,mode:f.mode,bytes:bytes.length,sha256:sha(bytes),git_blob:f.id});
 }
 assert.equal(files.find(f=>f.path==='web/airspace/src/main.ts').sha256,c.main);
 const manifest={schema:'towerops.existing-owner-source.v1',owner_claim:'https://github.com/Jacob-Met/TowerOps/issues/37#issuecomment-6058749962',source_root:dest,source_repository:owner,commit:c.commit,parent:'09b96e31d2867af5b7a9738406d0431cf1010090',source_tree:c.tree,files};
 const content=JSON.stringify(manifest,null,2)+'\n';fs.writeFileSync(path.join(root,c.label+'-source-manifest.json'),content,{flag:'wx'});
 fs.symlinkSync(dependency,path.join(dest,'web/airspace/node_modules'),'dir');
 receipts.push({label:c.label,commit:c.commit,tree:c.tree,leaves:files.length,source_bytes:files.reduce((n,f)=>n+f.bytes,0),manifest_sha256:sha(content)});
}
const observedAfter={head:git('rev-parse','HEAD').toString().trim(),status:git('status','--porcelain=v1').toString()};
const dependencyPins=['vite','typescript','vitest','pyodide'].map(name=>{const file=path.join(dependency,name,'package.json'),bytes=fs.readFileSync(file);return{name,path:file,version:JSON.parse(bytes).version,sha256:sha(bytes)};});
const receipt={at:new Date().toISOString(),method:'Pinned immutable native Git blobs; isolated output directories, read-only dependency symlink. Owner workspace was neither written nor built.',contract_sha256:sha(fs.readFileSync(path.join(root,'contract.json'))),driver_sha256:sha(fs.readFileSync(path.join(root,'receiver.mjs'))),observedBefore,observedAfter,owner_state_stable:JSON.stringify(observedBefore)===JSON.stringify(observedAfter),dependency,dependencyPins,snapshots:receipts};
fs.writeFileSync(path.join(root,'source-capture-receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt,null,2));