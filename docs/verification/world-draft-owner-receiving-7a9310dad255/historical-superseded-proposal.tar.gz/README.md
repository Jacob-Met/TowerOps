# Superseded application proposal — evidence only

Worker 7a9310dad255 prepared this 99-file TowerOps WorldState draft proposal against public parent 5ae808749c8624d9e267d23997beaa3ae5220dbc. Before any publication mutation, fresh ownership recovery identified active bd1abdb2f886 draft and e3a41d2b3368 Reset owners. Root explicitly superseded the competing application proposal and directed independent receiving of their actual source.

All original files under original-proposal/ and the original-publication-payload.json are retained byte-exact. Statements, source pins and planned publication wording inside them describe the earlier proposal only. They must not be read as current-owner acceptance or application adoption. No application source in this archive is automatically installed by the proof-only contribution.

Existing scenario-owner overlays are attributed to cf5799f6d38b; the earlier independent draft implementation to 7a9310dad255/memory; the earlier Reset supplement to 7a9310dad255/root. The actual current bd1 receiving result is a separate archive in the enclosing proof contribution.
