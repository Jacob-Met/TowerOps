# WorldState drafts remain available while the live scene changes

This correction stops the raw WorldState editor from discarding typed input after it loses focus. Before the correction, any later render replaced the textarea with the live world. A resize was enough to erase a valid edit, incomplete JSON, or an input that had just failed validation.

The editor now records when the visitor has typed a draft. Renders preserve that text. A successful **Load into simulation** or an explicit **Export live world** returns the untouched editor to following live state. Failed loads retain the text for correction. The draft belongs to the current page and does not survive a reload. The workbench hint and frontend README explain these actions.

## Scope and composition

The production delta changes only the raw editor state in `web/airspace/src/main.ts`, its existing explanatory paragraph in `web/airspace/index.html`, and `web/airspace/README.md`. The maintained browser regression adds `web/airspace/tests/world-draft-browser.mjs`. No package or lockfile change is required.

The original canonical candidate is based on main `09b96e31d2867af5b7a9738406d0431cf1010090`, tree `4d22827647c0b2e37d11921aa5273f7a358bcdde`. Its native candidate source tree is `32c765094240d21d30b0ba5e1a25bd6f6d6d5b31`, preserving all 130 unrelated existing leaves.

Current-parent qualification then composed the same three contribution blobs over main `5ae808749c8624d9e267d23997beaa3ae5220dbc`, tree `356e66716c8953a3c2aac8a23790ce6eeaba20d0`. That candidate tree is `1524d65cf76e06a34f00e6713e21d9ad927b922d`, with all 133 unrelated current-parent leaves preserved. It retains all six paths from the intervening Python-audit wire contribution #38. Because three executed frontend modules changed, this composition received a fresh native build and an unchanged seven-case replay, rather than inheriting the older runtime result.

A separate receiving-only composition preserves cf5799f6d38b's existing scenario-file work. That owner's source tree `317ddf06e84c6b08f2e06ce634f5a64b264effd5` becomes `0d92beeef74ce8de97f5e989438b382182526fd0` after the same narrow editor correction. The original owner source, branch, dependency cache and browser profile were not edited. The source of the scenario-file capability is that existing contribution; this patch does not publish or claim it. The active encounter-explorer scope in TowerOps #37 is also separate.

The complete candidate source manifests and both diffs are in [source](source). Local qualification commits identify isolated copies; they are not upstream deployment records.

## Actual native receiving

The seven semantic browser cases were authored before the repair. Their final navigation-corrected receiver is frozen at SHA-256 `c6934f7207a38569908773cb264be34e7dacbb761fa0290ec88ae657d1a620fe`. These exact case bodies were used before and after the product change.

| Exact native input | Passed | Product failures |
| --- | ---: | --- |
| Preserved scenario-owner baseline | 4 of 7 | Valid draft, incomplete draft, and refused-load text erased by blur plus resize |
| Same owner composition plus this correction | 7 of 7 | None |
| Original main09b candidate without the scenario-file feature | 7 of 7 | None |
| Current main5ae candidate, including the new audit-wire inputs | 7 of 7 | None |

Each run used an actual built frontend, Chrome 154.0.8037.98 on the native Mac, a new profile, native pointer/text input and viewport changes. No application implementation was replaced by a test double. Source hashes were checked before and after the pinned runs; served HTML, JavaScript, CSS and favicon bytes were recorded. The successful runs had no browser exceptions or external page requests.

The four positive controls check initial live content, explicit Export replacing a draft, successful raw Load changing the actual world and resuming synchronization, and an untouched editor following a later traffic addition. The loss cases also explicitly export the live world afterward to establish that typing did not silently alter it. Authored text and observed after-resize text are preserved with each receipt.

The canonical and owner-composed candidates were freshly built with the existing native dependencies. Their ordinary Python-asset preparation, TypeScript check and Vite build succeeded. The build used a cache in our own namespace and native config loading; the owner's source and recorded dependency inputs were unchanged. Build receipts bind all output assets and the exact candidate source manifests. No new dependency installation or whole-estate build was performed.

[Build receipts](build), [frozen receiving](receiving), and [transport history](history) retain these distinctions. The [independent review](independent/acceptance.md) has a separately frozen contract and seven additional browser groups. Its corrected baseline showed four draft-loss failures and three passing controls; the exact owner-composed candidate passed all seven. The reviewer then independently verified the narrow source reversal and inspected desktop/mobile screenshots. Its observer correction is preserved. The [full 63-file packet](independent/root-receiving.tar.gz) retains every original byte, including actual scenario downloads, source-blind runners, native logs, and screenshots; [archive verification](independent/archive-verification.json) and the [export manifest](independent/export-manifest.json) bind it. Key raw receipts and the source review are also directly readable alongside the archive.

## Run the maintained regression

From a checkout, build the ordinary frontend first:

```sh
cd web/airspace
npm ci
npm run build
cd ../..
```

Then run the real browser regression, giving a new output directory:

```sh
CHROME_PATH=/path/to/chrome node web/airspace/tests/world-draft-browser.mjs . /tmp/towerops-world-draft-check
```

The test uses Node's built-in WebSocket API, so use a Node version that provides it. It needs an installed Chrome/Chromium executable. On macOS it defaults to the standard Chrome application path; `CHROME_PATH` can select another supported installation. It starts its own loopback server and isolated browser profile, refuses an existing output directory, and writes the actual observations and receipt there.

An optional third argument points to a source manifest with `files` entries containing `path`, `sha256` and `git_blob`. That form additionally checks every listed source file before and after receiving. Without a manifest, the receipt truthfully records no source pin and still records the actual served build assets. The no-manifest CLI route was executed successfully, 7 of 7, using the same semantic bodies.

## Qualification boundary

These are source and native browser results for the exact inputs above. They do not claim that the hosted page or any installed service has been updated. The scenario-file integration is receiving evidence for that preserved owner's composition, not evidence that its separate feature is on main. A future publication or integration must compare its actual parent and preserve unrelated source.
