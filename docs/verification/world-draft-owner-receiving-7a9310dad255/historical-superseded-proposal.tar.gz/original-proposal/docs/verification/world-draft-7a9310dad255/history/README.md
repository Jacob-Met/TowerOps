# Preserved receiver setup history

The product repair was not written until the final baseline executed all seven semantic groups.

| Receiver | Observed result | Interpretation |
| --- | --- | --- |
| Original | Page.navigate timed out; 0 product groups executed | Browser setup failure |
| v2 | Own HTTP self-check returned the exact owner index with status 200; Chrome navigation still timed out; 0 groups | Browser setup failure, with server and CDP diagnostics |
| v3 | A reset socket from the refusing background proxy raised an unhandled ECONNRESET; no receipt or product groups were completed | Receiver failure; stdout and stderr preserved. Its isolated browser was subsequently closed through its own CDP endpoint. |
| v4 | Actual page loaded; 3 draft-loss cases failed, initial/export passed, 2 live-control observations failed because their details section was closed | Mixed product evidence and receiver navigation errors, not a 2/7 product verdict |
| Frozen v5 | Actual page loaded; 4 controls passed and exactly 3 draft-loss cases failed | Clean baseline product result |

The v4 launcher isolated Chrome's password/keychain storage and handled reset errors on the refusing proxy socket. This permitted subsequent navigation; these observations do not establish a general Chrome or operating-system defect. v5 opened the real traffic-control details element and refused clicks on invisible or disabled controls. Its semantic case bodies remained unchanged. The source repair was then evaluated with that exact v5 receiver.

Original scripts, available raw receipts, stdout/stderr and outer execution records are retained here. Native network logs remain in the isolated execution directory and are catalogued by byte count and SHA-256 in `native-diagnostics.json`; they are not part of the product result.

During isolated source preparation, a separate assertion mistakenly compared the recursive-tree request selector with a Git tree identity. It stopped before canonical source edits. The actual upstream commit tree was then checked as `4d22827647c0b2e37d11921aa5273f7a358bcdde`, and every canonical source blob was checked before the correction. This preparation event did not alter the owner checkout or the native browser results.
