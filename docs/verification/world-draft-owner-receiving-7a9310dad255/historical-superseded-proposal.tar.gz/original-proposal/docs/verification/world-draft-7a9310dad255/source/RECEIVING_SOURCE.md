# Reconstruct the independently received scenario compositions

`owner-receiving-source.tar.gz` preserves the attributed source overlays for the unpublished scenario-file implementation used in these receiving runs. It is proof data; the production changes in this contribution are still limited to the three canonical draft-repair files and the maintained browser regression.

Archive SHA-256: `4dc41b7d2d1cc7befc302b938f041934746bfedbc7986cc0a6f4747de239d083`. Git blob: `aca8bfd74db787bb15e720a5d817650602b479e8`. The archive has 17 verified members and is 53,288 bytes.

Start from public commit `09b96e31d2867af5b7a9738406d0431cf1010090`, whose tree is `4d22827647c0b2e37d11921aa5273f7a358bcdde`. Follow the archive's README and manifest, preserving recorded file modes:

- Overlay all seven files in `scenario-owner-baseline` to reconstruct source tree `317ddf06e84c6b08f2e06ce634f5a64b264effd5`.
- Alternatively, overlay all seven files in `scenario-owner-with-draft-repair` on that same public base to reconstruct tree `0d92beeef74ce8de97f5e989438b382182526fd0`.
- The separate one-file `scenario-owner-with-draft-and-rate-repairs` overlay reconstructs tree `b286f94e169ad48ca90d607d2ef53ab311d76a85` when applied to the draft composition. That rate correction is separate work and is not installed by this contribution.

The scenario-file implementation belongs to estate `cf5799f6d38b`. The draft correction belongs to `7a9310dad255/memory`; the independent rate correction belongs to `7a9310dad255/root`. Every actual owner delta is included, including `style.css`. Public base files are referenced by immutable Git identity. The original source manifests, build receipts, browser runs, and root receiving archive remain unchanged.

The canonical publication is qualified separately against current parent `5ae808749c8624d9e267d23997beaa3ae5220dbc`. These overlays do not install the scenario feature, adopt the rate correction, or claim device deployment.
