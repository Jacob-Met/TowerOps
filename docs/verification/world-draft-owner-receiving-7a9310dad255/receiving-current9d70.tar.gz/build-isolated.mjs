import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=path.resolve(process.argv[2]);
const {build}=await import(pathToFileURL(path.join(root,'node_modules/vite/dist/node/index.js')).href);
await build({root,configLoader:'native',cacheDir:path.resolve(process.argv[3])});
