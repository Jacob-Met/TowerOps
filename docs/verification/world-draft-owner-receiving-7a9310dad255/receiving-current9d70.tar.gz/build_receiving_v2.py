from pathlib import Path
import subprocess,hashlib,json,time,os
root=Path('/home/jacob/hamon-7a9310dad255-tower-bd1')
candidate=root/'source-current9d70-owner';baseline=root/'source-current9d70-baseline'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
env=dict(os.environ);env['GIT_OPTIONAL_LOCKS']='0'
assert baseline.is_dir()
deps=(candidate/'web/airspace/node_modules').resolve()
assert (baseline/'web/airspace/node_modules').resolve()==deps
def check_source(r,m):
 for f in m['files']:
  b=(r/f['path']).read_bytes();assert sha(b)==f['sha256'] and git(b)==f['git_blob'],f['path']
selected=['typescript/bin/tsc','typescript/lib/tsc.js','vite/bin/vite.js','vite/dist/node/index.js','vitest/dist/config.js','pyodide/pyodide.mjs','pyodide/pyodide.asm.js','pyodide/pyodide.asm.wasm','pyodide/python_stdlib.zip','pyodide/pyodide-lock.json']
pins={}
for package in ['typescript','vite','vitest','pyodide']:
 b=(deps/package/'package.json').read_bytes();pins[package+'/package.json']={'sha256':sha(b),'bytes':len(b),'version':json.loads(b)['version']}
for name in selected:
 p=deps/name
 if p.exists():
  b=p.read_bytes();pins[name]={'sha256':sha(b),'bytes':len(b)}
reports=[]
for label,r,mp in [('baseline',baseline,root/'current9d70-manifest.json'),('owner',candidate,root/'source-current9d70-owner-manifest.json')]:
 m=json.loads(mp.read_text());check_source(r,m);front=r/'web/airspace';commands=[]
 tasks=[('prepare-python',['/usr/bin/node','prepare-python.mjs']),('typescript',['/usr/bin/node',str(front/'node_modules/typescript/bin/tsc'),'--noEmit']),('build',['/usr/bin/node','--experimental-strip-types',str(root/'build-isolated.mjs'),str(front),str(root/(label+'-vite-cache'))])]
 if label=='baseline':
  commands=json.loads((root/'baseline-build-failure.json').read_text())['commands'][:2]
  tasks=tasks[2:]
 for name,cmd in tasks:
  started=time.monotonic();p=subprocess.run(cmd,cwd=front,capture_output=True,timeout=90)
  (root/(label+'-'+name+'-v2.stdout.log')).write_bytes(p.stdout);(root/(label+'-'+name+'-v2.stderr.log')).write_bytes(p.stderr)
  commands.append({'name':name,'command':cmd,'cwd':str(front),'exit_code':p.returncode,'seconds':time.monotonic()-started,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
  if p.returncode:
   (root/(label+'-build-failure.json')).write_text(json.dumps({'commands':commands,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')},indent=2)+'\n')
   raise RuntimeError(label+' '+name+' failed: '+p.stderr.decode(errors='replace')[-2000:])
 check_source(r,m);assets=[]
 for p in sorted((front/'dist').rglob('*')):
  if p.is_file():
   b=p.read_bytes();assets.append({'path':str(p.relative_to(front/'dist')),'bytes':len(b),'sha256':sha(b)})
 report={'schema':'towerops.bd1-owner-build.v1','source':str(r),'parent':m['parent'],'source_tree':m['source_tree'],'source_manifest_sha256':sha(mp.read_bytes()),'source_files':len(m['files']),'source_unchanged':True,'first_environment_failure_preserved':'baseline-build-failure.json; no browser cases ran before Node22 TypeScript-load flag adjustment','node':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip(),'commands':commands,'dependency_root':str(deps),'dependency_pins':pins,'assets':assets,'boundary':'Exact current-main baseline and preserved bd1 source composition, compiled in this receiver namespace from existing read-only native dependency inputs. No owner source, dependency, profile or installed service write.'}
 out=root/(label+'-build-receipt.json');out.write_text(json.dumps(report,indent=2)+'\n');reports.append({'label':label,'receipt':str(out),'sha256':sha(out.read_bytes()),'assets':len(assets),'commands':[{k:x[k] for k in ['name','exit_code','seconds']} for x in commands]});print(json.dumps(reports[-1]),flush=True)
for name,pin in pins.items():assert sha((deps/name).read_bytes())==pin['sha256'],name
custody=json.loads((root/'owner-read-custody.json').read_text())
for f in custody['owner_before']:
 b=(Path(custody['owner_root'])/f['path']).read_bytes();assert sha(b)==f['sha256'],'Owner input drift: '+f['path']
(root/'builds-summary.json').write_text(json.dumps({'reports':reports,'owner_source_unchanged':True,'dependency_inputs_unchanged':True},indent=2)+'\n')
