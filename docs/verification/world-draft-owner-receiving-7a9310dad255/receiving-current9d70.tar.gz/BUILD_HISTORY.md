# Native receiving setup history

The original frozen browser behavior was authored before reading bd1's candidate. The ThinkPad copy changes only the Chrome executable path. Both current-main baseline and preserved-owner candidate then completed all seven groups in real Chromium.

The first isolated build used the earlier Mac native TypeScript-config loader and stopped with ERR_UNKNOWN_FILE_EXTENSION. The second added Node's documented stripping flag, but this installed Node22 was compiled without TypeScript support. Neither attempt ran browser cases or changed product source. Both raw build logs and wrapper versions remain here. The aggregate baseline-build-failure.json was replaced by the second failed invocation; the original first-attempt stdout/stderr remain byte-exact and are the retained first-failure evidence.

The final wrapper reads the unchanged two-line JavaScript configuration as an owned, byte-identical .mjs file, then calls the existing Vite build with an owned cache directory. Original .ts configuration, all source files and selected dependency inputs were checked. Both builds succeeded. The subsequent source-custody comparison observed the owner updating its README in parallel, so it did not assert that the owner's work stopped. Our captured inputs remained exact and receiving stayed bound to them.
