from pathlib import Path
import subprocess,json,hashlib,time,os
root=Path('/home/jacob/hamon-7a9310dad255-tower-bd1')
sha=lambda b:hashlib.sha256(b).hexdigest()
custody=json.loads((root/'owner-read-custody.json').read_text())
changes=[]
for f in custody['owner_before']:
 p=Path(custody['owner_root'])/f['path']
 current=sha(p.read_bytes()) if p.exists() else None
 if current!=f['sha256']:changes.append({'path':f['path'],'captured_sha256':f['sha256'],'current_sha256':current})
(root/'owner-concurrent-update.json').write_text(json.dumps({'observed_after_isolated_build':True,'changes':changes,'receiving_remains_bound_to_captured_source':True,'owner_paths_were_read_only':True},indent=2)+'\n')
for label in ['baseline','owner']:
 source=root/('source-current9d70-baseline' if label=='baseline' else 'source-current9d70-owner')
 mp=root/('current9d70-manifest.json' if label=='baseline' else 'source-current9d70-owner-manifest.json')
 out=root/(label+'-receiving')
 cmd=['/usr/bin/node',str(root/'receiver_thinkpad.mjs'),str(source),str(mp),str(out)]
 start=time.monotonic()
 p=subprocess.run(cmd,capture_output=True,timeout=90)
 (root/(label+'-receiving.stdout.log')).write_bytes(p.stdout);(root/(label+'-receiving.stderr.log')).write_bytes(p.stderr)
 rp=out/'receipt.json';receipt=json.loads(rp.read_text()) if rp.exists() else None
 result={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'receipt_path':str(rp),'receipt_sha256':sha(rp.read_bytes()) if rp.exists() else None,'receiver_sha256':sha((root/'receiver_thinkpad.mjs').read_bytes()),'source_manifest_sha256':sha(mp.read_bytes()),'result':receipt}
 (root/(label+'-receiving-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'label':label,'exit_code':p.returncode,'seconds':result['seconds'],'receipt_sha256':result['receipt_sha256'],'receipt':receipt,'stderr':p.stderr.decode(errors='replace')}),flush=True)
 if not receipt or receipt.get('fatal') or len(receipt.get('checks',[]))!=7:raise RuntimeError('Native receiver did not complete seven groups; candidate held')
 if label=='baseline' and sum(bool(x['passed']) for x in receipt['checks'])!=4:raise RuntimeError('Baseline differs from expected three product failures; inspect before candidate')
