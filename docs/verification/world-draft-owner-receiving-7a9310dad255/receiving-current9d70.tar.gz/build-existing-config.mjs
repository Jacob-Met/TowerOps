import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=path.resolve(process.argv[2]);
const config=path.join(root,'vite.receiving.config.mjs');
const original=await fs.readFile(path.join(root,'vite.config.ts'));
await fs.writeFile(config,original,{flag:'wx'});
const {build}=await import(pathToFileURL(path.join(root,'node_modules/vite/dist/node/index.js')).href);
await build({root,configFile:config,configLoader:'native',cacheDir:path.resolve(process.argv[3])});
