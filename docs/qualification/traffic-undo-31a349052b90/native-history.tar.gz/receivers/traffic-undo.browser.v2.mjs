#!/usr/bin/env node
// Uses the repository's existing CDP transport pattern with an isolated static build/profile.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {readFile,writeFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {join,resolve,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';

const args=process.argv.slice(2);
const option=(name,fallback)=>args.includes(name)?args[args.indexOf(name)+1]:fallback;
const root=resolve(option('--root',process.cwd()));
const output=resolve(option('--output',root+'-traffic-undo-receiving'));
const built=resolve(option('--dist',join(root,'web/airspace/dist')));
const executable=option('--browser','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
const delivery=option('--delivery','http');
assert.ok(['http','cdp'].includes(delivery),'delivery must be http or cdp');
await mkdir(output,{recursive:true});
const sha=data=>createHash('sha256').update(data).digest('hex');
const sourceFiles=[...new Set(execFileSync('git',['-C',root,'ls-files','--cached','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0').filter(Boolean))];
const snapshot=()=>Object.fromEntries(sourceFiles.map(path=>[path,sha(fs.readFileSync(join(root,path)))]));
const beforeSource=snapshot();
function filesBelow(path,base=path){
 return fs.readdirSync(path,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?filesBelow(join(path,entry.name),base):[{path:join(path,entry.name).slice(base.length+1),sha256:sha(fs.readFileSync(join(path,entry.name))),bytes:fs.statSync(join(path,entry.name)).size}]);
}
const beforeBuild=filesBelow(built);
const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.mjs':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.py':'text/x-python;charset=utf-8','.wasm':'application/wasm','.zip':'application/zip','.png':'image/png','.svg':'image/svg+xml'};
const server=createServer((req,res)=>{
 let path;try{path=resolve(built,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));}catch{res.writeHead(400);res.end();return;}
 if(path!==built&&!path.startsWith(built+sep)){res.writeHead(403);res.end();return;}
 if(path===built||fs.existsSync(path)&&fs.statSync(path).isDirectory())path=join(path,'index.html');
 if(!fs.existsSync(path)||!fs.statSync(path).isFile()){res.writeHead(404);res.end();return;}
 res.setHeader('Content-Type',mime[extname(path)]||'application/octet-stream');
 res.setHeader('Cache-Control','no-store');fs.createReadStream(path).pipe(res);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
const profile=await mkdtemp(join(output,'profile-'));
const report={kind:'traffic-undo-actual-built-browser-v1',receiverSha256:sha(await readFile(fileURLToPath(import.meta.url))),root,built,base,node:process.version,startedAt:new Date().toISOString(),baseCommit:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceBefore:beforeSource,buildBefore:beforeBuild,checks:[],observations:[],pageErrors:[],requests:[],downloads:[],inputMethod:'Native CDP mouse events and Input.insertText after explicit DOM focus/selection; no product function or worker-result substitute.'};
let browser,browserClosed,socket,sessionId,browserLog='',sequence=0;
const pending=new Map(),sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitFor(check,label,attempts=200){let last;for(let i=0;i<attempts;i++){try{if(await check())return;}catch(error){last=error;}await sleep(100);}throw Error('Timed out: '+label+(last?' '+last.message:''));}
function command(method,params={},scoped=true,scope=sessionId){const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},10000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...scoped&&scope?{sessionId:scope}:{}}));});}
const deliveryRequests=[],deliveryErrors=[];
async function fulfillStatic(msg){
 const {requestId,request}=msg.params,scope=msg.sessionId;
 try{
  assert.ok(request.url.startsWith(base+'/'),'Static carrier only serves its own origin');
  let path=resolve(built,'.'+decodeURIComponent(new URL(request.url).pathname));
  assert.ok(path===built||path.startsWith(built+sep),'Static path stays within the exact build');
  if(path===built||fs.existsSync(path)&&fs.statSync(path).isDirectory())path=join(path,'index.html');
  const exists=fs.existsSync(path)&&fs.statSync(path).isFile(),data=exists?await readFile(path):Buffer.from('Not found');
  deliveryRequests.push({url:request.url,path:exists?path.slice(built.length+1):null,status:exists?200:404,bytes:data.length,sha256:sha(data),sessionId:scope});
  await command('Fetch.fulfillRequest',{requestId,responseCode:exists?200:404,responseHeaders:[{name:'Content-Type',value:mime[extname(path)]||'application/octet-stream'},{name:'Cache-Control',value:'no-store'}],body:data.toString('base64')},true,scope);
 }catch(error){deliveryErrors.push(error.stack);await command('Fetch.failRequest',{requestId,errorReason:'Failed'},true,scope).catch(()=>{});}
}
async function attachDelivery(msg){
 const scope=msg.params.sessionId;
 try{
  await command('Fetch.enable',{patterns:[{urlPattern:base+'/*',requestStage:'Request'}]},true,scope);
  await command('Runtime.enable',{},true,scope);
  await command('Runtime.runIfWaitingForDebugger',{},true,scope);
 }catch(error){deliveryErrors.push(error.stack);}
}
async function evaluate(expression){const result=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description??result.exceptionDetails.text);return result.result.value;}
async function click(selector){
 const point=await evaluate('(()=>{const node=document.querySelector('+JSON.stringify(selector)+');if(!node)throw Error("Missing element: "+'+JSON.stringify(selector)+');node.scrollIntoView({block:"center"});const r=node.getBoundingClientRect();if(!r.width||!r.height)throw Error("Hidden element");if(node.disabled)throw Error("Disabled element");return {x:r.x+r.width/2,y:r.y+r.height/2};})()');
 for(const type of ['mouseMoved','mousePressed','mouseReleased'])await command('Input.dispatchMouseEvent',{type,...point,...type==='mouseMoved'?{}:{button:'left',clickCount:1}});
}
async function openDetails(selector){if(!await evaluate('document.querySelector('+JSON.stringify(selector)+').open'))await click(selector+' > summary');}
async function fill(selector,text){
 await click(selector);
 await evaluate('(()=>{const node=document.querySelector('+JSON.stringify(selector)+');node.focus();node.select();})()');
 await command('Input.insertText',{text});
 assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'),text,'native inserted input matches');
}
const editor=()=>evaluate('document.querySelector("#world-json").value');
const live=async()=>JSON.parse(await editor());
const selected=()=>evaluate('document.querySelector("#flight-list .selected button")?.textContent');
const ids=()=>evaluate('[...document.querySelectorAll("#flight-list button")].map(node=>node.textContent)');
async function selectFlight(id){
 const index=await evaluate('[...document.querySelectorAll("#flight-list button")].findIndex(node=>node.textContent==='+JSON.stringify(id)+')');
 assert.ok(index>=0);await click('#flight-list .flight-row:nth-child('+(index+1)+') button');assert.equal(await selected(),id);
}
async function screenshot(name){
 const result=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
 const data=Buffer.from(result.data,'base64');await writeFile(join(output,name),data);report.observations.push({screenshot:name,bytes:data.length,sha256:sha(data)});
}
const authoredWorld={version:17,observed_at:2400,aircraft:[
 {aircraft_id:'UNDO101',x_nm:-7.25,y_nm:1.125,altitude_ft:10000,vx_nm_min:1.375,vy_nm_min:0,climb_ft_min:0},
 {aircraft_id:'UNDO202',x_nm:7.75,y_nm:1.125,altitude_ft:10000,vx_nm_min:-1.625,vy_nm_min:0,climb_ft_min:0},
 {aircraft_id:'UNDO303',x_nm:9.875,y_nm:-8.625,altitude_ft:24000,vx_nm_min:0.125,vy_nm_min:0.75,climb_ft_min:-125}
]};
async function navigate(world=authoredWorld){
 await command('Emulation.setDeviceMetricsOverride',{width:1280,height:960,deviceScaleFactor:1,mobile:false});
 await command('Page.navigate',{url:base+'/'});
 await waitFor(()=>evaluate('document.readyState==="complete" && !!document.querySelector("#world-json")?.value && document.querySelector("#flight-list")?.children.length>0'),'actual built workbench ready');
 await openDetails('.state-workbench');
 await fill('#world-json',JSON.stringify(world,null,2));await click('#load-world');
 await waitFor(async()=>JSON.stringify(await ids())===JSON.stringify(world.aircraft.map(a=>a.aircraft_id)),'authored world loaded');
 await openDetails('details.control-card');await openDetails('.telemetry-wrap');
 assert.deepEqual(await live(),world);
}
async function undo(){
 const exists=await evaluate('!!document.querySelector("#undo-traffic-edit")');
 assert.ok(exists,'the actual workbench must expose Undo last traffic edit');
 assert.equal(await evaluate('document.querySelector("#undo-traffic-edit").disabled'),false,'undo must be available for this exact edit');
 await click('#undo-traffic-edit');
}
async function check(name,run){try{await run();report.checks.push({name,status:'passed'});console.log('PASS '+name);}catch(error){report.checks.push({name,status:'failed',error:error.stack});console.log('FAIL '+name+': '+error.message);}}
try{
 browser=spawn(executable,['--headless=new','--no-sandbox','--disk-cache-size=1','--media-cache-size=1','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
 browserClosed=new Promise(resolve=>{browser.once('close',resolve);browser.once('error',resolve);});
 browser.stderr.on('data',data=>{browserLog=(browserLog+data.toString()).slice(-10000);});
 let launchError,port,endpoint;browser.on('error',error=>{launchError=error;});
 await waitFor(async()=>{if(launchError)throw launchError;if(browser.exitCode!==null)throw Error('Browser exited '+browser.exitCode+' '+browserLog);[port,endpoint]=(await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');return port&&endpoint;},'private browser startup');
 socket=new WebSocket('ws://127.0.0.1:'+port+endpoint);
 socket.addEventListener('message',event=>{
  const msg=JSON.parse(event.data);
  if(msg.id){const task=pending.get(msg.id);if(!task)return;pending.delete(msg.id);clearTimeout(task.timer);msg.error?task.reject(Error(msg.error.message)):task.resolve(msg.result);}
  else if(delivery==='cdp'&&msg.method==='Fetch.requestPaused')void fulfillStatic(msg);
  else if(delivery==='cdp'&&msg.method==='Target.attachedToTarget')void attachDelivery(msg);
  else if(msg.method==='Runtime.exceptionThrown')report.pageErrors.push(msg.params.exceptionDetails.exception?.description??msg.params.exceptionDetails.text);
  else if(msg.method==='Network.requestWillBeSent')report.requests.push(msg.params.request.url);
  else if(msg.method==='Browser.downloadWillBegin'||msg.method==='Browser.downloadProgress')report.downloads.push({method:msg.method,...msg.params});
 });
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 report.browser=await command('Browser.getVersion',{},false);
 const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
 ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
 await command('Page.enable');await command('Runtime.enable');await command('Network.enable');
 if(delivery==='cdp'){
  await command('Fetch.enable',{patterns:[{urlPattern:base+'/*',requestStage:'Request'}]});
  await command('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true});
 }
 await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath:output,eventsEnabled:true},false);
 await command('Page.addScriptToEvaluateOnNewDocument',{source:'window.__trafficUndoWorkerMessages=[];(()=>{const original=Worker.prototype.postMessage;const seen=new WeakSet();Worker.prototype.postMessage=function(message,...rest){if(!seen.has(this)){seen.add(this);this.addEventListener("message",event=>window.__trafficUndoWorkerMessages.push({direction:"received",data:structuredClone(event.data)}));}window.__trafficUndoWorkerMessages.push({direction:"sent",data:structuredClone(message)});return Reflect.apply(original,this,[message,...rest]);};})();'});
 await check('an accidental selected-flight removal can be recovered exactly',async()=>{
  await navigate();await selectFlight('UNDO202');const before=await live();await click('#remove-selected');
  await waitFor(async()=>(await ids()).length===2,'successful accidental removal');const removed=await live();
  assert.deepEqual(removed.aircraft,before.aircraft.filter(a=>a.aircraft_id!=='UNDO202'));assert.equal(removed.version,before.version+1);
  report.observations.push({name:'accidental-removal',before,removed,selectedAfterRemoval:await selected(),undoPresent:await evaluate('!!document.querySelector("#undo-traffic-edit")')});
  await screenshot('removal-before-undo.png');await undo();
  const recovered=await live();assert.deepEqual(recovered.aircraft,before.aircraft);assert.equal(await selected(),'UNDO202');assert.equal(recovered.version,removed.version+1);assert.equal(recovered.observed_at,before.observed_at);
  assert.equal(await evaluate('document.querySelector("#undo-traffic-edit").disabled'),true,'the one-step entry is consumed');
  report.observations.push({name:'removal-recovered',recovered,selected:await selected()});await screenshot('removal-recovered.png');
 });
 await check('a refused duplicate callsign keeps the original world and editable input',async()=>{
  await navigate();const before=await live();await fill('#flight-id','UNDO202');await click('#add-custom-flight');
  assert.match(await evaluate('document.querySelector("#builder-feedback").textContent'),/NOT ADDED/);
  assert.deepEqual(await live(),before);assert.equal(await evaluate('document.querySelector("#flight-id").value'),'UNDO202');assert.equal(await selected(),'UNDO101');
 });
 await check('an authored raw JSON draft survives a successful native traffic perturbation',async()=>{
  await navigate();const before=await live(),draft='{"keep my unfinished draft": ';
  await fill('#world-json',draft);await click('#perturb-track');assert.equal(await editor(),draft);assert.equal(await selected(),'UNDO101');
  await click('#export-world');const changed=await live(),expected=structuredClone(before);
  expected.version++;expected.aircraft[0].vx_nm_min+=0.4;expected.aircraft[0].vy_nm_min+=0.3;
  assert.deepEqual(changed,expected);
 });
 report.workerMessages=await evaluate('window.__trafficUndoWorkerMessages');
 assert.deepEqual(report.pageErrors,[],'actual page has no unhandled errors');
 assert.deepEqual(deliveryErrors,[],'static byte carrier has no delivery errors');
 assert.deepEqual(report.requests.filter(url=>/^https?:/.test(url)&&!url.startsWith(base+'/')),[],'no non-loopback page requests');
}catch(error){report.fatal=error.stack;console.log('FATAL '+error.stack);}
finally{
 report.sourceAfter=snapshot();report.sourceChanged=sourceFiles.filter(path=>beforeSource[path]!==report.sourceAfter[path]);
 report.buildAfter=filesBelow(built);report.buildChanged=JSON.stringify(beforeBuild)!==JSON.stringify(report.buildAfter);
 try{
  if(socket?.readyState===WebSocket.OPEN)await Promise.race([command('Browser.close',{},false).catch(()=>{}),browserClosed,sleep(1000)]);
  if(browserClosed)await Promise.race([browserClosed,sleep(5000)]);
  if(browser&&browser.exitCode===null&&browser.signalCode===null){browser.kill('SIGTERM');await Promise.race([browserClosed,sleep(5000)]);}
  socket?.close();for(const task of pending.values())clearTimeout(task.timer);pending.clear();
  await new Promise(resolve=>server.close(resolve));await rm(profile,{recursive:true,force:true,maxRetries:4,retryDelay:100});
  report.cleanup={status:'passed',privateProfileRemoved:!fs.existsSync(profile)};
 }catch(error){report.cleanup={status:'failed',error:error.stack};}
 report.delivery={method:delivery,description:delivery==='cdp'?'Exact immutable build bytes carried through CDP Fetch.fulfillRequest; actual browser and Python worker execution, not an HTTP-delivery claim.':'Actual loopback HTTP server.',requests:deliveryRequests,errors:deliveryErrors};
 report.browserLog=browserLog;report.finishedAt=new Date().toISOString();
 report.status=!report.fatal&&report.checks.every(check=>check.status==='passed')&&!report.sourceChanged.length&&!report.buildChanged&&report.cleanup.status==='passed'?'passed':'failed';
 await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,passed:report.checks.filter(check=>check.status==='passed').length,failed:report.checks.filter(check=>check.status==='failed').length,pageErrors:report.pageErrors.length,sourceChanged:report.sourceChanged,buildChanged:report.buildChanged,cleanup:report.cleanup,report:join(output,'browser-report.json')}));
 if(report.status!=='passed')process.exitCode=1;
}
