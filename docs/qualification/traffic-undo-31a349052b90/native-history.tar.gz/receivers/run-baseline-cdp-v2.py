import pathlib,subprocess,json,hashlib,tarfile,shutil,os,datetime
r=pathlib.Path('/Users/me/hamon-towerops-undo-31a349052b90')
assert shutil.disk_usage(r).free>128*1024**2
worktree=r/'baseline-browser-source'; extracted=r/'baseline-browser-build'
assert not worktree.exists() and not extracted.exists()
subprocess.run(['git','-C',str(r/'source'),'worktree','add','--detach',str(worktree),'093f88b29d6e1ede778f967528c7e010b7689ab1'],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert subprocess.check_output(['git','-C',str(worktree),'rev-parse','HEAD'],text=True).strip()=='093f88b29d6e1ede778f967528c7e010b7689ab1'
archive=r/'evidence/static-baseline-input/input.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='7729f502f6128694234596734a157c11a10ac0e7629c4ba0547112872ddb1db4'
extracted.mkdir()
with tarfile.open(archive,'r:gz') as tar: tar.extractall(extracted,filter='data')
manifest=json.loads((extracted/'input-manifest.json').read_text())
for member in manifest['build']:
 p=extracted/'dist'/member['path'];assert p.is_file() and p.stat().st_size==member['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==member['sha256']
assert len([p for p in (extracted/'dist').rglob('*') if p.is_file()])==len(manifest['build'])
command=['/opt/homebrew/bin/node',str(r/'receivers/traffic-undo.browser.v2.mjs'),'--root',str(worktree),'--dist',str(extracted/'dist'),'--output',str(r/'evidence/browser-baseline-cdp-v2'),'--delivery','cdp']
out=r/'evidence/browser-baseline-cdp-v2.stdout.log';err=r/'evidence/browser-baseline-cdp-v2.stderr.log'
with out.open('wb') as o,err.open('wb') as e: result=subprocess.run(command,stdout=o,stderr=e,timeout=150,env={**os.environ,'TMPDIR':str(r/'tmp')})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit':result.returncode,'baseline_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest()}
(r/'evidence/browser-baseline-cdp-v2-run.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print(out.read_text()[-4000:]);print(err.read_text()[-1000:])
