import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/Users/me/hamon-towerops-undo-31a349052b90';
const source=root+'/source';
const inputs=JSON.parse(fs.readFileSync(root+'/receivers/preservation-input.json','utf8'));
const path='web/airspace/src/main.ts';
const before=execFileSync('git',['-C',source,'show',inputs.base+':'+path],{encoding:'utf8'});
const after=fs.readFileSync(source+'/'+path,'utf8');
let restored=after;
function removeOnce(needle,replacement=''){assert.equal(restored.split(needle).length,2,needle);restored=restored.replace(needle,replacement);}
removeOnce("import { TrafficEditUndo } from './traffic-undo';\n");
removeOnce(inputs.addedMainBlock);
removeOnce(' decisionTrace.setBusy(busy);\n syncTrafficUndo();',' decisionTrace.setBusy(busy);');
for(const [previous,current] of inputs.listenerChanges)removeOnce(current,previous);
removeOnce("$('undo-traffic-edit').addEventListener('click',undoTrafficEdit);\n");
removeOnce("$('toggle-run').addEventListener('click',syncTrafficUndo);\n");
assert.equal(restored,before,'all original main bytes preserved outside the explicit additive seams');
const require=createRequire(import.meta.url);
const ts=require(source+'/web/airspace/node_modules/typescript');
const functions=text=>Object.fromEntries(ts.createSourceFile('main.ts',text,ts.ScriptTarget.Latest,true).statements.filter(ts.isFunctionDeclaration).map(node=>[node.name.text,node.getText()]));
const oldFunctions=functions(before),newFunctions=functions(after),preserved=[];
for(const [name,body] of Object.entries(oldFunctions)){
 const expected=name==='render'?body.replace(' decisionTrace.setBusy(busy);',' decisionTrace.setBusy(busy);\n syncTrafficUndo();'):body;
 assert.equal(newFunctions[name],expected,name+' preserved');preserved.push(name);
}
const sha=data=>createHash('sha256').update(data).digest('hex');
const report={base:inputs.base,beforeSha256:sha(before),afterSha256:sha(after),allOriginalBytesOutsideDeclaredSeams:true,existingFunctionsChecked:preserved.length,existingFunctions:preserved,renderOnlyAddition:'syncTrafficUndo()',newFunctions:Object.keys(newFunctions).filter(name=>!oldFunctions[name])};
fs.writeFileSync(root+'/evidence/candidate-main-preservation-v1.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
