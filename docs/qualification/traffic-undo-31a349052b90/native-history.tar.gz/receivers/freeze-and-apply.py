import pathlib, subprocess, json, hashlib, shutil, tarfile, datetime, os
r=pathlib.Path('/Users/me/hamon-towerops-undo-31a349052b90')
source=r/'source'; evidence=r/'evidence'
assert shutil.disk_usage(r).free>256*1024**2
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
assert git('rev-parse','HEAD')=='093f88b29d6e1ede778f967528c7e010b7689ab1'
assert not git('status','--porcelain')
built=source/'web/airspace/dist'
out=evidence/'static-baseline-input'; out.mkdir(exist_ok=False)
files=[{'path':str(p.relative_to(built)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(built.rglob('*')) if p.is_file()]
receipt=evidence/'baseline-source-freeze.json'
manifest={'kind':'exact-native-Mac-built-static-transfer','baseCommit':git('rev-parse','HEAD'),'baseTree':git('rev-parse','HEAD^{tree}'),'sourceReceipt':{'path':'baseline-source-freeze.json','sha256':hashlib.sha256(receipt.read_bytes()).hexdigest()},'build':files}
(out/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'input.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    tar.add(built,arcname='dist');tar.add(receipt,arcname='baseline-source-freeze.json');tar.add(out/'input-manifest.json',arcname='input-manifest.json')
print(json.dumps({'baseline_archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'build_files':len(files),'build_bytes':sum(f['bytes'] for f in files)}),flush=True)
env={**os.environ,'GIT_TERMINAL_PROMPT':'0'}
for name,args in [('fetch',['git','-C',str(source),'fetch','--no-tags','origin','53aa5048b6585aa08592d5513cfcf555a8bba018']),('checkout',['git','-C',str(source),'checkout','--detach','53aa5048b6585aa08592d5513cfcf555a8bba018'])]:
    with (evidence/f'candidate-base-{name}.stdout.log').open('wb') as outlog,(evidence/f'candidate-base-{name}.stderr.log').open('wb') as errlog:
        result=subprocess.run(args,env=env,stdout=outlog,stderr=errlog,timeout=90)
    assert result.returncode==0,(name,result.returncode)
assert git('rev-parse','HEAD')=='53aa5048b6585aa08592d5513cfcf555a8bba018'
assert not git('status','--porcelain')
expected={'web/airspace/src/main.ts':'e29d9ea54665e0c93e2baa66e45fa08e12b52203','web/airspace/index.html':'fb2b2c2b9f0b1f1ea31c14191af328ef09d9e1ec'}
inputs=json.loads((r/'receivers/candidate-input.json').read_text())
assert set(inputs)==set(expected)|{'web/airspace/src/traffic-undo.ts','web/airspace/tests/traffic-undo.test.ts'}
base_files={}
for path,text in inputs.items():
    target=source/path
    if path in expected:
        assert git('hash-object',str(target))==expected[path]
        base_files[path]={'blob':expected[path],'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    else: assert not target.exists(),path
for path,text in inputs.items():
    target=source/path;target.write_text(text);assert target.read_text()==text
readback={path:{'blob':git('hash-object',str(source/path)),'sha256':hashlib.sha256((source/path).read_bytes()).hexdigest(),'bytes':(source/path).stat().st_size} for path in inputs}
subprocess.run(['git','-C',str(source),'diff','--check'],check=True)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'base_files':base_files,'candidate':readback,'status':git('status','--porcelain'),'free_after':shutil.disk_usage(r).free}
(evidence/'candidate-source-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
