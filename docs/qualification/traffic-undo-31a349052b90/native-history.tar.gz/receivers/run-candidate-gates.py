import pathlib,subprocess,json,hashlib,datetime,os,shutil
r=pathlib.Path('/Users/me/hamon-towerops-undo-31a349052b90'); source=r/'source'; evidence=r/'evidence'
assert shutil.disk_usage(r).free>128*1024**2
env={**os.environ,'PATH':'/opt/homebrew/bin:'+os.environ.get('PATH',''),'TMPDIR':str(r/'tmp'),'npm_config_cache':str(r/'dependency-cache'),'npm_config_update_notifier':'false'}
commands=[('candidate-preservation-v1',['/opt/homebrew/bin/node',str(r/'receivers/check-main-preservation.mjs')],source),('candidate-vitest-v1',['/opt/homebrew/bin/npm','test','--','--reporter=verbose'],source/'web/airspace'),('candidate-build-v1',['/opt/homebrew/bin/npm','run','build'],source/'web/airspace')]
results=[]
for name,command,cwd in commands:
 with (evidence/f'{name}.stdout.log').open('wb') as out,(evidence/f'{name}.stderr.log').open('wb') as err:
  result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=err,timeout=180)
 item={'name':name,'command':command,'cwd':str(cwd),'exit':result.returncode,'stdout_sha256':hashlib.sha256((evidence/f'{name}.stdout.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((evidence/f'{name}.stderr.log').read_bytes()).hexdigest()}
 results.append(item); print(json.dumps(item),flush=True)
 print((evidence/f'{name}.stdout.log').read_text()[-7000:],flush=True)
 if result.returncode:
  print((evidence/f'{name}.stderr.log').read_text()[-7000:],flush=True)
  break
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_receipt_sha256':hashlib.sha256((evidence/'candidate-source-v1.json').read_bytes()).hexdigest(),'commands':results,'status':'passed' if len(results)==len(commands) and all(x['exit']==0 for x in results) else 'failed'}
(evidence/'candidate-native-gates-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'receipt_sha256':hashlib.sha256((evidence/'candidate-native-gates-v1.json').read_bytes()).hexdigest()}))
