import sys,pathlib,hashlib,json
from dataclasses import asdict
r=pathlib.Path('/Users/me/hamon-towerops-undo-31a349052b90/source')
sys.path.insert(0,str(r))
worker=(r/'web/airspace/src/python-worker.ts').read_bytes()
assert hashlib.sha1(b'blob '+str(len(worker)).encode()+b'\0'+worker).hexdigest()=='b1c4218b2abd5d444687d0b728bce70509df8b01'
native=(r/'towerops.py').read_bytes()
assert hashlib.sha256(native).hexdigest()=='6c0634e2ff02f38ff99a0983d5a3564b877553cf2f426e0da269cbd5a48c7874'
bootstrap=worker.decode().split('await py.runPythonAsync(`',1)[1].split('`);',1)[0]
scope={};exec(bootstrap,scope)
state={'version':17,'observed_at':2400,'aircraft':[
{'aircraft_id':'UNDO101','x_nm':-7.25,'y_nm':1.125,'altitude_ft':10000,'vx_nm_min':1.375,'vy_nm_min':0,'climb_ft_min':0},
{'aircraft_id':'UNDO202','x_nm':7.75,'y_nm':1.125,'altitude_ft':10000,'vx_nm_min':-1.625,'vy_nm_min':0,'climb_ft_min':0},
{'aircraft_id':'UNDO303','x_nm':9.875,'y_nm':-8.625,'altitude_ft':24000,'vx_nm_min':0.125,'vy_nm_min':0.75,'climb_ft_min':-125}]}
policy=asdict(scope['SafetyPolicy']())
call=lambda q:json.loads(scope['browser_request'](json.dumps(q)))
first=call({'op':'plan','state':state,'policy':policy,'now':2400})['advisory'];assert first
h=first['advisory_hash']
applied=call({'op':'apply','state':state,'advisory':first,'approval':{'advisory_hash':h,'decision':'approve','approved_at':2400.2,'approver':'synthetic-controller'},'ack':{'advisory_hash':h,'status':'accepted','acknowledged_at':2400.4},'now':2400.5,'policy':policy,'audit_json':'[]'})
assert applied.get('valid') and len(applied['events'])==4,applied
added={**applied['state'],'version':applied['state']['version']+1,'observed_at':2400.5,'aircraft':[*applied['state']['aircraft'],{'aircraft_id':'TWR820','x_nm':0,'y_nm':-5,'altitude_ft':10000,'vx_nm_min':0,'vy_nm_min':1,'climb_ft_min':0}]}
second=call({'op':'plan','state':added,'policy':policy,'now':2400.5})['advisory'];assert second
print(json.dumps({'kind':'native-Python-fixture-control-not-browser-acceptance','python':sys.version.split()[0],'worker_blob':'b1c4218b2abd5d444687d0b728bce70509df8b01','towerops_sha256':hashlib.sha256(native).hexdigest(),'bootstrap_sha256':hashlib.sha256(bootstrap.encode()).hexdigest(),'first_proposal':first,'applied':applied,'second_proposal':second,'status':'passed'}))
