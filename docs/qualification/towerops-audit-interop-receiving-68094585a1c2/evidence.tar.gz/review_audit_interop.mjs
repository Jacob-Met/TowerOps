// Independent receiving controls. Native sources stay unchanged; TypeScript's
// actual compiler runs in memory and resolves the verifier's sole local import.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = dirname(fileURLToPath(import.meta.url));
const variant = process.env.REVIEW_VARIANT ?? 'candidate';
const optimize = process.env.REVIEW_OPTIMIZE === '1';
const compilerPath = process.env.REVIEW_TYPESCRIPT ??
  '/workspace/scratch/68094585a1c2/production/towerops/web/airspace/node_modules/typescript';
const ts = createRequire(import.meta.url)(compilerPath);
const pins = JSON.parse(readFileSync(join(root, 'source-pins.json'), 'utf8'));
for (const pin of pins.baseline) {
  assert.equal(createHash('sha256').update(readFileSync(join(root, 'baseline', pin.path))).digest('hex'),
    pin.sha256, `native input moved: ${pin.path}`);
}
assert.equal(createHash('sha256').update(readFileSync(join(root, 'candidate', pins.candidate.path))).digest('hex'),
  pins.candidate.sha256, 'frozen candidate moved');

function compileNative(name, imports = {}) {
  const source = readFileSync(join(root, 'baseline/web/airspace/src', `${name}.ts`), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
    reportDiagnostics: true,
  });
  assert.equal(compiled.diagnostics?.length ?? 0, 0, `TypeScript compile diagnostics: ${name}`);
  const module = { exports: {} };
  const resolve = name => {
    assert.ok(Object.hasOwn(imports, name), `unprovided native import ${name}`);
    return imports[name];
  };
  Function('require', 'module', 'exports', compiled.outputText)(resolve, module, module.exports);
  return module.exports;
}
const core = compileNative('core');
const { AuditLog } = compileNative('audit', { './core': core });

function native(frame) {
  const child = spawnSync(process.env.REVIEW_PYTHON ?? 'python',
    [...(optimize ? ['-O'] : []), join(root, 'native_bridge.py')], {
      input: JSON.stringify(frame), encoding: 'utf8', timeout: 15000,
      env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1', TMPDIR: root, TMP: root, TEMP: root },
    });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stdout + child.stderr);
  return JSON.parse(child.stdout);
}
const fixture = overrides => native({ op: 'fixture', ...overrides });
const apply = request => native({ op: 'bridge', variant, request_json: JSON.stringify(request) });
async function verifyBrowser(events) {
  const consumer = new AuditLog(); consumer.events = events;
  return consumer.verify();
}
async function validInBoth(result) {
  assert.equal(native({ op: 'verify', audit_json: result.audit_json }).valid, true, 'Python carrier failed');
  assert.equal(await verifyBrowser(result.events), true, 'native Python chain failed browser verification');
}

test('approval-only, ack-only, both and zero integral timestamps share one browser/native chain', async () => {
  for (const [approved_at, acknowledged_at] of [[1, 1.5], [0.5, 1], [1, 2], [0, 0]]) {
    const result = apply(fixture({ approved_at, acknowledged_at }));
    assert.equal(result.error, undefined);
    assert.equal(result.state.version, 14);
    assert.equal(result.valid, true);
    assert.deepEqual(result.events.map(e => e.kind), ['screen_pass', 'approval', 'ack', 'simulated_actuation']);
    await validInBoth(result);
  }
});

test('boolean, numeric-string, null, list and object timestamps retain native refusal', async () => {
  for (const value of [true, '1', null, [], { n: 1 }]) {
    for (const field of ['approved_at', 'acknowledged_at']) {
      const request = fixture({ approved_at: 0.5, acknowledged_at: 1.5 });
      request[field === 'approved_at' ? 'approval' : 'ack'][field] = value;
      const result = apply(request);
      assert.equal(result.error, field === 'approved_at' ? 'invalid_approval_time' : 'invalid_ack_time');
      assert.equal(Object.hasOwn(result, 'state'), false);
      assert.equal(result.events.at(-1).kind, 'reject');
      assert.equal(result.events.some(event => event.kind === 'simulated_actuation'), false);
      await validInBoth(result);
    }
  }
});

test('integer approval keeps a verifiable refusal chain for missing, early and late readback', async () => {
  for (const [kind, expected] of [['missing', 'ack_missing'], ['early', 'invalid_ack_time'], ['late', 'ack_late']]) {
    const request = fixture({ approved_at: 1, acknowledged_at: 2 });
    if (kind === 'missing') request.ack = null;
    if (kind === 'early') request.ack.acknowledged_at = 0.5;
    if (kind === 'late') request.ack.acknowledged_at = 3;
    const result = apply(request);
    assert.equal(result.error, expected);
    assert.equal(Object.hasOwn(result, 'state'), false);
    assert.deepEqual(result.events.map(event => event.kind), ['screen_pass', 'approval', 'reject']);
    await validInBoth(result);
  }
});

test('two successful applications continue the exact prior native audit carrier', async () => {
  const first = apply(fixture({ approved_at: 1, acknowledged_at: 2 }));
  await validInBoth(first);
  const second = apply(fixture({ state: first.state, approved_at: 3, acknowledged_at: 4,
    audit_json: first.audit_json }));
  assert.equal(second.state.version, 15);
  assert.equal(second.events.length, 8);
  assert.deepEqual(second.events.slice(0, 4), first.events);
  assert.equal(second.events[4].prev_hash, first.events[3].event_hash);
  assert.deepEqual(second.events.map(e => e.seq), [0, 1, 2, 3, 4, 5, 6, 7]);
  await validInBoth(second);
});

test('accepted fractional timestamps and Unicode signed payloads retain exact transport', async () => {
  const result = apply(fixture({ approved_at: 0.25, acknowledged_at: 1.75 }));
  assert.equal(result.error, undefined);
  assert.equal(result.events[1].payload.approver, 'review-controller / 𝛂');
  assert.equal(result.events[1].payload.approved_at, 0.25);
  assert.equal(result.events[2].payload.acknowledged_at, 1.75);
  await validInBoth(result);
  assert.equal(await verifyBrowser(JSON.parse(JSON.stringify(result.events))), true);
});

test('payload, sequence, link, claimed-hash and order tampering remain detectable in both consumers', async () => {
  const result = apply(fixture({ approved_at: 0.25, acknowledged_at: 1.75 }));
  await validInBoth(result);
  for (const mutation of ['payload', 'sequence', 'link', 'hash', 'order']) {
    const events = structuredClone(result.events);
    if (mutation === 'payload') events[1].payload.approved_at += 0.25;
    if (mutation === 'sequence') events[1].seq = 99;
    if (mutation === 'link') events[1].prev_hash = 'f'.repeat(64);
    if (mutation === 'hash') events[1].event_hash = 'f'.repeat(64);
    if (mutation === 'order') [events[1], events[2]] = [events[2], events[1]];
    assert.equal(await verifyBrowser(events), false, mutation);
    assert.equal(native({ op: 'verify', audit_json: result.audit_json, mutation }).valid, false, mutation);
  }
});

test('refusal after a successful integer apply extends the existing chain without a second actuation', async () => {
  const first = apply(fixture({ approved_at: 1, acknowledged_at: 2 }));
  const next = fixture({ state: first.state, approved_at: 3, acknowledged_at: 4,
    audit_json: first.audit_json });
  next.ack = null;
  const refused = apply(next);
  assert.equal(refused.error, 'ack_missing');
  assert.equal(Object.hasOwn(refused, 'state'), false);
  assert.equal(refused.events.length, 7);
  assert.deepEqual(refused.events.slice(0, 4), first.events);
  assert.equal(refused.events.filter(event => event.kind === 'simulated_actuation').length, 1);
  await validInBoth(refused);
});

console.log(JSON.stringify({ review_variant: variant, optimized_python: optimize,
  node: process.version, typescript: ts.version, source_commit: pins.commit,
  candidate_sha256: pins.candidate.sha256, consumer: 'actual core.ts + audit.ts, in-memory TypeScript compilation' }));
