"""Invoke the frozen native producer and the exact embedded worker Python."""
from dataclasses import asdict
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline"))
from towerops import Aircraft, WorldState, SafetyPolicy, Advisory, AuditLog

frame = json.load(sys.stdin)
if frame["op"] == "fixture":
    raw = frame.get("state")
    if raw is None:
        state = WorldState(13, 0.0, (Aircraft("review-α", -4.5, 7.25, 11000.0, 0.0, 0.0),))
    else:
        state = WorldState(raw["version"], float(raw["observed_at"]), tuple(
            Aircraft(**{key: value if key == "aircraft_id" else float(value)
                        for key, value in item.items()}) for item in raw["aircraft"]))
    advisory = Advisory("review-α", state.world_hash, 1.0, 0.0, 0.0,
                        state.observed_at, state.observed_at + 4.0,
                        "Independent local synthetic bridge review")
    value = {
        "op": "apply", "state": state.to_dict(), "policy": asdict(SafetyPolicy()),
        "advisory": dict(asdict(advisory), advisory_hash=advisory.advisory_hash),
        "approval": {"advisory_hash": advisory.advisory_hash, "decision": "approve",
                     "approved_at": frame.get("approved_at", 1),
                     "approver": "review-controller / 𝛂"},
        "ack": {"advisory_hash": advisory.advisory_hash, "status": "accepted",
                "acknowledged_at": frame.get("acknowledged_at", 2)},
        "now": state.observed_at + 2.0,
        "audit_json": frame.get("audit_json", "[]"),
    }
    print(json.dumps(value))
elif frame["op"] == "bridge":
    source = (ROOT / frame["variant"] / "web/airspace/src/python-worker.ts").read_text()
    embedded = source.split("await py.runPythonAsync(`", 1)[1].split("`);", 1)[0]
    env = {}
    exec(compile(embedded, frame["variant"] + ":embedded-browser-request", "exec"), env)
    print(env["browser_request"](frame["request_json"]))
elif frame["op"] == "verify":
    # Preserve the native JSON string carrier. Re-serializing browser numbers
    # would erase .0 again and would be a different transport contract.
    events = json.loads(frame["audit_json"])
    mutation = frame.get("mutation")
    if mutation == "payload":
        events[1]["payload"]["approved_at"] += 0.25
    elif mutation == "sequence":
        events[1]["seq"] = 99
    elif mutation == "link":
        events[1]["prev_hash"] = "f" * 64
    elif mutation == "hash":
        events[1]["event_hash"] = "f" * 64
    elif mutation == "order":
        events[1], events[2] = events[2], events[1]
    print(json.dumps({"valid": AuditLog.verify(events)}))
else:
    raise ValueError("Unknown private review operation")
