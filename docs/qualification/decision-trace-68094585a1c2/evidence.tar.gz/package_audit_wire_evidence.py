from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import shutil
import tarfile

ROOT = Path('/Users/me/hamon-towerops-decision-trace-68094585a1c2')
OUT = ROOT / 'audit-wire-final-evidence'
OUT.mkdir(exist_ok=True)


def fingerprint(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


prior = ROOT/'decision-trace-evidence.tar.gz'
assert fingerprint(prior.read_bytes())['sha256'] == 'f0028c0777260109b3160f39b46efecddc667f4e2f4529d443470b04ad808110'
shutil.copyfile(prior,OUT/'previous-decision-trace-evidence.tar.gz')
old = ROOT/'final-contribution'
for name in ['contribution-manifest.json','candidate-source-manifest.json','contribution-summary.json','contribution/docs/qualification/decision-trace-68094585a1c2/README.md','contribution/docs/qualification/decision-trace-68094585a1c2/receipt.json']:
    target=OUT/'previous-publication'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(old/name,target)
for path in sorted((ROOT/'audit-wire-evidence').rglob('*')):
    if not path.is_file() or path.name=='base-source.tar':
        continue
    assert not path.is_symlink()
    target=OUT/'current-receiving'/path.relative_to(ROOT/'audit-wire-evidence')
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,target)
for name in ['audit-wire-candidate-source-manifest.json','qualify_audit_wire.py','package_audit_wire_evidence.py']:
    shutil.copyfile(ROOT/name,OUT/name)
peer=ROOT/'audit-wire-independent-preservation.json'
if peer.exists():
    shutil.copyfile(peer,OUT/peer.name)
members=[]
for file in sorted(OUT.rglob('*')):
    if file.is_file() and file.name!='packet-members.json':
        members.append({'path':file.relative_to(OUT).as_posix(),**fingerprint(file.read_bytes())})
(OUT/'packet-members.json').write_text(json.dumps({'files':members,'total_bytes':sum(x['bytes'] for x in members)},indent=2)+'\n')
tb=io.BytesIO()
with tarfile.open(fileobj=tb,mode='w',format=tarfile.PAX_FORMAT) as tf:
    for file in sorted(OUT.rglob('*')):
        if not file.is_file():continue
        data=file.read_bytes();ti=tarfile.TarInfo(file.relative_to(OUT).as_posix());ti.size=len(data);ti.mode=0o644;ti.mtime=0;tf.addfile(ti,io.BytesIO(data))
data=gzip.compress(tb.getvalue(),compresslevel=9,mtime=0)
(ROOT/'audit-wire-evidence.tar.gz').write_bytes(data)
(ROOT/'audit-wire-evidence.tar.gz.b64').write_text(base64.b64encode(data).decode()+'\n')
summary={'archive':{'name':'audit-wire-evidence.tar.gz',**fingerprint(data)},'members':len(members)+1,'independent_preservation_included':peer.exists()}
(ROOT/'audit-wire-evidence-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
