from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import time
from datetime import datetime, timezone

ROOT = Path('/Users/me/hamon-towerops-decision-trace-68094585a1c2')
SOURCE = ROOT / 'receiving-audit-wire-source'
EVIDENCE = ROOT / 'audit-wire-evidence'
overlay = json.loads((ROOT / 'audit-wire-source-overlay.json').read_text())
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', TMPDIR=str(ROOT / 'tmp'),
           PYTHONDONTWRITEBYTECODE='1', RUNNER_TEMP=str(EVIDENCE),
           PATH=str(ROOT / 'ci-browser-venv/bin') + ':/opt/homebrew/bin:' + os.environ['PATH'])


def fingerprint(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')


entries = subprocess.check_output(['/usr/bin/git', '-C', str(ROOT/'source'), 'ls-tree', '-r', '-z', '-l', overlay['base_commit']], env=env).split(b'\0')
base = []
for raw in entries:
    if not raw:
        continue
    header, path = raw.split(b'\t', 1)
    mode, kind, sha, size = header.decode().split()
    assert kind == 'blob'
    rel = path.decode()
    file = SOURCE / rel
    found = fingerprint(file.read_bytes())
    assert not file.is_symlink() and found['git_blob'] == sha and found['bytes'] == int(size), rel
    assert ('100755' if file.stat().st_mode & stat.S_IXUSR else '100644') == mode
    base.append({'path': rel, 'mode': mode, **found})
base_map = {item['path']: item for item in base}
guidance = [item['path'] for item in base if Path(item['path']).name in ('AGENTS.md', 'CONTINUE.md')]
assert guidance == []
save('base-inputs.json', {'base_commit': overlay['base_commit'], 'base_tree': overlay['base_tree'], 'files': base, 'applicable_AGENTS_or_CONTINUE': guidance})

for item in overlay['files']:
    assert base_map.get(item['path'], {}).get('git_blob') == item['before_git_blob'], item['path']
    file = SOURCE / item['path']
    file.parent.mkdir(parents=True, exist_ok=True)
    content = item['content'].encode()
    assert all(fingerprint(content)[key] == item[key] for key in ('bytes', 'sha256', 'git_blob'))
    file.write_bytes(content)
    file.chmod(int(item['mode'][-3:], 8))
for item in overlay['current_parent_inputs']:
    if item['path'].endswith('python-worker.ts'):
        continue
    assert fingerprint((SOURCE/item['path']).read_bytes())['git_blob'] == item['git_blob']
expected = dict(base_map)
expected.update({item['path']: {key:item[key] for key in ('path','mode','bytes','sha256','git_blob')} for item in overlay['files']})


def verify_source():
    for rel, item in expected.items():
        file = SOURCE / rel
        assert not file.is_symlink() and all(fingerprint(file.read_bytes())[key] == item[key] for key in ('bytes','sha256','git_blob')), rel
        assert ('100755' if file.stat().st_mode & stat.S_IXUSR else '100644') == item['mode']


verify_source()
save('source-freeze-before.json', {'base_commit': overlay['base_commit'], 'base_tree': overlay['base_tree'], 'files': list(expected.values())})
save('source-overlay.json', overlay)
(EVIDENCE/'worker-current-parent.diff').write_text(overlay['worker_current_parent_diff'])
(EVIDENCE/'helper-previous-candidate.diff').write_text(overlay['helper_previous_candidate_diff'])
old_source = ROOT/'receiving-source'
unchanged = []
for rel in ['towerops.py','audit_replay.py','decision_trace.py','tests/test_decision_trace.py','web/airspace/package.json','web/airspace/package-lock.json']:
    assert (SOURCE/rel).read_bytes() == (old_source/rel).read_bytes(),rel
    unchanged.append({'path':rel,**fingerprint((SOURCE/rel).read_bytes())})
save('unchanged-native-and-dependencies.json', {'files':unchanged,'native_108_suite_repeated':False,'reason':'Native producer, replay, adapter and native controls are unchanged. Qualification targets changed Worker/client/browser consumer inputs.'})

workflow = (SOURCE/'.github/workflows/airspace-demo.yml').read_text()
step = workflow.split('      - name: Verify saved decision traces\n        run: |\n',1)[1].split('      - run:',1)[0]
ci_command = '\n'.join(line[10:] for line in step.rstrip().splitlines()) + '\n'
native_command = ci_command.rstrip() + " --chrome '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'\n"
(EVIDENCE/'ci-command.sh').write_text(ci_command)
(EVIDENCE/'native-command.sh').write_text(native_command)
gates = []
for name, command, cwd in [
    ('frontend-tests',['/opt/homebrew/bin/npm','test','--','--no-cache','--configLoader','runner'],SOURCE/'web/airspace'),
    ('build',['/opt/homebrew/bin/npm','run','build'],SOURCE/'web/airspace'),
    ('maintained-browser',['/bin/bash','-e','-o','pipefail','-c',native_command],SOURCE),
]:
    start = time.monotonic()
    with (EVIDENCE/(name+'.log')).open('w') as log:
        result = subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    item = {'name':name,'command':command,'cwd':str(cwd),'returncode':result.returncode,'elapsed_seconds':round(time.monotonic()-start,3)}
    gates.append(item)
    save('gates.json',gates)
    print(json.dumps(item),flush=True)
    if result.returncode:
        verify_source()
        raise SystemExit(result.returncode)
verify_source()
browser = json.loads((EVIDENCE/'towerops-decision-trace-browser/browser-receipt.json').read_text())
assert browser['passed'] and len(browser['controls']) == 11 and all(item['passed'] for item in browser['controls'])
assert browser['controls'][0]['detail']['visible_chain_verdict'] == 'HASH CHAIN VALID - 4 EVENTS'
assert browser['controls'][9]['detail']['visible_chain_verdict'] == 'HASH CHAIN VALID - 4 EVENTS'
save('source-freeze-after.json', {'base_commit':overlay['base_commit'],'base_tree':overlay['base_tree'],'files':list(expected.values()),'verified_at_utc':datetime.now(timezone.utc).isoformat(),'unchanged_during_gates':True})
save('receiving-summary.json', {'base_commit':overlay['base_commit'],'base_tree':overlay['base_tree'],'source_leaves':len(expected),'base_leaves':len(base),'gates':gates,'browser_passed':11,'visible_native_chain_verified_before_review_and_after_later_apply':True,'native_browser_override':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','ci_command':ci_command,'native_108_suite_repeated':False})
print(json.dumps({'completed':True,'base_leaves':len(base),'source_leaves':len(expected),'browser_controls':11,'source_pins_unchanged':True}),flush=True)
