TOWEROPS_PLAYWRIGHT_JS="$(python -c 'from pathlib import Path; import playwright; print(Path(playwright.__file__).parent / "driver" / "package" / "index.mjs")')"
node tools/verify_decision_trace.mjs --playwright "$TOWEROPS_PLAYWRIGHT_JS" --output "$RUNNER_TEMP/towerops-decision-trace-browser"
