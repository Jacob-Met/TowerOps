# Review, save and reopen the native decision trail

Airspace Lab can now review a recorded decision sequence, download its original
native JSON, and reopen it in a later session. The view separates broken hashes
from a hash-valid history with decision-sequence issues. It displays each
advisory's screening, approval, readback, actuations and world links, followed by
recorded rejections. Opening a trace never installs its aircraft or audit into
the live simulation.

## Native source and integration

The feature uses the existing `audit_replay.replay_audit` unchanged. A bounded
`decision_trace.review_trace(raw)` adapter projects that result for the existing
Python Worker. The new `review_trace` operation returns before the bridge reads
any plan/apply fields. The page continues to use the existing
`towerPython(request: unknown)` client; it acquires the existing busy guard and
requires paused traffic. The optional replay modules load only when requested,
and a failed replay-source fetch does not disable native planning.

The UI and styles are isolated in `decision-trace.ts` and `decision-trace.css`.
The shared hooks are one initialization and callback in `main.ts`, busy-state
rendering, and controls inside the existing Decision trace panel. No scenario
loader, client lifecycle, planner, gate, numeric serializer, or replay algorithm
is replaced. The two replay modules are added to the existing Python packaging
step and both Airspace workflow path arrays. The existing Airspace capture is
followed by the maintained decision-trace browser acceptance tool. That tool is
also included in both path arrays. Existing jobs, permissions, dependency pins
and commands remain intact.

The original authored and tested source was based on main
`728387a51fba7be34cf8344fe4f5cd9c7b12b6ad`. During qualification, PR #36 merged the
separate numeric-admission work. The final contribution is composed over
`09b96e31d2867af5b7a9738406d0431cf1010090`, tree
`4d22827647c0b2e37d11921aa5273f7a358bcdde`, preserving that work exactly. Its
12 source/integration paths produce source tree
`873a2438fab3fb1acf2a73118d881992928760b2` before these qualification documents
are added: 127 unchanged parent leaves, six replacements, six additions and no
deletions. Neither pinned tree contains an applicable `AGENTS.md` or
`CONTINUE.md`. `receipt.json` records exact before-blobs, modes, hashes and
source-input maps.

## Completed qualification

The current-parent composition ran on native macOS with Python 3.13.7,
CI-pinned pytest 8.3.5 and Ruff 0.16.10, Node 26.3.0, and the unchanged npm lock.
Browser controls used Google Chrome 154.0.8037.98 with the actual built Worker
and locally packaged Pyodide 0.27.7. Worker requests and results were observed;
native execution was not replaced.

| Current-parent check | Observed result |
| --- | --- |
| Complete native suite, including 17 adapter cases | 108 passed |
| Whole-repository Ruff | Passed |
| Existing generated-reference check | Four real-source scenarios unchanged |
| Complete frontend suite, including six delivery cases | 76 passed in seven files |
| Python packaging, TypeScript check and Vite build | Passed |
| Actual Chrome/Pyodide decision-trail controls | 11 passed |
| Maintained CI command through Python Playwright's JavaScript driver | 11 passed with the native Chrome override described below |

The browser controls produce a trace through the real planner, approval and
readback flow; download it byte-for-byte; verify it with the native CLI; and
reopen it while a different world-bound approval remains pending. They preserve
the paused world, policy, pending proposal/approval and live audit. Other cases
exercise rehashed missing-approval, wrong-world and wrong-order histories,
tampered hashes, malformed files, both input bounds, literal hostile labels,
390-pixel mobile layout, native demo documents, later live application, and a
real optional-module fetch failure followed by successful planning and retry.

The original author source passed 78 native and 51 frontend cases plus the same
11 browser controls. The current-parent build changes only the served
`python/towerops.py` file to PR #36's exact producer; JavaScript, CSS, HTML and the
downloaded native trace are byte-identical. Current-parent gates ran on source
tree `b5976d9fbbadb2a6fcc385e0d76b35d65275947b`. An intermediate workflow
path-filter addition produced tree `5ec106974e17d4cb8a3544127efc21a25b96653a`;
its original receipt remains preserved. The final maintained-gate change adds
the acceptance step and helper path, and updates only the helper's introductory
comments. Removing the new step and three filenames restores the original
workflow byte-for-byte. The helper's executable body is unchanged.

The new command was executed once through the JavaScript driver distributed
inside the existing CI dependency, Python Playwright 1.63.0. Its package exports
`chromium` and declares Node 20 or later, matching the existing CI Node 20
installation. The native check used Node 26.3.0 and the installed real Chrome
154 executable because the default Playwright Chromium revision was absent
from that native cache. The maintained workflow omits this `--chrome` override
and follows its existing Chromium installation. This verifies the command and
driver path without claiming a hosted CI run. All 139 final source leaves were
verified afterward; all 15 served build files match the current-parent browser
run. No product dependencies, lockfiles or test frameworks were added.

Independent receiving adds a real four-aircraft history with two different
actuated advisories and a refused repeat. Its controls cover rehashed world and
ordering errors, omitted native fields, unknown event kinds, saved integral
float text, and review requests with deliberately irrelevant plan/apply fields.
Two additional real-browser controls on the frozen author build preserve that
file text through File → Worker → Pyodide, display two advisories and their
rejections, keep hostile labels literal, and retain a different pending live
approval and empty live audit. The original and current-producer execution
identities, unchanged independent cases, fixtures and screenshots are included
in the evidence archive and summarized in `receipt.json`. The six independent
native cases passed both normally and with Python optimization on each producer
pin. The two additional browser cases used the frozen original author build;
the current producer has its separately recorded 11-control browser run.

Initial failed author controls are retained. Four assertions incorrectly
expected a later world-hash refusal when the native time check rejects first;
one depended on a particular JSON-decoder recursion threshold. Those controls
were corrected to the existing native contract. The first lint run also led to
using `TypeError` for wrong argument types. No native safety or replay rule was
changed to satisfy those controls. Earlier low-contrast status colors were
replaced with the existing UI palette before the final frontend/build/browser
run; the earlier source and evidence remain available.

## Reproduce and interpret

Run the repository's normal native and frontend commands. The maintained
`tools/verify_decision_trace.mjs` helper accepts an installed Chrome executable,
an existing Playwright module, and an output directory:

```sh
python -m pytest -q
python -m ruff check .
python tools/generate_airspace_reference.py --check
cd web/airspace
npm ci
npm test
npm run build
cd ../..
node tools/verify_decision_trace.mjs --chrome /path/to/chrome --playwright /path/to/playwright/index.mjs --output /path/to/evidence
```

The Airspace workflow uses its existing Python Playwright installation directly:

```sh
TOWEROPS_PLAYWRIGHT_JS="$(python -c 'from pathlib import Path; import playwright; print(Path(playwright.__file__).parent / "driver" / "package" / "index.mjs")')"
node tools/verify_decision_trace.mjs --playwright "$TOWEROPS_PLAYWRIGHT_JS" --output "$RUNNER_TEMP/towerops-decision-trace-browser"
```

The evidence archive preserves the original author and current-parent archives
unchanged, the independent contributor's exact 22-file packet, the maintained
command and its native override, actual browser receipts and screenshots, and
the final source map. `packet-members.json` provides hashes for those records.

Browser review accepts an event list or a native demo object with `audit_events`,
up to 2 MiB of UTF-8 JSON and 5,000 events. Downloads preserve the full native
text; larger files remain usable with `python audit_replay.py file.json`.
Preserving the text avoids JavaScript's conversion of native integral floats to
integer JSON values before Python verifies their canonical hashes.

This is the existing replay's semantic scope: first screening/approval/readback
records, recorded actuations and available world links. Unknown event kinds and
omitted optional world hashes retain their native behavior. The review does not
rerun separation policy, reconstruct motion, authenticate an approval or certify
operational aviation safety. These receipts establish local source and actual
browser qualification; hosted CI, deployment and any later receiving commit are
separate observations.
