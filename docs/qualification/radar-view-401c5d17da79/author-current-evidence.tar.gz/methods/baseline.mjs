import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createServer } from '../source/web/airspace/node_modules/vite/dist/node/index.js';
import { openBrowser } from './cdp.mjs';
const base='/home/jacob/.commander-tp-1/hamon-work/estate-401c5d17da79/towerops-radar';
const root=base+'/source',web=root+'/web/airspace',out=base+'/evidence/baseline';
await mkdir(out,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
const files=spawnSync('git',['-C',root,'ls-files','-z'],{encoding:'utf8'}).stdout.split('\0').filter(Boolean);
async function hashes(){return Object.fromEntries(await Promise.all(files.map(async p=>[p,hash(await readFile(root+'/'+p))])));}
const before=await hashes(),checks=[];
const head=spawnSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).stdout.trim();
if(head!=='5b3015567a01017245c5f715c1bce65e20a06138')throw Error('Unexpected baseline source');
const prepare=spawnSync('/usr/bin/node',['prepare-python.mjs'],{cwd:web,encoding:'utf8'});
await writeFile(out+'/prepare.json',JSON.stringify({exit:prepare.status,stdout:prepare.stdout,stderr:prepare.stderr},null,2)+'\n');
if(prepare.status!==0)throw Error('Original Python asset preparation failed');
let server,browser;const started=Date.now();let failure=null;
function check(name,condition,details){checks.push({name,passed:!!condition,details});if(!condition)throw Error(name);}
try{
 server=await createServer({root:web,configFile:false,base:'./',cacheDir:base+'/cache/baseline-vite',server:{host:'127.0.0.1',port:0,fs:{allow:[root,'/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules']}}});
 await server.listen();
 const port=server.httpServer.address().port;
 browser=await openBrowser({profile:'/home/jacob/towerops-radar-profiles-401c5d17da79/baseline',evidence:out});
 const cdp=browser.cdp;
 await cdp.send('Page.navigate',{url:'http://127.0.0.1:'+port+'/'});
 await cdp.wait('document.querySelector("#world-json")?.value?.includes("aircraft")');
 const initial=await cdp.evaluate('({range:document.querySelector("#range-label").textContent,world:JSON.parse(document.querySelector("#world-json").value)})');
 check('original full page renders in automatic fit',initial.range.startsWith('AUTO FIT'),initial.range);
 const data=JSON.parse(await readFile(web+'/tests/python-reference.json','utf8'));
 const state={version:17,observed_at:data.scenarios[0].now,aircraft:[
  {aircraft_id:'LOCAL_A',x_nm:0,y_nm:0,altitude_ft:10000,vx_nm_min:0,vy_nm_min:0,climb_ft_min:0},
  {aircraft_id:'LOCAL_B',x_nm:1,y_nm:0,altitude_ft:10000,vx_nm_min:0,vy_nm_min:0,climb_ft_min:0},
  {aircraft_id:'DISTANT',x_nm:10000,y_nm:10000,altitude_ft:20000,vx_nm_min:0,vy_nm_min:0,climb_ft_min:0},
 ]};
 await cdp.click('.state-workbench > summary');
 await cdp.fill('#world-json',JSON.stringify(state,null,2));await cdp.click('#load-world');
 await cdp.wait('document.querySelector("#world-json-feedback").textContent.startsWith("Loaded 3")');
 const observed=await cdp.evaluate(`(()=>{
 const canvas=document.querySelector('#airspace'),texts=canvas.getContext('2d').__radarText??[];
 const a=texts.find(x=>x[0]==='LOCAL_A'),b=texts.find(x=>x[0]==='LOCAL_B');
 return {range:document.querySelector('#range-label').textContent,world:JSON.parse(document.querySelector('#world-json').value),
  glyph_separation_px:a&&b?Math.abs(a[1]-b[1]):null,
  camera_controls:[...document.querySelectorAll('button')].filter(x=>/zoom|pan north|pan south|pan east|pan west|fit traffic|focus selected/i.test(x.textContent)).map(x=>x.textContent),
  canvas:{width:canvas.getBoundingClientRect().width,height:canvas.getBoundingClientRect().height}};
 })()`);
 check('real WorldState input preserves all three authored tracks',JSON.stringify(observed.world)===JSON.stringify(state),observed.world);
 check('full-set automatic fit compresses the one-NM local pair below one pixel',typeof observed.glyph_separation_px==='number'&&observed.glyph_separation_px<1,observed);
 check('current page has no manual radar navigation controls',observed.camera_controls.length===0,observed.camera_controls);
 await cdp.evaluate('document.querySelector(".radar-panel").scrollIntoView({block:"center"})');
 await new Promise(r=>setTimeout(r,150));
 await cdp.screenshot(out+'/broad-traffic-baseline.png');
 check('native page has no script exceptions',browser.errors.length===0,browser.errors);
}catch(error){failure=String(error.stack??error);}
finally{
 if(browser)await browser.close();if(server)await server.close();
 const after=await hashes();
 check('all 458 tracked baseline files remain unchanged',JSON.stringify(before)===JSON.stringify(after),{files:files.length});
 const receipt={source_head:head,source_tree:'89a7769301291fb66605eb0a4e45cc9ce285861a',purpose:'Frozen missing-navigation baseline; automatic fitting itself is the preserved current behavior, not an implementation defect.',checks,passed:checks.filter(c=>c.passed).length,failed:checks.filter(c=>!c.passed).length,failure,seconds:(Date.now()-started)/1000,node:process.version,browser:browser?.version,blocked_external_requests:browser?.blocked,method_sha256:hash(await readFile(new URL(import.meta.url))),helper_sha256:hash(await readFile(new URL('./cdp.mjs',import.meta.url))),source_hashes:before};
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({passed:receipt.passed,failed:receipt.failed,failure,receipt:out+'/receipt.json',sha256:hash(await readFile(out+'/receipt.json')),seconds:receipt.seconds}));
 if(failure||receipt.failed)process.exitCode=1;
}
