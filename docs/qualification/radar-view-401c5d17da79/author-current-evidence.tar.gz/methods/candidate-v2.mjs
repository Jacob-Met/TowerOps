import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createServer } from '../source/web/airspace/node_modules/vite/dist/node/index.js';
import { openBrowser } from './cdp.mjs';
const base='/home/jacob/.commander-tp-1/hamon-work/estate-401c5d17da79/towerops-radar';
const root=base+'/source',web=root+'/web/airspace',out=base+'/evidence/browser-v2';
await mkdir(out);
const hash=b=>createHash('sha256').update(b).digest('hex');
const files=[...new Set([...spawnSync('git',['-C',root,'ls-files','-z'],{encoding:'utf8'}).stdout.split('\0').filter(Boolean),
  'web/airspace/src/radar-view.ts','web/airspace/tests/radar-view.test.ts'])].sort();
async function hashes(){return Object.fromEntries(await Promise.all(files.map(async p=>[p,hash(await readFile(root+'/'+p))])));}
const before=await hashes(),checks=[],observations={};
const head=spawnSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).stdout.trim();
const started=Date.now();let server,browser,cdp,failure=null;
const check=(name,condition,details)=>{checks.push({name,passed:!!condition,details});if(!condition)throw Error(name);};
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const evaluate=fn=>cdp.evaluate('('+fn.toString()+')()');
async function stateView(){
 return evaluate(()=>{
  const canvas=document.querySelector('#airspace'),ctx=canvas.getContext('2d'),r=canvas.getBoundingClientRect();
  return {range:document.querySelector('#range-label').textContent,center:document.querySelector('#radar-center-label').textContent,
   summary:document.querySelector('#radar-view-summary').textContent,auto:document.querySelector('#radar-fit').getAttribute('aria-pressed'),
   text:ctx.__radarText??[],strokes:ctx.__radarStrokes??[],canvas:{width:r.width,height:r.height},
   pair_count:document.querySelector('#pair-count').textContent,
   clock:document.querySelector('#sim-clock').textContent,run:document.querySelector('#toggle-run').textContent};
 });
}
async function operationSnapshot(){
 return evaluate(()=>({
  world:document.querySelector('#world-json').value,
  selected:document.querySelector('.flight-row.selected button')?.textContent,
  clock:document.querySelector('#sim-clock').textContent,
  proposal:document.querySelector('#proposal-output').textContent,
  gates:['gate-screen','gate-approval','gate-ack'].map(id=>document.getElementById(id).outerHTML),
  audit:document.querySelector('#audit-status').textContent,
  events:document.querySelector('#audit-events').innerHTML,
  fields:[...document.querySelectorAll('.flight-builder input')].map(e=>[e.id,e.value,e.readOnly]),
 }));
}
async function pngHash(){
 const url=await cdp.evaluate('document.querySelector("#airspace").toDataURL("image/png")');
 return hash(Buffer.from(url.split(',')[1],'base64'));
}
async function marginHash(){
 const data=await evaluate(()=>{
  const c=document.querySelector('#airspace'),ctx=c.getContext('2d'),p=ctx.getImageData(0,0,c.width,c.height).data,result=[];
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)
   if(x<64||x>=c.width-28||y<24||y>=c.height-40){
    const i=(y*c.width+x)*4;result.push(p[i],p[i+1],p[i+2],p[i+3]);
   }
  return result;
 });
 return hash(Buffer.from(data));
}
async function loadWorld(state){
 const opened=await cdp.evaluate('document.querySelector(".state-workbench").open');
 if(!opened)await cdp.click('.state-workbench > summary');
 await cdp.fill('#world-json',JSON.stringify(state,null,2));await cdp.click('#load-world');
 await cdp.wait('document.querySelector("#world-json-feedback").textContent.startsWith("Loaded '+state.aircraft.length+'")');
}
function glyph(view,id){return view.text.find(x=>x[0]===id);}
const near=(a,b)=>Math.abs(a-b)<1e-7;
async function tap(selector){
 const p=await cdp.evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');e.scrollIntoView({block:"center"});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()');
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p,radiusX:1,radiusY:1,force:1}]});
 await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 await pause(100);
}
try{
 server=await createServer({root:web,configFile:false,base:'./',cacheDir:base+'/cache/browser-v2-vite',
  server:{host:'127.0.0.1',port:0,fs:{allow:[root,'/home/jacob/towerops-current-main-31366547c1f5/repository/web/airspace/node_modules']}}});
 await server.listen();const port=server.httpServer.address().port;
 browser=await openBrowser({profile:'/home/jacob/towerops-radar-profiles-401c5d17da79/browser-v2',evidence:out,width:1280,height:1100});
 cdp=browser.cdp;
 await cdp.send('Page.addScriptToEvaluateOnNewDocument',{source:'('+(()=>{
  const p=CanvasRenderingContext2D.prototype,fill=p.fillRect,begin=p.beginPath,move=p.moveTo,line=p.lineTo,stroke=p.stroke;
  p.fillRect=function(...a){if(a[0]===0&&a[1]===0)this.__radarStrokes=[];return Reflect.apply(fill,this,a);};
  p.beginPath=function(...a){this.__radarPath=[];return Reflect.apply(begin,this,a);};
  p.moveTo=function(...a){(this.__radarPath??=[]).push(['M',...a]);return Reflect.apply(move,this,a);};
  p.lineTo=function(...a){(this.__radarPath??=[]).push(['L',...a]);return Reflect.apply(line,this,a);};
  p.stroke=function(...a){(this.__radarStrokes??=[]).push({path:[...this.__radarPath??[]],style:this.strokeStyle,dash:this.getLineDash()});return Reflect.apply(stroke,this,a);};
 }).toString()+')();'});
 await cdp.send('Page.navigate',{url:'http://127.0.0.1:'+port+'/'});
 await cdp.wait('document.querySelector("#world-json")?.value?.includes("aircraft")');
 const initial=await stateView();
 check('native page starts in automatic mode with keyboard-addressable controls',
  initial.auto==='true'&&initial.range.startsWith('AUTO FIT')&&await cdp.evaluate('document.querySelector("#airspace").tabIndex===0'),initial.range);
 const data=JSON.parse(await readFile(web+'/tests/python-reference.json','utf8'));
 const makePlane=(id,x,y,alt=10000,vx=0,vy=0)=>({aircraft_id:id,x_nm:x,y_nm:y,altitude_ft:alt,vx_nm_min:vx,vy_nm_min:vy,climb_ft_min:0});
 const broad={version:17,observed_at:data.scenarios[0].now,aircraft:[makePlane('LOCAL_A',0,0),makePlane('LOCAL_B',1,0),makePlane('DISTANT',10000,10000,20000)]};
 await loadWorld(broad);
 const automatic=await stateView(),original=await operationSnapshot(),automaticPng=await pngHash();
 check('automatic view retains the frozen broad-world compression',
  near(Math.abs(glyph(automatic,'LOCAL_A')[1]-glyph(automatic,'LOCAL_B')[1]),(automatic.canvas.height-64)/11000),
  {range:automatic.range,separation:Math.abs(glyph(automatic,'LOCAL_A')[1]-glyph(automatic,'LOCAL_B')[1])});
 await cdp.click('#radar-focus');
 const focused=await stateView();
 check('Focus selects a manual local view without changing the selected flight',
  focused.range==='MANUAL +/- 15 NM'&&focused.center==='CENTER EAST 0 / NORTH 0 NM'&&focused.auto==='false',focused.summary);
 await cdp.click('#radar-zoom-in');await cdp.click('#radar-zoom-in');
 const zoomed=await stateView(),zoomPng=await pngHash();
 const gap=glyph(zoomed,'LOCAL_B')[1]-glyph(zoomed,'LOCAL_A')[1];
 check('actual local glyphs separate at a useful common scale after zoom',
  gap>50&&zoomed.range==='MANUAL +/- 3.75 NM',{gap,canvas:zoomed.canvas});
 check('manual feedback names the real offscreen count while global conflict remains',
  zoomed.summary==='2 of 3 aircraft positions in view. 1 outside; 1 projection ends outside.'&&zoomed.pair_count==='1',zoomed.summary);
 await cdp.click('#radar-pan-east');const east=await stateView();
 await cdp.click('#radar-pan-north');const north=await stateView();
 check('native pan moves the image opposite the east/north center change',
  near(glyph(east,'LOCAL_A')[1]-glyph(zoomed,'LOCAL_A')[1],-(zoomed.canvas.height-64)/4)&&
  near(glyph(north,'LOCAL_A')[2]-glyph(east,'LOCAL_A')[2],(zoomed.canvas.height-64)/4),
  {east:east.center,north:north.center});
 await cdp.click('#radar-pan-west');await cdp.click('#radar-pan-south');
 await cdp.click('#radar-zoom-out');await cdp.click('#radar-zoom-in');
 check('inverse pan and zoom return the complete native canvas raster',await pngHash()===zoomPng,{sha256:zoomPng});
 check('camera actions preserve the paused operational snapshot exactly',
  JSON.stringify(await operationSnapshot())===JSON.stringify(original),{snapshot_sha256:hash(JSON.stringify(original))});
 const beforeMargin=await marginHash();
 const edgeX=(zoomed.canvas.width-92)/(zoomed.canvas.height-64)*3.75+.2;
 const edgeWorld={...broad,aircraft:[...broad.aircraft,makePlane('OUTSIDE',edgeX,0,30000)]};
 await loadWorld(edgeWorld);const edge=await stateView();
 check('a nearby offscreen aircraft cannot paint its glyph or label into the canvas margin',
  await marginHash()===beforeMargin&&!glyph(edge,'OUTSIDE'),{margin_sha256:beforeMargin,summary:edge.summary});
 const crossingWorld={...broad,aircraft:[...edgeWorld.aircraft,makePlane('CROSSING',-100,1,40000,40,0)]};
 await loadWorld(crossingWorld);const crossing=await stateView();
 const crossingY=24+(crossing.canvas.height-64)/2-(crossing.canvas.height-64)/7.5;
 const visiblePath=crossing.strokes.find(s=>s.dash.join(',')==='5,5'&&s.path.length===2&&
  s.path[0][0]==='M'&&near(s.path[0][1],64)&&near(s.path[0][2],crossingY)&&
  s.path[1][0]==='L'&&near(s.path[1][1],crossing.canvas.width-28)&&near(s.path[1][2],crossingY));
 check('a real dashed projection crossing the view survives two offscreen endpoints',
  !!visiblePath&&!glyph(crossing,'CROSSING')&&await marginHash()===beforeMargin,{path:visiblePath,summary:crossing.summary});
 await cdp.evaluate('document.querySelector(".radar-panel").scrollIntoView({block:"center"})');await pause(120);
 await cdp.screenshot(out+'/desktop-manual-view.png');
 await cdp.click('#radar-fit');const fitted=await stateView();
 check('Auto fit restores all current and projected tracks',fitted.auto==='true'&&
  fitted.summary==='5 of 5 aircraft positions in view. 0 outside; 0 projection ends outside.',fitted.summary);
 await loadWorld(broad);
 check('the original automatic broad-world raster is unchanged by the round trip',
  await pngHash()===automaticPng,{sha256:automaticPng});
 const moving={...broad,version:18,aircraft:broad.aircraft.map((a,i)=>i===0?{...a,vx_nm_min:1}:a)};
 await loadWorld(moving);await cdp.click('#radar-focus');
 await cdp.click('#toggle-run');
 await cdp.wait('document.querySelector("#sim-clock").textContent!=="T+0 SEC"');
 await cdp.click('#radar-pan-north');
 const running=await stateView();
 await pause(350);
 const advanced=await stateView();
 check('manual camera controls leave native traffic running and its clock advancing',
  running.run==='Pause traffic'&&advanced.run==='Pause traffic'&&advanced.clock!==running.clock,
  {before:running.clock,after:advanced.clock});
 check('manual center stays fixed while the selected aircraft moves',
  running.center===advanced.center&&!near(glyph(running,'LOCAL_A')[1],glyph(advanced,'LOCAL_A')[1]),
  {center:running.center,before:glyph(running,'LOCAL_A')[1],after:glyph(advanced,'LOCAL_A')[1]});
 await cdp.click('#toggle-run');await loadWorld(broad);
 for(const width of [390,320]){
  await cdp.send('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:true});
  await cdp.send('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1});
  await pause(120);await tap('#radar-fit');await tap('#radar-focus');
  for(let i=0;i<3;i++)await tap('#radar-zoom-in');
  await tap('#radar-pan-east');
  const phone=await stateView();
  const bounds=await evaluate(()=>{
   const panel=document.querySelector('.radar-panel').getBoundingClientRect();
   const buttons=[...document.querySelectorAll('.radar-navigation button')].map(b=>{
    const r=b.getBoundingClientRect();return {id:b.id,x:r.x,y:r.y,width:r.width,height:r.height};});
   return {scrollWidth:document.documentElement.scrollWidth,width:innerWidth,panel:{left:panel.left,right:panel.right},buttons};
  });
  check('all eight native radar controls fit and retain touch height at '+width+'px',
   bounds.scrollWidth<=bounds.width&&bounds.buttons.length===8&&bounds.buttons.every(b=>
    b.width>24&&b.height>=44&&b.x>=bounds.panel.left&&b.x+b.width<=bounds.panel.right+.1),bounds);
  check('actual touch controls reach and announce the manual phone view at '+width+'px',
   phone.range==='MANUAL +/- 1.875 NM'&&phone.auto==='false'&&phone.summary.includes('2 of 3 aircraft positions'),phone);
  await cdp.evaluate('document.querySelector(".radar-panel").scrollIntoView({block:"center"})');await pause(120);
  await cdp.screenshot(out+'/phone-'+width+'-manual-view.png');
 }
 const overflow={version:20,observed_at:broad.observed_at,aircraft:[makePlane('OVERFLOW',0,0,10000,Number.MAX_VALUE)]};
 await loadWorld(overflow);
 const unavailable=await stateView();
 check('unrepresentable projected traffic stays explicitly unavailable in a manual view',
  unavailable.range==='RADAR VIEW UNAVAILABLE'&&unavailable.text.some(t=>t[0]==='RADAR VIEW UNAVAILABLE')&&
  await cdp.evaluate('document.querySelector("#radar-pan-east").disabled&&!document.querySelector("#radar-fit").disabled'),unavailable.range);
 await tap('#radar-fit');await loadWorld(broad);
 const recovered=await stateView();
 check('valid traffic can recover automatic fitting after the unavailable view',
  recovered.auto==='true'&&recovered.range==='AUTO FIT +/- 5500 NM'&&!await cdp.evaluate('document.querySelector("#radar-focus").disabled'),recovered.range);
 observations.broad=automatic;observations.manual=zoomed;observations.crossing=crossing;observations.automatic_recovered=recovered;
 check('native execution has no page script exceptions',browser.errors.length===0,browser.errors);
}catch(error){failure=String(error.stack??error);if(cdp)try{await cdp.screenshot(out+'/failure.png');}catch{}}
finally{
 if(browser)await browser.close();if(server)await server.close();
 const after=await hashes();
 const unchanged=JSON.stringify(before)===JSON.stringify(after);
 checks.push({name:'all qualified candidate source bytes remain unchanged',passed:unchanged,details:{files:files.length}});
 const receipt={source_parent:head,source_status:'working-tree candidate, exact source hashes below; commit metadata follows unchanged-byte freeze',
  checks,passed:checks.filter(c=>c.passed).length,failed:checks.filter(c=>!c.passed).length,failure,
  seconds:(Date.now()-started)/1000,node:process.version,browser:browser?.version,
  blocked_external_requests:browser?.blocked,method_sha256:hash(await readFile(new URL(import.meta.url))),
  helper_sha256:hash(await readFile(new URL('./cdp.mjs',import.meta.url))),source_hashes:before,observations};
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({passed:receipt.passed,failed:receipt.failed,failure,receipt:out+'/receipt.json',sha256:hash(await readFile(out+'/receipt.json')),seconds:receipt.seconds}));
 if(failure||receipt.failed)process.exitCode=1;
}
