import {readFile,writeFile,mkdir,stat,statfs} from 'node:fs/promises';
import {createServer} from 'node:http';
import {join,extname,resolve,sep} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {openBrowser} from './cdp.mjs';
const base='/home/jacob/.commander-tp-1/hamon-work/estate-401c5d17da79/towerops-radar';
const root=base+'/current-source',dist=root+'/web/airspace/dist',out=base+'/evidence/current-composition/scenario-camera-v1';
const hash=b=>createHash('sha256').update(b).digest('hex');
const git=(...args)=>{const r=spawnSync('git',['-C',root,...args],{encoding:'utf8'});if(r.status)throw Error(r.stderr);return r.stdout.trim();};
if(git('rev-parse','HEAD')!=='c06ade187171300112c29f2b9f4944d1e4b93240'||git('status','--porcelain'))throw Error('source pin drift');
const free=await statfs(base);if(free.bavail*free.bsize<100*1024*1024)throw Error('insufficient native capacity');
await mkdir(out);await mkdir(out+'/downloads');
const gate=JSON.parse(await readFile(base+'/evidence/current-composition/frontend-gate/receipt.json','utf8'));
const checks=[],observations={},started=Date.now();let browser,server,cdp,failure=null;
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const check=(name,ok,details)=>{checks.push({name,passed:!!ok,details});console.log((ok?'PASS ':'FAIL ')+name);if(!ok)throw Error(name);};
const ev=fn=>cdp.evaluate('('+fn.toString()+')()');
async function snap(){return ev(()=>({
 worldDraft:document.querySelector('#world-json').value,selected:document.querySelector('.flight-row.selected button')?.textContent,
 clock:document.querySelector('#sim-clock').textContent,run:document.querySelector('#toggle-run').textContent,
 proposal:document.querySelector('#proposal-output').innerHTML,proposalState:document.querySelector('#proposal-state').textContent,
 gates:['gate-screen','gate-approval','gate-ack'].map(id=>document.getElementById(id).outerHTML),
 audit:document.querySelector('#audit-status').textContent,events:document.querySelector('#audit-events').innerHTML,
 fields:[...document.querySelectorAll('.flight-builder input')].map(e=>[e.id,e.value,e.readOnly]),
 policy:['policy-horizontal','policy-vertical','policy-horizon','speed-range'].map(id=>[id,document.getElementById(id).value]),
 traffic:document.querySelector('#flight-list').innerHTML,conflicts:document.querySelector('#conflict-list').innerHTML,
 requests:window.__scenarioBoundary.requests
}));}
async function view(){return ev(()=>({range:document.querySelector('#range-label').textContent,
 center:document.querySelector('#radar-center-label').textContent,summary:document.querySelector('#radar-view-summary').textContent,
 auto:document.querySelector('#radar-fit').getAttribute('aria-pressed')}));}
async function review(){return ev(()=>({html:document.querySelector('#scenario-review').outerHTML,
 status:document.querySelector('#scenario-status').textContent,cancel:document.querySelector('#cancel-scenario').outerHTML,
 available:document.querySelector('#scenario-availability').textContent}));}
async function save(){
 const n=await ev(()=>window.__scenarioBoundary.blobs.length);
 await cdp.click('#save-scenario');
 await cdp.wait('window.__scenarioBoundary.blobs.length>'+n+' && window.__scenarioBoundary.blobs['+n+'].text!==null');
 return ev(()=>window.__scenarioBoundary.blobs.at(-1));
}
try{
 const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.wasm':'application/wasm','.zip':'application/zip','.svg':'image/svg+xml'};
 server=createServer(async(req,res)=>{try{
   const pathname=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
   const path=resolve(dist,'.'+(pathname==='/'?'/index.html':pathname));
   if(!path.startsWith(resolve(dist)+sep))throw Error('outside static root');
   const bytes=await readFile(path);res.writeHead(200,{'Content-Type':mime[extname(path)]??'application/octet-stream'});res.end(bytes);
 }catch{res.writeHead(404);res.end('Not found');}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await openBrowser({profile:'/home/jacob/towerops-radar-profiles-401c5d17da79/scenario-current-v1',evidence:out,width:1440,height:1200});
 cdp=browser.cdp;
 await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:out+'/downloads',eventsEnabled:true});
 await cdp.send('Page.addScriptToEvaluateOnNewDocument',{source:'('+(()=>{
   const trace=window.__scenarioBoundary={requests:[],responses:[],blobs:[],heldRead:false,release:null};
   const post=Worker.prototype.postMessage;
   Worker.prototype.postMessage=function(message,...rest){
     trace.requests.push(structuredClone(message));
     if(!this.__receivingObserved){this.__receivingObserved=true;this.addEventListener('message',e=>trace.responses.push(structuredClone(e.data)));}
     return Reflect.apply(post,this,[message,...rest]);
   };
   const create=URL.createObjectURL;
   URL.createObjectURL=function(blob){
     const url=Reflect.apply(create,this,[blob]);
     if(blob instanceof Blob){const row={url,type:blob.type,size:blob.size,text:null};trace.blobs.push(row);blob.text().then(t=>row.text=t);}
     return url;
   };
   const read=File.prototype.text;
   File.prototype.text=async function(){
     const text=await Reflect.apply(read,this,[]);
     if(this.name==='radar-boundary-scenario.json'){
       trace.heldRead=true;await new Promise(resolve=>trace.release=resolve);
     }
     return text;
   };
 }).toString()+')();'});
 await cdp.send('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/'});
 await cdp.wait('document.querySelector("#world-json")?.value?.includes("aircraft")');
 const opening=await view();
 check('built current source starts with the retained automatic fit',opening.auto==='true'&&opening.range.startsWith('AUTO FIT'),opening);
 await cdp.click('.scenario-workbench > summary');
 const initialSave=await save(),initial=JSON.parse(initialSave.text);
 check('native scenario export contains operational fields and no camera schema',
   initial.format==='towerops.airspace-scenario'&&same(Object.keys(initial),['format','version','world','policy','now','time_scale','selected_aircraft_id']),initial);
 await cdp.click('#run-planner');
 await cdp.wait('!document.querySelector("#approve").disabled',60000);
 await cdp.click('#approve');
 await cdp.wait('!document.querySelector("#readback").disabled');
 await cdp.click('.state-workbench > summary');
 const draft='{\n  "unfinished": "Keep this raw draft through camera and scenario actions"\n';
 await cdp.fill('#world-json',draft);
 const held=await snap();
 check('receiving setup holds a real native approved proposal and unfinished draft',
   held.worldDraft===draft&&held.requests.length===1&&held.requests[0].request.op==='plan'&&held.gates[1].includes('APPROVED'),
   {proposal:held.proposalState,requests:held.requests.map(r=>r.request.op),gates:held.gates});
 const plane=(aircraft_id,x_nm,y_nm,altitude_ft,vx_nm_min)=>({aircraft_id,x_nm,y_nm,altitude_ft,vx_nm_min,vy_nm_min:0,climb_ft_min:0});
 const replacement={format:'towerops.airspace-scenario',version:1,
   world:{version:73,observed_at:initial.now+60,aircraft:[plane('WEST',-25,-6,12000,2),plane('EAST',25,6,16000,-1)]},
   policy:{...initial.policy,min_horizontal_nm:6,min_vertical_ft:1200,horizon_min:7.5},
   now:initial.now+60,time_scale:2,selected_aircraft_id:'EAST'};
 const fixture=out+'/radar-boundary-scenario.json';await writeFile(fixture,JSON.stringify(replacement,null,2)+'\n');
 const doc=await cdp.send('DOM.getDocument');const node=await cdp.send('DOM.querySelector',{nodeId:doc.root.nodeId,selector:'#scenario-file'});
 await cdp.send('DOM.setFileInputFiles',{nodeId:node.nodeId,files:[fixture]});
 await cdp.wait('window.__scenarioBoundary.heldRead && document.querySelector("#scenario-status").textContent.startsWith("Reading")');
 const reading=await review();
 for(const id of ['radar-focus','radar-zoom-in','radar-pan-west','radar-pan-west','radar-pan-west','radar-pan-west'])await cdp.click('#'+id);
 check('camera actions preserve the in-progress real file read and all held operational state',same(await snap(),held)&&same(await review(),reading),
   {view:await view(),status:(await review()).status});
 await ev(()=>window.__scenarioBoundary.release());
 await cdp.wait('!document.querySelector("#scenario-review").hidden && !document.querySelector("#load-scenario").disabled');
 const reviewed=await review();
 check('the held actual file reaches an explicit complete review after camera movement',
   reviewed.html.includes('world version 73')&&reviewed.html.includes('selected EAST')&&reviewed.html.includes('7.5 MIN')&&same(await snap(),held),reviewed);
 for(const id of ['radar-fit','radar-focus','radar-zoom-in','radar-pan-west'])await cdp.click('#'+id);
 const manual=await view();
 check('camera controls preserve the completed review and its pending approval exactly',
   manual.auto==='false'&&same(await review(),reviewed)&&same(await snap(),held),manual);
 const duringSave=await save();
 check('native save during manual view serializes identical complete live state',duringSave.text===initialSave.text,
   {before_sha256:hash(initialSave.text),after_sha256:hash(duringSave.text)});
 check('saving the live scenario retains the reviewed replacement and held operational state',
   await ev(()=>!document.querySelector('#scenario-review').hidden&&!document.querySelector('#load-scenario').disabled)&&same(await snap(),held));
 await cdp.evaluate('document.querySelector("#scenario-review").scrollIntoView({block:"center"})');
 await cdp.screenshot(out+'/review-preserved.png');
 await cdp.click('#load-scenario');
 await cdp.wait('document.querySelector("#scenario-status").textContent.startsWith("Scenario loaded")');
 const after=await snap(),afterView=await view();
 const loadedSave=await save(),loaded=JSON.parse(loadedSave.text);
 check('explicit scenario Load restores its complete traffic/policy/clock/rate/selection',same(loaded,replacement),loaded);
 check('explicit load retains manual camera geometry and reports replacement positions honestly',
   afterView.auto==='false'&&afterView.range===manual.range&&afterView.center===manual.center&&
   afterView.summary.includes('0 of 2 aircraft positions in view.')&&afterView.summary.includes('Selected EAST is outside this view.'),afterView);
 check('explicit load keeps the raw draft and performs only the incumbent decision reset',
   after.worldDraft===draft&&after.audit==='0 EVENTS'&&after.proposalState==='IDLE'&&after.run==='Run traffic'&&
   await ev(()=>document.querySelector('#approve').disabled&&document.querySelector('#readback').disabled),
   {draft:after.worldDraft,audit:after.audit,proposal:after.proposalState,run:after.run});
 await cdp.evaluate('document.querySelector(".radar-panel").scrollIntoView({block:"start"})');
 await cdp.screenshot(out+'/loaded-manual.png');
 await cdp.click('#radar-fit');
 const fit=await view(),fittedSave=await save();
 check('auto fit includes all replacement traffic without changing the loaded scenario',
   fit.auto==='true'&&fit.summary.startsWith('2 of 2 aircraft positions in view.')&&loadedSave.text===fittedSave.text,fit);
 const trace=await ev(()=>window.__scenarioBoundary);
 check('camera and file operations generate no additional native worker request',
   trace.requests.length===1&&trace.requests[0].request.op==='plan',trace.requests.map(r=>r.request.op));
 observations.opening=opening;observations.held=held;observations.manual=manual;observations.loaded=after;observations.fit=fit;
 await writeFile(out+'/native-observations.json',JSON.stringify({observations,trace},null,2)+'\n');
 check('actual production browser has no page exceptions or external requests',browser.errors.length===0&&browser.blocked.length===0,{errors:browser.errors,blocked:browser.blocked});
}catch(e){failure=String(e.stack??e);console.error(failure);}
finally{
 if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));
 let source_unchanged=true,build_unchanged=true;
 const changed=[];
 for(const [p,h]of Object.entries(gate.source_hashes)){if(hash(await readFile(root+'/'+p))!==h){source_unchanged=false;changed.push(p);}}
 for(const [p,row]of Object.entries(gate.build)){if(hash(await readFile(dist+'/'+p))!==row.sha256){build_unchanged=false;changed.push('dist/'+p);}}
 checks.push({name:'all sixteen qualified production build files remain byte-identical',passed:build_unchanged,details:{count:Object.keys(gate.build).length}});
 checks.push({name:'all frozen tracked source files remain byte-identical',passed:source_unchanged,details:{count:Object.keys(gate.source_hashes).length,changed}});
 const receipt={head:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),frontend_receipt_sha256:hash(await readFile(base+'/evidence/current-composition/frontend-gate/receipt.json')),
  method_sha256:hash(await readFile(new URL(import.meta.url))),duration_ms:Date.now()-started,checks,passed:checks.filter(x=>x.passed).length,failed:checks.filter(x=>!x.passed).length,
  failure,source_unchanged,build_unchanged,browser:browser?.version,errors:browser?.errors,blocked:browser?.blocked,
  methodology:'Actual built app, real native planner and scenario file; passive Worker/Blob recording. Actual File.text bytes are delayed once in the receiver to expose reading/context preservation. No module or application state hook.'};
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({passed:receipt.passed,failed:receipt.failed,failure,duration_ms:receipt.duration_ms}));
 if(failure||receipt.failed)process.exitCode=1;
}
