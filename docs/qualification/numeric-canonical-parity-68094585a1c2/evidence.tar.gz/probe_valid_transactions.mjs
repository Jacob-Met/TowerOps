import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const variant = process.env.PARITY_VARIANT ?? 'baseline';
const optimize = process.env.PARITY_OPTIMIZE === '1';
const ts = createRequire(import.meta.url)(process.env.PARITY_TYPESCRIPT ??
  '/workspace/scratch/68094585a1c2/production/towerops/web/airspace/node_modules/typescript');
const pins = JSON.parse(readFileSync(join(root, 'source-pins.json'), 'utf8'));
for (const pin of pins.inputs) {
  assert.equal(createHash('sha256').update(readFileSync(join(root, 'baseline', pin.path))).digest('hex'), pin.sha256);
}
function compiled(name, imports = {}) {
  const source = readFileSync(join(root, name === 'core' ? variant : 'baseline', 'web/airspace/src', `${name}.ts`), 'utf8');
  const result = ts.transpileModule(source, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
  }, reportDiagnostics: true });
  assert.equal(result.diagnostics?.length ?? 0, 0);
  const module = { exports: {} };
  Function('require', 'module', 'exports', result.outputText)(name => {
    assert.ok(Object.hasOwn(imports, name)); return imports[name];
  }, module, module.exports);
  return module.exports;
}
const core = compiled('core');
const { AuditLog } = compiled('audit', { './core': core });
function native(request) {
  const result = spawnSync(process.env.PARITY_PYTHON ?? 'python',
    [...(optimize ? ['-O'] : []), join(root, 'native_transaction.py')], {
      input: JSON.stringify({ request_json: JSON.stringify(request) }),
      encoding: 'utf8', timeout: 15000,
      env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1', TMPDIR: root, TMP: root, TEMP: root },
    });
  assert.equal(result.error, undefined, result.error?.message);
  assert.equal(result.status, 0, result.stdout + result.stderr);
  return JSON.parse(result.stdout);
}
const cases = [
  { name: 'positive_microsecond_admission', clock: 0, approved: 0.000001, acknowledged: 0.000002, applied: 0.000003 },
  { name: 'ui_small_fraction', clock: -0.199999 },
  { name: 'ui_large_fraction_control', clock: 1000000000000000.25 },
  { name: 'ui_large_exponent', clock: 10000000000000000 },
];
const rows = [];
for (const item of cases) {
  const state = { version: 7, observed_at: item.clock, aircraft: [
    { aircraft_id: 'PARITY-L', x_nm: -8, y_nm: 0, altitude_ft: 10000, vx_nm_min: 3, vy_nm_min: 0, climb_ft_min: 0 },
    { aircraft_id: 'PARITY-R', x_nm: 8, y_nm: 0, altitude_ft: 10000, vx_nm_min: -3, vy_nm_min: 0, climb_ft_min: 0 },
  ] };
  const planned = native({ op: 'plan', state, policy: core.DEFAULT_POLICY, now: item.clock });
  assert.ok(planned.advisory, `${item.name}: native planner found no advisory`);
  const advisory = planned.advisory;
  const approved_at = item.approved ?? item.clock + 0.2;
  const acknowledged_at = item.acknowledged ?? item.clock + 0.4;
  const applied_at = item.applied ?? item.clock + 0.5;
  const result = native({ op: 'apply', state, policy: core.DEFAULT_POLICY, advisory,
    approval: { advisory_hash: advisory.advisory_hash, decision: 'approve', approved_at, approver: 'parity-review' },
    ack: { advisory_hash: advisory.advisory_hash, status: 'accepted', acknowledged_at },
    now: applied_at, audit_json: '[]' });
  assert.equal(result.error, undefined, `${item.name}: native rejection ${result.error}`);
  assert.equal(result.valid, true);
  assert.equal(result.state.version, 8);
  assert.deepEqual(result.events.map(e => e.kind), ['screen_pass', 'approval', 'ack', 'simulated_actuation']);
  const log = new AuditLog(); log.events = result.events;
  const browserValid = await log.verify();
  const browserBodies = result.events.map(({ event_hash, ...body }) => core.canonicalJson(body));
  const firstDifferent = browserBodies.findIndex((body, i) => body !== result.native_canonical_events[i]);
  const { advisory_hash, ...advisoryBody } = advisory;
  rows.push({ name: item.name, clock: item.clock, approved_at, acknowledged_at, applied_at,
    python_valid: result.valid, browser_valid: browserValid, new_state_version: result.state.version,
    browser_world_hash_matches: (await core.worldHash(state)) === advisory.world_hash,
    browser_advisory_hash_matches: (await core.hashObject(advisoryBody)) === advisory_hash,
    first_different_event: firstDifferent,
    native_canonical: firstDifferent < 0 ? null : result.native_canonical_events[firstDifferent],
    browser_canonical: firstDifferent < 0 ? null : browserBodies[firstDifferent],
    kinds: result.events.map(e => e.kind), events: result.events, audit_json: result.audit_json });
}
const passed = rows.filter(r => r.browser_valid && r.browser_world_hash_matches && r.browser_advisory_hash_matches).length;
console.log(JSON.stringify({ variant, optimized_python: optimize, base_commit: pins.base_commit,
  dependent_guard_sha256: pins.inputs.find(x => x.path.endsWith('python-worker.ts')).sha256,
  core_sha256: createHash('sha256').update(readFileSync(join(root, variant, 'web/airspace/src/core.ts'))).digest('hex'),
  passed, failed: rows.length - passed, cases: rows }, null, 2));
process.exitCode = passed === rows.length ? 0 : 1;
