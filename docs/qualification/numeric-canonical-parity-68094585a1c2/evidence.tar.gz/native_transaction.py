"""Run the exact frozen worker and add native canonical-byte diagnostics."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline"))
from towerops import canonical_bytes

frame = json.load(sys.stdin)
source = (ROOT / "baseline/web/airspace/src/python-worker.ts").read_text()
embedded = source.split("await py.runPythonAsync(`", 1)[1].split("`);", 1)[0]
env = {}
exec(compile(embedded, "frozen-worker:browser-request", "exec"), env)
result = json.loads(env["browser_request"](frame["request_json"]))
if "events" in result:
    result["native_canonical_events"] = [canonical_bytes({
        key: value for key, value in event.items() if key != "event_hash"
    }).decode("utf-8") for event in result["events"]]
print(json.dumps(result))
